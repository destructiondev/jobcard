package g;

public final class a {

    /* renamed from: A */
    public static final int accessibility_custom_action_4 = 2131099675;

    /* renamed from: B */
    public static final int accessibility_custom_action_5 = 2131099676;

    /* renamed from: C */
    public static final int accessibility_custom_action_6 = 2131099677;

    /* renamed from: D */
    public static final int accessibility_custom_action_7 = 2131099678;

    /* renamed from: E */
    public static final int accessibility_custom_action_8 = 2131099679;

    /* renamed from: F */
    public static final int accessibility_custom_action_9 = 2131099680;

    /* renamed from: G */
    public static final int tag_accessibility_pane_title = 2131099716;

    /* renamed from: H */
    public static final int tag_unhandled_key_event_manager = 2131099723;

    /* renamed from: I */
    public static final int tag_unhandled_key_listeners = 2131099724;

    /* renamed from: a */
    public static final int accessibility_custom_action_0 = 2131099649;

    /* renamed from: b */
    public static final int accessibility_custom_action_1 = 2131099650;

    /* renamed from: c */
    public static final int accessibility_custom_action_10 = 2131099651;

    /* renamed from: d */
    public static final int accessibility_custom_action_11 = 2131099652;

    /* renamed from: e */
    public static final int accessibility_custom_action_12 = 2131099653;

    /* renamed from: f */
    public static final int accessibility_custom_action_13 = 2131099654;

    /* renamed from: g */
    public static final int accessibility_custom_action_14 = 2131099655;

    /* renamed from: h */
    public static final int accessibility_custom_action_15 = 2131099656;

    /* renamed from: i */
    public static final int accessibility_custom_action_16 = 2131099657;

    /* renamed from: j */
    public static final int accessibility_custom_action_17 = 2131099658;

    /* renamed from: k */
    public static final int accessibility_custom_action_18 = 2131099659;

    /* renamed from: l */
    public static final int accessibility_custom_action_19 = 2131099660;

    /* renamed from: m */
    public static final int accessibility_custom_action_2 = 2131099661;

    /* renamed from: n */
    public static final int accessibility_custom_action_20 = 2131099662;

    /* renamed from: o */
    public static final int accessibility_custom_action_21 = 2131099663;

    /* renamed from: p */
    public static final int accessibility_custom_action_22 = 2131099664;

    /* renamed from: q */
    public static final int accessibility_custom_action_23 = 2131099665;

    /* renamed from: r */
    public static final int accessibility_custom_action_24 = 2131099666;

    /* renamed from: s */
    public static final int accessibility_custom_action_25 = 2131099667;

    /* renamed from: t */
    public static final int accessibility_custom_action_26 = 2131099668;

    /* renamed from: u */
    public static final int accessibility_custom_action_27 = 2131099669;

    /* renamed from: v */
    public static final int accessibility_custom_action_28 = 2131099670;

    /* renamed from: w */
    public static final int accessibility_custom_action_29 = 2131099671;

    /* renamed from: x */
    public static final int accessibility_custom_action_3 = 2131099672;

    /* renamed from: y */
    public static final int accessibility_custom_action_30 = 2131099673;

    /* renamed from: z */
    public static final int accessibility_custom_action_31 = 2131099674;
}
