package w;

import w.o;

final class i extends o {

    /* renamed from: a  reason: collision with root package name */
    private final o.c f4735a;

    /* renamed from: b  reason: collision with root package name */
    private final o.b f4736b;

    static final class b extends o.a {

        /* renamed from: a  reason: collision with root package name */
        private o.c f4737a;

        /* renamed from: b  reason: collision with root package name */
        private o.b f4738b;

        b() {
        }

        public o a() {
            return new i(this.f4737a, this.f4738b);
        }

        public o.a b(o.b bVar) {
            this.f4738b = bVar;
            return this;
        }

        public o.a c(o.c cVar) {
            this.f4737a = cVar;
            return this;
        }
    }

    private i(o.c cVar, o.b bVar) {
        this.f4735a = cVar;
        this.f4736b = bVar;
    }

    public o.b b() {
        return this.f4736b;
    }

    public o.c c() {
        return this.f4735a;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof o)) {
            return false;
        }
        o oVar = (o) obj;
        o.c cVar = this.f4735a;
        if (cVar != null ? cVar.equals(oVar.c()) : oVar.c() == null) {
            o.b bVar = this.f4736b;
            o.b b4 = oVar.b();
            if (bVar == null) {
                if (b4 == null) {
                    return true;
                }
            } else if (bVar.equals(b4)) {
                return true;
            }
        }
        return false;
    }

    public int hashCode() {
        o.c cVar = this.f4735a;
        int i4 = 0;
        int hashCode = ((cVar == null ? 0 : cVar.hashCode()) ^ 1000003) * 1000003;
        o.b bVar = this.f4736b;
        if (bVar != null) {
            i4 = bVar.hashCode();
        }
        return hashCode ^ i4;
    }

    public String toString() {
        return "NetworkConnectionInfo{networkType=" + this.f4735a + ", mobileSubtype=" + this.f4736b + "}";
    }
}
