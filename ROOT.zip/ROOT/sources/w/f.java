package w;

import java.util.Arrays;
import w.l;

final class f extends l {

    /* renamed from: a  reason: collision with root package name */
    private final long f4706a;

    /* renamed from: b  reason: collision with root package name */
    private final Integer f4707b;

    /* renamed from: c  reason: collision with root package name */
    private final long f4708c;

    /* renamed from: d  reason: collision with root package name */
    private final byte[] f4709d;

    /* renamed from: e  reason: collision with root package name */
    private final String f4710e;

    /* renamed from: f  reason: collision with root package name */
    private final long f4711f;

    /* renamed from: g  reason: collision with root package name */
    private final o f4712g;

    static final class b extends l.a {

        /* renamed from: a  reason: collision with root package name */
        private Long f4713a;

        /* renamed from: b  reason: collision with root package name */
        private Integer f4714b;

        /* renamed from: c  reason: collision with root package name */
        private Long f4715c;

        /* renamed from: d  reason: collision with root package name */
        private byte[] f4716d;

        /* renamed from: e  reason: collision with root package name */
        private String f4717e;

        /* renamed from: f  reason: collision with root package name */
        private Long f4718f;

        /* renamed from: g  reason: collision with root package name */
        private o f4719g;

        b() {
        }

        public l a() {
            String str = "";
            if (this.f4713a == null) {
                str = str + " eventTimeMs";
            }
            if (this.f4715c == null) {
                str = str + " eventUptimeMs";
            }
            if (this.f4718f == null) {
                str = str + " timezoneOffsetSeconds";
            }
            if (str.isEmpty()) {
                return new f(this.f4713a.longValue(), this.f4714b, this.f4715c.longValue(), this.f4716d, this.f4717e, this.f4718f.longValue(), this.f4719g);
            }
            throw new IllegalStateException("Missing required properties:" + str);
        }

        public l.a b(Integer num) {
            this.f4714b = num;
            return this;
        }

        public l.a c(long j4) {
            this.f4713a = Long.valueOf(j4);
            return this;
        }

        public l.a d(long j4) {
            this.f4715c = Long.valueOf(j4);
            return this;
        }

        public l.a e(o oVar) {
            this.f4719g = oVar;
            return this;
        }

        /* access modifiers changed from: package-private */
        public l.a f(byte[] bArr) {
            this.f4716d = bArr;
            return this;
        }

        /* access modifiers changed from: package-private */
        public l.a g(String str) {
            this.f4717e = str;
            return this;
        }

        public l.a h(long j4) {
            this.f4718f = Long.valueOf(j4);
            return this;
        }
    }

    private f(long j4, Integer num, long j5, byte[] bArr, String str, long j6, o oVar) {
        this.f4706a = j4;
        this.f4707b = num;
        this.f4708c = j5;
        this.f4709d = bArr;
        this.f4710e = str;
        this.f4711f = j6;
        this.f4712g = oVar;
    }

    public Integer b() {
        return this.f4707b;
    }

    public long c() {
        return this.f4706a;
    }

    public long d() {
        return this.f4708c;
    }

    public o e() {
        return this.f4712g;
    }

    public boolean equals(Object obj) {
        Integer num;
        String str;
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof l)) {
            return false;
        }
        l lVar = (l) obj;
        if (this.f4706a == lVar.c() && ((num = this.f4707b) != null ? num.equals(lVar.b()) : lVar.b() == null) && this.f4708c == lVar.d()) {
            if (Arrays.equals(this.f4709d, lVar instanceof f ? ((f) lVar).f4709d : lVar.f()) && ((str = this.f4710e) != null ? str.equals(lVar.g()) : lVar.g() == null) && this.f4711f == lVar.h()) {
                o oVar = this.f4712g;
                o e4 = lVar.e();
                if (oVar == null) {
                    if (e4 == null) {
                        return true;
                    }
                } else if (oVar.equals(e4)) {
                    return true;
                }
            }
        }
        return false;
    }

    public byte[] f() {
        return this.f4709d;
    }

    public String g() {
        return this.f4710e;
    }

    public long h() {
        return this.f4711f;
    }

    public int hashCode() {
        long j4 = this.f4706a;
        int i4 = (((int) (j4 ^ (j4 >>> 32))) ^ 1000003) * 1000003;
        Integer num = this.f4707b;
        int i5 = 0;
        int hashCode = num == null ? 0 : num.hashCode();
        long j5 = this.f4708c;
        int hashCode2 = (((((i4 ^ hashCode) * 1000003) ^ ((int) (j5 ^ (j5 >>> 32)))) * 1000003) ^ Arrays.hashCode(this.f4709d)) * 1000003;
        String str = this.f4710e;
        int hashCode3 = str == null ? 0 : str.hashCode();
        long j6 = this.f4711f;
        int i6 = (((hashCode2 ^ hashCode3) * 1000003) ^ ((int) ((j6 >>> 32) ^ j6))) * 1000003;
        o oVar = this.f4712g;
        if (oVar != null) {
            i5 = oVar.hashCode();
        }
        return i6 ^ i5;
    }

    public String toString() {
        return "LogEvent{eventTimeMs=" + this.f4706a + ", eventCode=" + this.f4707b + ", eventUptimeMs=" + this.f4708c + ", sourceExtension=" + Arrays.toString(this.f4709d) + ", sourceExtensionJsonProto3=" + this.f4710e + ", timezoneOffsetSeconds=" + this.f4711f + ", networkConnectionInfo=" + this.f4712g + "}";
    }
}
