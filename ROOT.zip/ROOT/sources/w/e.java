package w;

import w.k;

final class e extends k {

    /* renamed from: a  reason: collision with root package name */
    private final k.b f4702a;

    /* renamed from: b  reason: collision with root package name */
    private final a f4703b;

    static final class b extends k.a {

        /* renamed from: a  reason: collision with root package name */
        private k.b f4704a;

        /* renamed from: b  reason: collision with root package name */
        private a f4705b;

        b() {
        }

        public k a() {
            return new e(this.f4704a, this.f4705b);
        }

        public k.a b(a aVar) {
            this.f4705b = aVar;
            return this;
        }

        public k.a c(k.b bVar) {
            this.f4704a = bVar;
            return this;
        }
    }

    private e(k.b bVar, a aVar) {
        this.f4702a = bVar;
        this.f4703b = aVar;
    }

    public a b() {
        return this.f4703b;
    }

    public k.b c() {
        return this.f4702a;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof k)) {
            return false;
        }
        k kVar = (k) obj;
        k.b bVar = this.f4702a;
        if (bVar != null ? bVar.equals(kVar.c()) : kVar.c() == null) {
            a aVar = this.f4703b;
            a b4 = kVar.b();
            if (aVar == null) {
                if (b4 == null) {
                    return true;
                }
            } else if (aVar.equals(b4)) {
                return true;
            }
        }
        return false;
    }

    public int hashCode() {
        k.b bVar = this.f4702a;
        int i4 = 0;
        int hashCode = ((bVar == null ? 0 : bVar.hashCode()) ^ 1000003) * 1000003;
        a aVar = this.f4703b;
        if (aVar != null) {
            i4 = aVar.hashCode();
        }
        return hashCode ^ i4;
    }

    public String toString() {
        return "ClientInfo{clientType=" + this.f4702a + ", androidClientInfo=" + this.f4703b + "}";
    }
}
