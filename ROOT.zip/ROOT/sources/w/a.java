package w;

import w.c;

public abstract class a {

    /* renamed from: w.a$a  reason: collision with other inner class name */
    public static abstract class C0115a {
        public abstract a a();

        public abstract C0115a b(String str);

        public abstract C0115a c(String str);

        public abstract C0115a d(String str);

        public abstract C0115a e(String str);

        public abstract C0115a f(String str);

        public abstract C0115a g(String str);

        public abstract C0115a h(String str);

        public abstract C0115a i(String str);

        public abstract C0115a j(String str);

        public abstract C0115a k(String str);

        public abstract C0115a l(String str);

        public abstract C0115a m(Integer num);
    }

    public static C0115a a() {
        return new c.b();
    }

    public abstract String b();

    public abstract String c();

    public abstract String d();

    public abstract String e();

    public abstract String f();

    public abstract String g();

    public abstract String h();

    public abstract String i();

    public abstract String j();

    public abstract String k();

    public abstract String l();

    public abstract Integer m();
}
