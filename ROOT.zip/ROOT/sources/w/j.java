package w;

import java.util.List;
import l1.a;
import n1.d;

public abstract class j {
    public static j a(List<m> list) {
        return new d(list);
    }

    public static a b() {
        return new d().j(b.f4639a).k(true).i();
    }

    public abstract List<m> c();
}
