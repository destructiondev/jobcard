package w;

public final class b implements m1.a {

    /* renamed from: a  reason: collision with root package name */
    public static final m1.a f4639a = new b();

    private static final class a implements l1.d<a> {

        /* renamed from: a  reason: collision with root package name */
        static final a f4640a = new a();

        /* renamed from: b  reason: collision with root package name */
        private static final l1.c f4641b = l1.c.d("sdkVersion");

        /* renamed from: c  reason: collision with root package name */
        private static final l1.c f4642c = l1.c.d("model");

        /* renamed from: d  reason: collision with root package name */
        private static final l1.c f4643d = l1.c.d("hardware");

        /* renamed from: e  reason: collision with root package name */
        private static final l1.c f4644e = l1.c.d("device");

        /* renamed from: f  reason: collision with root package name */
        private static final l1.c f4645f = l1.c.d("product");

        /* renamed from: g  reason: collision with root package name */
        private static final l1.c f4646g = l1.c.d("osBuild");

        /* renamed from: h  reason: collision with root package name */
        private static final l1.c f4647h = l1.c.d("manufacturer");

        /* renamed from: i  reason: collision with root package name */
        private static final l1.c f4648i = l1.c.d("fingerprint");

        /* renamed from: j  reason: collision with root package name */
        private static final l1.c f4649j = l1.c.d("locale");

        /* renamed from: k  reason: collision with root package name */
        private static final l1.c f4650k = l1.c.d("country");

        /* renamed from: l  reason: collision with root package name */
        private static final l1.c f4651l = l1.c.d("mccMnc");

        /* renamed from: m  reason: collision with root package name */
        private static final l1.c f4652m = l1.c.d("applicationBuild");

        private a() {
        }

        /* renamed from: b */
        public void a(a aVar, l1.e eVar) {
            eVar.f(f4641b, aVar.m());
            eVar.f(f4642c, aVar.j());
            eVar.f(f4643d, aVar.f());
            eVar.f(f4644e, aVar.d());
            eVar.f(f4645f, aVar.l());
            eVar.f(f4646g, aVar.k());
            eVar.f(f4647h, aVar.h());
            eVar.f(f4648i, aVar.e());
            eVar.f(f4649j, aVar.g());
            eVar.f(f4650k, aVar.c());
            eVar.f(f4651l, aVar.i());
            eVar.f(f4652m, aVar.b());
        }
    }

    /* renamed from: w.b$b  reason: collision with other inner class name */
    private static final class C0116b implements l1.d<j> {

        /* renamed from: a  reason: collision with root package name */
        static final C0116b f4653a = new C0116b();

        /* renamed from: b  reason: collision with root package name */
        private static final l1.c f4654b = l1.c.d("logRequest");

        private C0116b() {
        }

        /* renamed from: b */
        public void a(j jVar, l1.e eVar) {
            eVar.f(f4654b, jVar.c());
        }
    }

    private static final class c implements l1.d<k> {

        /* renamed from: a  reason: collision with root package name */
        static final c f4655a = new c();

        /* renamed from: b  reason: collision with root package name */
        private static final l1.c f4656b = l1.c.d("clientType");

        /* renamed from: c  reason: collision with root package name */
        private static final l1.c f4657c = l1.c.d("androidClientInfo");

        private c() {
        }

        /* renamed from: b */
        public void a(k kVar, l1.e eVar) {
            eVar.f(f4656b, kVar.c());
            eVar.f(f4657c, kVar.b());
        }
    }

    private static final class d implements l1.d<l> {

        /* renamed from: a  reason: collision with root package name */
        static final d f4658a = new d();

        /* renamed from: b  reason: collision with root package name */
        private static final l1.c f4659b = l1.c.d("eventTimeMs");

        /* renamed from: c  reason: collision with root package name */
        private static final l1.c f4660c = l1.c.d("eventCode");

        /* renamed from: d  reason: collision with root package name */
        private static final l1.c f4661d = l1.c.d("eventUptimeMs");

        /* renamed from: e  reason: collision with root package name */
        private static final l1.c f4662e = l1.c.d("sourceExtension");

        /* renamed from: f  reason: collision with root package name */
        private static final l1.c f4663f = l1.c.d("sourceExtensionJsonProto3");

        /* renamed from: g  reason: collision with root package name */
        private static final l1.c f4664g = l1.c.d("timezoneOffsetSeconds");

        /* renamed from: h  reason: collision with root package name */
        private static final l1.c f4665h = l1.c.d("networkConnectionInfo");

        private d() {
        }

        /* renamed from: b */
        public void a(l lVar, l1.e eVar) {
            eVar.e(f4659b, lVar.c());
            eVar.f(f4660c, lVar.b());
            eVar.e(f4661d, lVar.d());
            eVar.f(f4662e, lVar.f());
            eVar.f(f4663f, lVar.g());
            eVar.e(f4664g, lVar.h());
            eVar.f(f4665h, lVar.e());
        }
    }

    private static final class e implements l1.d<m> {

        /* renamed from: a  reason: collision with root package name */
        static final e f4666a = new e();

        /* renamed from: b  reason: collision with root package name */
        private static final l1.c f4667b = l1.c.d("requestTimeMs");

        /* renamed from: c  reason: collision with root package name */
        private static final l1.c f4668c = l1.c.d("requestUptimeMs");

        /* renamed from: d  reason: collision with root package name */
        private static final l1.c f4669d = l1.c.d("clientInfo");

        /* renamed from: e  reason: collision with root package name */
        private static final l1.c f4670e = l1.c.d("logSource");

        /* renamed from: f  reason: collision with root package name */
        private static final l1.c f4671f = l1.c.d("logSourceName");

        /* renamed from: g  reason: collision with root package name */
        private static final l1.c f4672g = l1.c.d("logEvent");

        /* renamed from: h  reason: collision with root package name */
        private static final l1.c f4673h = l1.c.d("qosTier");

        private e() {
        }

        /* renamed from: b */
        public void a(m mVar, l1.e eVar) {
            eVar.e(f4667b, mVar.g());
            eVar.e(f4668c, mVar.h());
            eVar.f(f4669d, mVar.b());
            eVar.f(f4670e, mVar.d());
            eVar.f(f4671f, mVar.e());
            eVar.f(f4672g, mVar.c());
            eVar.f(f4673h, mVar.f());
        }
    }

    private static final class f implements l1.d<o> {

        /* renamed from: a  reason: collision with root package name */
        static final f f4674a = new f();

        /* renamed from: b  reason: collision with root package name */
        private static final l1.c f4675b = l1.c.d("networkType");

        /* renamed from: c  reason: collision with root package name */
        private static final l1.c f4676c = l1.c.d("mobileSubtype");

        private f() {
        }

        /* renamed from: b */
        public void a(o oVar, l1.e eVar) {
            eVar.f(f4675b, oVar.c());
            eVar.f(f4676c, oVar.b());
        }
    }

    private b() {
    }

    public void a(m1.b<?> bVar) {
        C0116b bVar2 = C0116b.f4653a;
        bVar.a(j.class, bVar2);
        bVar.a(d.class, bVar2);
        e eVar = e.f4666a;
        bVar.a(m.class, eVar);
        bVar.a(g.class, eVar);
        c cVar = c.f4655a;
        bVar.a(k.class, cVar);
        bVar.a(e.class, cVar);
        a aVar = a.f4640a;
        bVar.a(a.class, aVar);
        bVar.a(c.class, aVar);
        d dVar = d.f4658a;
        bVar.a(l.class, dVar);
        bVar.a(f.class, dVar);
        f fVar = f.f4674a;
        bVar.a(o.class, fVar);
        bVar.a(i.class, fVar);
    }
}
