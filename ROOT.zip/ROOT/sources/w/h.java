package w;

final class h extends n {

    /* renamed from: a  reason: collision with root package name */
    private final long f4734a;

    h(long j4) {
        this.f4734a = j4;
    }

    public long c() {
        return this.f4734a;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        return (obj instanceof n) && this.f4734a == ((n) obj).c();
    }

    public int hashCode() {
        long j4 = this.f4734a;
        return 1000003 ^ ((int) (j4 ^ (j4 >>> 32)));
    }

    public String toString() {
        return "LogResponse{nextRequestWaitMillis=" + this.f4734a + "}";
    }
}
