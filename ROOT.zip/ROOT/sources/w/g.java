package w;

import java.util.List;
import w.m;

final class g extends m {

    /* renamed from: a  reason: collision with root package name */
    private final long f4720a;

    /* renamed from: b  reason: collision with root package name */
    private final long f4721b;

    /* renamed from: c  reason: collision with root package name */
    private final k f4722c;

    /* renamed from: d  reason: collision with root package name */
    private final Integer f4723d;

    /* renamed from: e  reason: collision with root package name */
    private final String f4724e;

    /* renamed from: f  reason: collision with root package name */
    private final List<l> f4725f;

    /* renamed from: g  reason: collision with root package name */
    private final p f4726g;

    static final class b extends m.a {

        /* renamed from: a  reason: collision with root package name */
        private Long f4727a;

        /* renamed from: b  reason: collision with root package name */
        private Long f4728b;

        /* renamed from: c  reason: collision with root package name */
        private k f4729c;

        /* renamed from: d  reason: collision with root package name */
        private Integer f4730d;

        /* renamed from: e  reason: collision with root package name */
        private String f4731e;

        /* renamed from: f  reason: collision with root package name */
        private List<l> f4732f;

        /* renamed from: g  reason: collision with root package name */
        private p f4733g;

        b() {
        }

        public m a() {
            String str = "";
            if (this.f4727a == null) {
                str = str + " requestTimeMs";
            }
            if (this.f4728b == null) {
                str = str + " requestUptimeMs";
            }
            if (str.isEmpty()) {
                return new g(this.f4727a.longValue(), this.f4728b.longValue(), this.f4729c, this.f4730d, this.f4731e, this.f4732f, this.f4733g);
            }
            throw new IllegalStateException("Missing required properties:" + str);
        }

        public m.a b(k kVar) {
            this.f4729c = kVar;
            return this;
        }

        public m.a c(List<l> list) {
            this.f4732f = list;
            return this;
        }

        /* access modifiers changed from: package-private */
        public m.a d(Integer num) {
            this.f4730d = num;
            return this;
        }

        /* access modifiers changed from: package-private */
        public m.a e(String str) {
            this.f4731e = str;
            return this;
        }

        public m.a f(p pVar) {
            this.f4733g = pVar;
            return this;
        }

        public m.a g(long j4) {
            this.f4727a = Long.valueOf(j4);
            return this;
        }

        public m.a h(long j4) {
            this.f4728b = Long.valueOf(j4);
            return this;
        }
    }

    private g(long j4, long j5, k kVar, Integer num, String str, List<l> list, p pVar) {
        this.f4720a = j4;
        this.f4721b = j5;
        this.f4722c = kVar;
        this.f4723d = num;
        this.f4724e = str;
        this.f4725f = list;
        this.f4726g = pVar;
    }

    public k b() {
        return this.f4722c;
    }

    public List<l> c() {
        return this.f4725f;
    }

    public Integer d() {
        return this.f4723d;
    }

    public String e() {
        return this.f4724e;
    }

    public boolean equals(Object obj) {
        k kVar;
        Integer num;
        String str;
        List<l> list;
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof m)) {
            return false;
        }
        m mVar = (m) obj;
        if (this.f4720a == mVar.g() && this.f4721b == mVar.h() && ((kVar = this.f4722c) != null ? kVar.equals(mVar.b()) : mVar.b() == null) && ((num = this.f4723d) != null ? num.equals(mVar.d()) : mVar.d() == null) && ((str = this.f4724e) != null ? str.equals(mVar.e()) : mVar.e() == null) && ((list = this.f4725f) != null ? list.equals(mVar.c()) : mVar.c() == null)) {
            p pVar = this.f4726g;
            p f4 = mVar.f();
            if (pVar == null) {
                if (f4 == null) {
                    return true;
                }
            } else if (pVar.equals(f4)) {
                return true;
            }
        }
        return false;
    }

    public p f() {
        return this.f4726g;
    }

    public long g() {
        return this.f4720a;
    }

    public long h() {
        return this.f4721b;
    }

    public int hashCode() {
        long j4 = this.f4720a;
        long j5 = this.f4721b;
        int i4 = (((((int) (j4 ^ (j4 >>> 32))) ^ 1000003) * 1000003) ^ ((int) ((j5 >>> 32) ^ j5))) * 1000003;
        k kVar = this.f4722c;
        int i5 = 0;
        int hashCode = (i4 ^ (kVar == null ? 0 : kVar.hashCode())) * 1000003;
        Integer num = this.f4723d;
        int hashCode2 = (hashCode ^ (num == null ? 0 : num.hashCode())) * 1000003;
        String str = this.f4724e;
        int hashCode3 = (hashCode2 ^ (str == null ? 0 : str.hashCode())) * 1000003;
        List<l> list = this.f4725f;
        int hashCode4 = (hashCode3 ^ (list == null ? 0 : list.hashCode())) * 1000003;
        p pVar = this.f4726g;
        if (pVar != null) {
            i5 = pVar.hashCode();
        }
        return hashCode4 ^ i5;
    }

    public String toString() {
        return "LogRequest{requestTimeMs=" + this.f4720a + ", requestUptimeMs=" + this.f4721b + ", clientInfo=" + this.f4722c + ", logSource=" + this.f4723d + ", logSourceName=" + this.f4724e + ", logEvents=" + this.f4725f + ", qosTier=" + this.f4726g + "}";
    }
}
