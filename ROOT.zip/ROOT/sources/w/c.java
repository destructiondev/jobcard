package w;

import w.a;

final class c extends a {

    /* renamed from: a  reason: collision with root package name */
    private final Integer f4677a;

    /* renamed from: b  reason: collision with root package name */
    private final String f4678b;

    /* renamed from: c  reason: collision with root package name */
    private final String f4679c;

    /* renamed from: d  reason: collision with root package name */
    private final String f4680d;

    /* renamed from: e  reason: collision with root package name */
    private final String f4681e;

    /* renamed from: f  reason: collision with root package name */
    private final String f4682f;

    /* renamed from: g  reason: collision with root package name */
    private final String f4683g;

    /* renamed from: h  reason: collision with root package name */
    private final String f4684h;

    /* renamed from: i  reason: collision with root package name */
    private final String f4685i;

    /* renamed from: j  reason: collision with root package name */
    private final String f4686j;

    /* renamed from: k  reason: collision with root package name */
    private final String f4687k;

    /* renamed from: l  reason: collision with root package name */
    private final String f4688l;

    static final class b extends a.C0115a {

        /* renamed from: a  reason: collision with root package name */
        private Integer f4689a;

        /* renamed from: b  reason: collision with root package name */
        private String f4690b;

        /* renamed from: c  reason: collision with root package name */
        private String f4691c;

        /* renamed from: d  reason: collision with root package name */
        private String f4692d;

        /* renamed from: e  reason: collision with root package name */
        private String f4693e;

        /* renamed from: f  reason: collision with root package name */
        private String f4694f;

        /* renamed from: g  reason: collision with root package name */
        private String f4695g;

        /* renamed from: h  reason: collision with root package name */
        private String f4696h;

        /* renamed from: i  reason: collision with root package name */
        private String f4697i;

        /* renamed from: j  reason: collision with root package name */
        private String f4698j;

        /* renamed from: k  reason: collision with root package name */
        private String f4699k;

        /* renamed from: l  reason: collision with root package name */
        private String f4700l;

        b() {
        }

        public a a() {
            return new c(this.f4689a, this.f4690b, this.f4691c, this.f4692d, this.f4693e, this.f4694f, this.f4695g, this.f4696h, this.f4697i, this.f4698j, this.f4699k, this.f4700l);
        }

        public a.C0115a b(String str) {
            this.f4700l = str;
            return this;
        }

        public a.C0115a c(String str) {
            this.f4698j = str;
            return this;
        }

        public a.C0115a d(String str) {
            this.f4692d = str;
            return this;
        }

        public a.C0115a e(String str) {
            this.f4696h = str;
            return this;
        }

        public a.C0115a f(String str) {
            this.f4691c = str;
            return this;
        }

        public a.C0115a g(String str) {
            this.f4697i = str;
            return this;
        }

        public a.C0115a h(String str) {
            this.f4695g = str;
            return this;
        }

        public a.C0115a i(String str) {
            this.f4699k = str;
            return this;
        }

        public a.C0115a j(String str) {
            this.f4690b = str;
            return this;
        }

        public a.C0115a k(String str) {
            this.f4694f = str;
            return this;
        }

        public a.C0115a l(String str) {
            this.f4693e = str;
            return this;
        }

        public a.C0115a m(Integer num) {
            this.f4689a = num;
            return this;
        }
    }

    private c(Integer num, String str, String str2, String str3, String str4, String str5, String str6, String str7, String str8, String str9, String str10, String str11) {
        this.f4677a = num;
        this.f4678b = str;
        this.f4679c = str2;
        this.f4680d = str3;
        this.f4681e = str4;
        this.f4682f = str5;
        this.f4683g = str6;
        this.f4684h = str7;
        this.f4685i = str8;
        this.f4686j = str9;
        this.f4687k = str10;
        this.f4688l = str11;
    }

    public String b() {
        return this.f4688l;
    }

    public String c() {
        return this.f4686j;
    }

    public String d() {
        return this.f4680d;
    }

    public String e() {
        return this.f4684h;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof a)) {
            return false;
        }
        a aVar = (a) obj;
        Integer num = this.f4677a;
        if (num != null ? num.equals(aVar.m()) : aVar.m() == null) {
            String str = this.f4678b;
            if (str != null ? str.equals(aVar.j()) : aVar.j() == null) {
                String str2 = this.f4679c;
                if (str2 != null ? str2.equals(aVar.f()) : aVar.f() == null) {
                    String str3 = this.f4680d;
                    if (str3 != null ? str3.equals(aVar.d()) : aVar.d() == null) {
                        String str4 = this.f4681e;
                        if (str4 != null ? str4.equals(aVar.l()) : aVar.l() == null) {
                            String str5 = this.f4682f;
                            if (str5 != null ? str5.equals(aVar.k()) : aVar.k() == null) {
                                String str6 = this.f4683g;
                                if (str6 != null ? str6.equals(aVar.h()) : aVar.h() == null) {
                                    String str7 = this.f4684h;
                                    if (str7 != null ? str7.equals(aVar.e()) : aVar.e() == null) {
                                        String str8 = this.f4685i;
                                        if (str8 != null ? str8.equals(aVar.g()) : aVar.g() == null) {
                                            String str9 = this.f4686j;
                                            if (str9 != null ? str9.equals(aVar.c()) : aVar.c() == null) {
                                                String str10 = this.f4687k;
                                                if (str10 != null ? str10.equals(aVar.i()) : aVar.i() == null) {
                                                    String str11 = this.f4688l;
                                                    String b4 = aVar.b();
                                                    if (str11 == null) {
                                                        if (b4 == null) {
                                                            return true;
                                                        }
                                                    } else if (str11.equals(b4)) {
                                                        return true;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        return false;
    }

    public String f() {
        return this.f4679c;
    }

    public String g() {
        return this.f4685i;
    }

    public String h() {
        return this.f4683g;
    }

    public int hashCode() {
        Integer num = this.f4677a;
        int i4 = 0;
        int hashCode = ((num == null ? 0 : num.hashCode()) ^ 1000003) * 1000003;
        String str = this.f4678b;
        int hashCode2 = (hashCode ^ (str == null ? 0 : str.hashCode())) * 1000003;
        String str2 = this.f4679c;
        int hashCode3 = (hashCode2 ^ (str2 == null ? 0 : str2.hashCode())) * 1000003;
        String str3 = this.f4680d;
        int hashCode4 = (hashCode3 ^ (str3 == null ? 0 : str3.hashCode())) * 1000003;
        String str4 = this.f4681e;
        int hashCode5 = (hashCode4 ^ (str4 == null ? 0 : str4.hashCode())) * 1000003;
        String str5 = this.f4682f;
        int hashCode6 = (hashCode5 ^ (str5 == null ? 0 : str5.hashCode())) * 1000003;
        String str6 = this.f4683g;
        int hashCode7 = (hashCode6 ^ (str6 == null ? 0 : str6.hashCode())) * 1000003;
        String str7 = this.f4684h;
        int hashCode8 = (hashCode7 ^ (str7 == null ? 0 : str7.hashCode())) * 1000003;
        String str8 = this.f4685i;
        int hashCode9 = (hashCode8 ^ (str8 == null ? 0 : str8.hashCode())) * 1000003;
        String str9 = this.f4686j;
        int hashCode10 = (hashCode9 ^ (str9 == null ? 0 : str9.hashCode())) * 1000003;
        String str10 = this.f4687k;
        int hashCode11 = (hashCode10 ^ (str10 == null ? 0 : str10.hashCode())) * 1000003;
        String str11 = this.f4688l;
        if (str11 != null) {
            i4 = str11.hashCode();
        }
        return hashCode11 ^ i4;
    }

    public String i() {
        return this.f4687k;
    }

    public String j() {
        return this.f4678b;
    }

    public String k() {
        return this.f4682f;
    }

    public String l() {
        return this.f4681e;
    }

    public Integer m() {
        return this.f4677a;
    }

    public String toString() {
        return "AndroidClientInfo{sdkVersion=" + this.f4677a + ", model=" + this.f4678b + ", hardware=" + this.f4679c + ", device=" + this.f4680d + ", product=" + this.f4681e + ", osBuild=" + this.f4682f + ", manufacturer=" + this.f4683g + ", fingerprint=" + this.f4684h + ", locale=" + this.f4685i + ", country=" + this.f4686j + ", mccMnc=" + this.f4687k + ", applicationBuild=" + this.f4688l + "}";
    }
}
