package w;

import w.e;

public abstract class k {

    public static abstract class a {
        public abstract k a();

        public abstract a b(a aVar);

        public abstract a c(b bVar);
    }

    public enum b {
        UNKNOWN(0),
        ANDROID_FIREBASE(23);
        

        /* renamed from: d  reason: collision with root package name */
        private final int f4742d;

        private b(int i4) {
            this.f4742d = i4;
        }
    }

    public static a a() {
        return new e.b();
    }

    public abstract a b();

    public abstract b c();
}
