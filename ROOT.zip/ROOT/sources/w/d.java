package w;

import java.util.List;
import java.util.Objects;

final class d extends j {

    /* renamed from: a  reason: collision with root package name */
    private final List<m> f4701a;

    d(List<m> list) {
        Objects.requireNonNull(list, "Null logRequests");
        this.f4701a = list;
    }

    public List<m> c() {
        return this.f4701a;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (obj instanceof j) {
            return this.f4701a.equals(((j) obj).c());
        }
        return false;
    }

    public int hashCode() {
        return this.f4701a.hashCode() ^ 1000003;
    }

    public String toString() {
        return "BatchedLogRequest{logRequests=" + this.f4701a + "}";
    }
}
