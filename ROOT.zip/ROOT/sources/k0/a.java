package k0;

import android.app.Activity;
import android.app.Application;
import android.content.ComponentCallbacks2;
import android.content.res.Configuration;
import android.os.Bundle;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.concurrent.atomic.AtomicBoolean;

public final class a implements Application.ActivityLifecycleCallbacks, ComponentCallbacks2 {

    /* renamed from: h  reason: collision with root package name */
    private static final a f3430h = new a();

    /* renamed from: d  reason: collision with root package name */
    private final AtomicBoolean f3431d = new AtomicBoolean();

    /* renamed from: e  reason: collision with root package name */
    private final AtomicBoolean f3432e = new AtomicBoolean();

    /* renamed from: f  reason: collision with root package name */
    private final ArrayList f3433f = new ArrayList();

    /* renamed from: g  reason: collision with root package name */
    private boolean f3434g = false;

    /* renamed from: k0.a$a  reason: collision with other inner class name */
    public interface C0082a {
        void a(boolean z3);
    }

    private a() {
    }

    public static a b() {
        return f3430h;
    }

    public static void c(Application application) {
        a aVar = f3430h;
        synchronized (aVar) {
            if (!aVar.f3434g) {
                application.registerActivityLifecycleCallbacks(aVar);
                application.registerComponentCallbacks(aVar);
                aVar.f3434g = true;
            }
        }
    }

    private final void e(boolean z3) {
        synchronized (f3430h) {
            Iterator it = this.f3433f.iterator();
            while (it.hasNext()) {
                ((C0082a) it.next()).a(z3);
            }
        }
    }

    public void a(C0082a aVar) {
        synchronized (f3430h) {
            this.f3433f.add(aVar);
        }
    }

    public boolean d() {
        return this.f3431d.get();
    }

    public final void onActivityCreated(Activity activity, Bundle bundle) {
        boolean compareAndSet = this.f3431d.compareAndSet(true, false);
        this.f3432e.set(true);
        if (compareAndSet) {
            e(false);
        }
    }

    public final void onActivityDestroyed(Activity activity) {
    }

    public final void onActivityPaused(Activity activity) {
    }

    public final void onActivityResumed(Activity activity) {
        boolean compareAndSet = this.f3431d.compareAndSet(true, false);
        this.f3432e.set(true);
        if (compareAndSet) {
            e(false);
        }
    }

    public final void onActivitySaveInstanceState(Activity activity, Bundle bundle) {
    }

    public final void onActivityStarted(Activity activity) {
    }

    public final void onActivityStopped(Activity activity) {
    }

    public final void onConfigurationChanged(Configuration configuration) {
    }

    public final void onLowMemory() {
    }

    public final void onTrimMemory(int i4) {
        if (i4 == 20 && this.f3431d.compareAndSet(false, true)) {
            this.f3432e.set(true);
            e(true);
        }
    }
}
