package k0;

public class b {
}
