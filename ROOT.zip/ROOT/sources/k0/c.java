package k0;

public interface c {
}
