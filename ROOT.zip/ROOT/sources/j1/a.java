package j1;

import android.content.Context;
import u0.e;
import u0.h;
import x.u;

public final /* synthetic */ class a implements h {

    /* renamed from: a  reason: collision with root package name */
    public static final /* synthetic */ a f3429a = new a();

    private /* synthetic */ a() {
    }

    public final Object a(e eVar) {
        return u.f((Context) eVar.a(Context.class));
    }
}
