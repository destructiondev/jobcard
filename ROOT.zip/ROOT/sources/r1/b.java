package r1;

public interface b<T> {
    T get();
}
