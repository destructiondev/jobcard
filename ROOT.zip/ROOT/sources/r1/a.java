package r1;

public interface a<T> {

    /* renamed from: r1.a$a  reason: collision with other inner class name */
    public interface C0098a<T> {
        void a(b<T> bVar);
    }

    void a(C0098a<T> aVar);
}
