package h0;

import z.b;

public final class d implements b<a> {

    private static final class a {
        /* access modifiers changed from: private */

        /* renamed from: a  reason: collision with root package name */
        public static final d f2141a = new d();
    }

    public static d a() {
        return a.f2141a;
    }

    public static a c() {
        return (a) z.d.c(b.b(), "Cannot return null from a non-@Nullable @Provides method");
    }

    /* renamed from: b */
    public a get() {
        return c();
    }
}
