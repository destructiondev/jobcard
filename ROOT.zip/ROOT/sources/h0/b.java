package h0;

public abstract class b {
    static a a() {
        return new f();
    }

    static a b() {
        return new e();
    }
}
