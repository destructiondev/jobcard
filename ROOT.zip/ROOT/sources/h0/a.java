package h0;

public interface a {
    long a();
}
