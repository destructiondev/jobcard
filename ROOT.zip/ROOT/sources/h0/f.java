package h0;

public class f implements a {
    public long a() {
        return System.currentTimeMillis();
    }
}
