package l;

import android.content.Context;
import i.a;
import java.io.File;
import kotlin.jvm.internal.i;

public final class b {
    public static final File a(Context context, String str) {
        i.e(context, "<this>");
        i.e(str, "name");
        return a.a(context, i.k(str, ".preferences_pb"));
    }
}
