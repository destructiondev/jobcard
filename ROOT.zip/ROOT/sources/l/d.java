package l;

import androidx.datastore.preferences.protobuf.b0;
import java.io.InputStream;
import kotlin.jvm.internal.e;
import kotlin.jvm.internal.i;

public final class d {

    /* renamed from: a  reason: collision with root package name */
    public static final a f3644a = new a((e) null);

    public static final class a {
        private a() {
        }

        public /* synthetic */ a(e eVar) {
            this();
        }

        public final f a(InputStream inputStream) {
            i.e(inputStream, "input");
            try {
                f S = f.S(inputStream);
                i.d(S, "{\n                PreferencesProto.PreferenceMap.parseFrom(input)\n            }");
                return S;
            } catch (b0 e4) {
                throw new j.a("Unable to parse preferences proto.", e4);
            }
        }
    }
}
