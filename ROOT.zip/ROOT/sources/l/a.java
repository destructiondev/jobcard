package l;

import android.content.Context;
import j.d;
import j.f;
import j3.l;
import java.util.List;
import k.b;
import kotlin.jvm.internal.i;
import kotlin.jvm.internal.j;
import s3.l0;
import s3.m0;
import s3.m2;
import s3.t1;
import s3.z0;

public final class a {

    /* renamed from: l.a$a  reason: collision with other inner class name */
    static final class C0088a extends j implements l<Context, List<? extends d<m.d>>> {

        /* renamed from: d  reason: collision with root package name */
        public static final C0088a f3636d = new C0088a();

        C0088a() {
            super(1);
        }

        /* renamed from: b */
        public final List<d<m.d>> invoke(Context context) {
            i.e(context, "it");
            return m.b();
        }
    }

    public static final k3.a<Context, f<m.d>> a(String str, b<m.d> bVar, l<? super Context, ? extends List<? extends d<m.d>>> lVar, l0 l0Var) {
        i.e(str, "name");
        i.e(lVar, "produceMigrations");
        i.e(l0Var, "scope");
        return new c(str, bVar, lVar, l0Var);
    }

    public static /* synthetic */ k3.a b(String str, b bVar, l lVar, l0 l0Var, int i4, Object obj) {
        if ((i4 & 2) != 0) {
            bVar = null;
        }
        if ((i4 & 4) != 0) {
            lVar = C0088a.f3636d;
        }
        if ((i4 & 8) != 0) {
            z0 z0Var = z0.f4324a;
            l0Var = m0.a(z0.b().H(m2.b((t1) null, 1, (Object) null)));
        }
        return a(str, bVar, lVar, l0Var);
    }
}
