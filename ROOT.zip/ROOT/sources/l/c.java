package l;

import android.content.Context;
import j.f;
import j3.l;
import java.io.File;
import java.util.List;
import k.b;
import kotlin.jvm.internal.i;
import kotlin.jvm.internal.j;
import m.d;
import o3.h;
import s3.l0;

public final class c implements k3.a<Context, f<d>> {
    /* access modifiers changed from: private */

    /* renamed from: a  reason: collision with root package name */
    public final String f3637a;

    /* renamed from: b  reason: collision with root package name */
    private final l<Context, List<j.d<d>>> f3638b;

    /* renamed from: c  reason: collision with root package name */
    private final l0 f3639c;

    /* renamed from: d  reason: collision with root package name */
    private final Object f3640d = new Object();

    /* renamed from: e  reason: collision with root package name */
    private volatile f<d> f3641e;

    static final class a extends j implements j3.a<File> {

        /* renamed from: d  reason: collision with root package name */
        final /* synthetic */ Context f3642d;

        /* renamed from: e  reason: collision with root package name */
        final /* synthetic */ c f3643e;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        a(Context context, c cVar) {
            super(0);
            this.f3642d = context;
            this.f3643e = cVar;
        }

        /* renamed from: b */
        public final File invoke() {
            Context context = this.f3642d;
            i.d(context, "applicationContext");
            return b.a(context, this.f3643e.f3637a);
        }
    }

    public c(String str, b<d> bVar, l<? super Context, ? extends List<? extends j.d<d>>> lVar, l0 l0Var) {
        i.e(str, "name");
        i.e(lVar, "produceMigrations");
        i.e(l0Var, "scope");
        this.f3637a = str;
        this.f3638b = lVar;
        this.f3639c = l0Var;
    }

    /* renamed from: c */
    public f<d> a(Context context, h<?> hVar) {
        f<d> fVar;
        i.e(context, "thisRef");
        i.e(hVar, "property");
        f<d> fVar2 = this.f3641e;
        if (fVar2 != null) {
            return fVar2;
        }
        synchronized (this.f3640d) {
            if (this.f3641e == null) {
                Context applicationContext = context.getApplicationContext();
                m.c cVar = m.c.f3675a;
                l<Context, List<j.d<d>>> lVar = this.f3638b;
                i.d(applicationContext, "applicationContext");
                this.f3641e = cVar.a((b<d>) null, lVar.invoke(applicationContext), this.f3639c, new a(applicationContext, this));
            }
            fVar = this.f3641e;
            i.b(fVar);
        }
        return fVar;
    }
}
