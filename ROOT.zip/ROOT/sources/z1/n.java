package z1;

import n1.f;

public enum n implements f {
    LOG_ENVIRONMENT_UNKNOWN(0),
    LOG_ENVIRONMENT_AUTOPUSH(1),
    LOG_ENVIRONMENT_STAGING(2),
    LOG_ENVIRONMENT_PROD(3);
    

    /* renamed from: d  reason: collision with root package name */
    private final int f5071d;

    private n(int i4) {
        this.f5071d = i4;
    }

    public int a() {
        return this.f5071d;
    }
}
