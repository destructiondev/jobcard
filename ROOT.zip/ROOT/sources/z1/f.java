package z1;

import kotlin.jvm.internal.e;
import kotlin.jvm.internal.i;

public final class f {

    /* renamed from: a  reason: collision with root package name */
    private final d f5038a;

    /* renamed from: b  reason: collision with root package name */
    private final d f5039b;

    /* renamed from: c  reason: collision with root package name */
    private final double f5040c;

    public f() {
        this((d) null, (d) null, 0.0d, 7, (e) null);
    }

    public f(d dVar, d dVar2, double d4) {
        i.e(dVar, "performance");
        i.e(dVar2, "crashlytics");
        this.f5038a = dVar;
        this.f5039b = dVar2;
        this.f5040c = d4;
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public /* synthetic */ f(d dVar, d dVar2, double d4, int i4, e eVar) {
        this((i4 & 1) != 0 ? d.COLLECTION_SDK_NOT_INSTALLED : dVar, (i4 & 2) != 0 ? d.COLLECTION_SDK_NOT_INSTALLED : dVar2, (i4 & 4) != 0 ? 1.0d : d4);
    }

    public final d a() {
        return this.f5039b;
    }

    public final d b() {
        return this.f5038a;
    }

    public final double c() {
        return this.f5040c;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof f)) {
            return false;
        }
        f fVar = (f) obj;
        return this.f5038a == fVar.f5038a && this.f5039b == fVar.f5039b && i.a(Double.valueOf(this.f5040c), Double.valueOf(fVar.f5040c));
    }

    public int hashCode() {
        return (((this.f5038a.hashCode() * 31) + this.f5039b.hashCode()) * 31) + Double.doubleToLongBits(this.f5040c);
    }

    public String toString() {
        return "DataCollectionStatus(performance=" + this.f5038a + ", crashlytics=" + this.f5039b + ", sessionSamplingRate=" + this.f5040c + ')';
    }
}
