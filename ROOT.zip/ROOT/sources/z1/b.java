package z1;

import kotlin.jvm.internal.i;

public final class b {

    /* renamed from: a  reason: collision with root package name */
    private final String f4996a;

    /* renamed from: b  reason: collision with root package name */
    private final String f4997b;

    /* renamed from: c  reason: collision with root package name */
    private final String f4998c;

    /* renamed from: d  reason: collision with root package name */
    private final String f4999d;

    /* renamed from: e  reason: collision with root package name */
    private final n f5000e;

    /* renamed from: f  reason: collision with root package name */
    private final a f5001f;

    public b(String str, String str2, String str3, String str4, n nVar, a aVar) {
        i.e(str, "appId");
        i.e(str2, "deviceModel");
        i.e(str3, "sessionSdkVersion");
        i.e(str4, "osVersion");
        i.e(nVar, "logEnvironment");
        i.e(aVar, "androidAppInfo");
        this.f4996a = str;
        this.f4997b = str2;
        this.f4998c = str3;
        this.f4999d = str4;
        this.f5000e = nVar;
        this.f5001f = aVar;
    }

    public final a a() {
        return this.f5001f;
    }

    public final String b() {
        return this.f4996a;
    }

    public final String c() {
        return this.f4997b;
    }

    public final n d() {
        return this.f5000e;
    }

    public final String e() {
        return this.f4999d;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof b)) {
            return false;
        }
        b bVar = (b) obj;
        return i.a(this.f4996a, bVar.f4996a) && i.a(this.f4997b, bVar.f4997b) && i.a(this.f4998c, bVar.f4998c) && i.a(this.f4999d, bVar.f4999d) && this.f5000e == bVar.f5000e && i.a(this.f5001f, bVar.f5001f);
    }

    public final String f() {
        return this.f4998c;
    }

    public int hashCode() {
        return (((((((((this.f4996a.hashCode() * 31) + this.f4997b.hashCode()) * 31) + this.f4998c.hashCode()) * 31) + this.f4999d.hashCode()) * 31) + this.f5000e.hashCode()) * 31) + this.f5001f.hashCode();
    }

    public String toString() {
        return "ApplicationInfo(appId=" + this.f4996a + ", deviceModel=" + this.f4997b + ", sessionSdkVersion=" + this.f4998c + ", osVersion=" + this.f4999d + ", logEnvironment=" + this.f5000e + ", androidAppInfo=" + this.f5001f + ')';
    }
}
