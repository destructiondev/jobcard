package z1;

import android.util.Log;
import kotlin.jvm.internal.e;
import kotlin.jvm.internal.i;
import q3.c;
import r1.b;
import v.g;

public final class h implements i {

    /* renamed from: b  reason: collision with root package name */
    public static final a f5042b = new a((e) null);

    /* renamed from: a  reason: collision with root package name */
    private final b<g> f5043a;

    public static final class a {
        private a() {
        }

        public /* synthetic */ a(e eVar) {
            this();
        }
    }

    public h(b<g> bVar) {
        i.e(bVar, "transportFactoryProvider");
        this.f5043a = bVar;
    }

    /* access modifiers changed from: private */
    public final byte[] c(q qVar) {
        String a4 = r.f5089a.b().a(qVar);
        i.d(a4, "SessionEvents.SESSION_EVENT_ENCODER.encode(value)");
        Log.d("EventGDTLogger", "Session Event: " + a4);
        byte[] bytes = a4.getBytes(c.f4097b);
        i.d(bytes, "this as java.lang.String).getBytes(charset)");
        return bytes;
    }

    public void a(q qVar) {
        i.e(qVar, "sessionEvent");
        this.f5043a.get().a("FIREBASE_APPQUALITY_SESSION", q.class, v.b.b("json"), new g(this)).a(v.c.d(qVar));
    }
}
