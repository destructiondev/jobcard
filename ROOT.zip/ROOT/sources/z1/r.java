package z1;

import a2.b;
import android.content.Context;
import android.content.pm.PackageInfo;
import android.os.Build;
import b2.f;
import java.util.Map;
import kotlin.jvm.internal.i;
import l1.a;
import n1.d;
import r0.e;

public final class r {

    /* renamed from: a  reason: collision with root package name */
    public static final r f5089a = new r();

    /* renamed from: b  reason: collision with root package name */
    private static final a f5090b;

    static {
        a i4 = new d().j(c.f5002a).k(true).i();
        i.d(i4, "JsonDataEncoderBuilder()…lues(true)\n      .build()");
        f5090b = i4;
    }

    private r() {
    }

    private final d d(b bVar) {
        return bVar == null ? d.COLLECTION_SDK_NOT_INSTALLED : bVar.c() ? d.COLLECTION_ENABLED : d.COLLECTION_DISABLED;
    }

    public final b a(e eVar) {
        i.e(eVar, "firebaseApp");
        Context m4 = eVar.m();
        i.d(m4, "firebaseApp.applicationContext");
        String packageName = m4.getPackageName();
        PackageInfo packageInfo = m4.getPackageManager().getPackageInfo(packageName, 0);
        String valueOf = Build.VERSION.SDK_INT >= 28 ? String.valueOf(packageInfo.getLongVersionCode()) : String.valueOf(packageInfo.versionCode);
        String c4 = eVar.r().c();
        i.d(c4, "firebaseApp.options.applicationId");
        String str = Build.MODEL;
        i.d(str, "MODEL");
        String str2 = Build.VERSION.RELEASE;
        i.d(str2, "RELEASE");
        n nVar = n.LOG_ENVIRONMENT_PROD;
        i.d(packageName, "packageName");
        String str3 = packageInfo.versionName;
        if (str3 == null) {
            str3 = valueOf;
        }
        String str4 = Build.MANUFACTURER;
        i.d(str4, "MANUFACTURER");
        return new b(c4, str, "1.0.2", str2, nVar, new a(packageName, str3, valueOf, str4));
    }

    public final a b() {
        return f5090b;
    }

    public final q c(e eVar, p pVar, f fVar, Map<b.a, ? extends b> map) {
        Map<b.a, ? extends b> map2 = map;
        i.e(eVar, "firebaseApp");
        i.e(pVar, "sessionDetails");
        i.e(fVar, "sessionsSettings");
        i.e(map2, "subscribers");
        j jVar = j.SESSION_START;
        t tVar = r7;
        t tVar2 = new t(pVar.b(), pVar.a(), pVar.c(), pVar.d(), new f(d((b) map2.get(b.a.PERFORMANCE)), d((b) map2.get(b.a.CRASHLYTICS)), fVar.b()), (String) null, 32, (kotlin.jvm.internal.e) null);
        return new q(jVar, tVar, a(eVar));
    }
}
