package z1;

import kotlin.jvm.internal.e;
import kotlin.jvm.internal.i;
import r3.a;

public final class t {

    /* renamed from: a  reason: collision with root package name */
    private final String f5098a;

    /* renamed from: b  reason: collision with root package name */
    private final String f5099b;

    /* renamed from: c  reason: collision with root package name */
    private final int f5100c;

    /* renamed from: d  reason: collision with root package name */
    private long f5101d;

    /* renamed from: e  reason: collision with root package name */
    private f f5102e;

    /* renamed from: f  reason: collision with root package name */
    private String f5103f;

    public t(String str, String str2, int i4, long j4, f fVar, String str3) {
        i.e(str, "sessionId");
        i.e(str2, "firstSessionId");
        i.e(fVar, "dataCollectionStatus");
        i.e(str3, "firebaseInstallationId");
        this.f5098a = str;
        this.f5099b = str2;
        this.f5100c = i4;
        this.f5101d = j4;
        this.f5102e = fVar;
        this.f5103f = str3;
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public /* synthetic */ t(String str, String str2, int i4, long j4, f fVar, String str3, int i5, e eVar) {
        this(str, str2, i4, j4, (i5 & 16) != 0 ? new f((d) null, (d) null, 0.0d, 7, (e) null) : fVar, (i5 & 32) != 0 ? "" : str3);
    }

    public final f a() {
        return this.f5102e;
    }

    public final long b() {
        return this.f5101d;
    }

    public final String c() {
        return this.f5103f;
    }

    public final String d() {
        return this.f5099b;
    }

    public final String e() {
        return this.f5098a;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof t)) {
            return false;
        }
        t tVar = (t) obj;
        return i.a(this.f5098a, tVar.f5098a) && i.a(this.f5099b, tVar.f5099b) && this.f5100c == tVar.f5100c && this.f5101d == tVar.f5101d && i.a(this.f5102e, tVar.f5102e) && i.a(this.f5103f, tVar.f5103f);
    }

    public final int f() {
        return this.f5100c;
    }

    public final void g(String str) {
        i.e(str, "<set-?>");
        this.f5103f = str;
    }

    public int hashCode() {
        return (((((((((this.f5098a.hashCode() * 31) + this.f5099b.hashCode()) * 31) + this.f5100c) * 31) + a.a(this.f5101d)) * 31) + this.f5102e.hashCode()) * 31) + this.f5103f.hashCode();
    }

    public String toString() {
        return "SessionInfo(sessionId=" + this.f5098a + ", firstSessionId=" + this.f5099b + ", sessionIndex=" + this.f5100c + ", eventTimestampUs=" + this.f5101d + ", dataCollectionStatus=" + this.f5102e + ", firebaseInstallationId=" + this.f5103f + ')';
    }
}
