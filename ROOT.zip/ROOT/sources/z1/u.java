package z1;

import a3.s;
import c3.d;

public interface u {
    Object a(p pVar, d<? super s> dVar);
}
