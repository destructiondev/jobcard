package z1;

public interface x {
    long a();

    long b();
}
