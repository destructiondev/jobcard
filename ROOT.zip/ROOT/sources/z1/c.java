package z1;

public final class c implements m1.a {

    /* renamed from: a  reason: collision with root package name */
    public static final m1.a f5002a = new c();

    private static final class a implements l1.d<a> {

        /* renamed from: a  reason: collision with root package name */
        static final a f5003a = new a();

        /* renamed from: b  reason: collision with root package name */
        private static final l1.c f5004b = l1.c.d("packageName");

        /* renamed from: c  reason: collision with root package name */
        private static final l1.c f5005c = l1.c.d("versionName");

        /* renamed from: d  reason: collision with root package name */
        private static final l1.c f5006d = l1.c.d("appBuildVersion");

        /* renamed from: e  reason: collision with root package name */
        private static final l1.c f5007e = l1.c.d("deviceManufacturer");

        private a() {
        }

        /* renamed from: b */
        public void a(a aVar, l1.e eVar) {
            eVar.f(f5004b, aVar.c());
            eVar.f(f5005c, aVar.d());
            eVar.f(f5006d, aVar.a());
            eVar.f(f5007e, aVar.b());
        }
    }

    private static final class b implements l1.d<b> {

        /* renamed from: a  reason: collision with root package name */
        static final b f5008a = new b();

        /* renamed from: b  reason: collision with root package name */
        private static final l1.c f5009b = l1.c.d("appId");

        /* renamed from: c  reason: collision with root package name */
        private static final l1.c f5010c = l1.c.d("deviceModel");

        /* renamed from: d  reason: collision with root package name */
        private static final l1.c f5011d = l1.c.d("sessionSdkVersion");

        /* renamed from: e  reason: collision with root package name */
        private static final l1.c f5012e = l1.c.d("osVersion");

        /* renamed from: f  reason: collision with root package name */
        private static final l1.c f5013f = l1.c.d("logEnvironment");

        /* renamed from: g  reason: collision with root package name */
        private static final l1.c f5014g = l1.c.d("androidAppInfo");

        private b() {
        }

        /* renamed from: b */
        public void a(b bVar, l1.e eVar) {
            eVar.f(f5009b, bVar.b());
            eVar.f(f5010c, bVar.c());
            eVar.f(f5011d, bVar.f());
            eVar.f(f5012e, bVar.e());
            eVar.f(f5013f, bVar.d());
            eVar.f(f5014g, bVar.a());
        }
    }

    /* renamed from: z1.c$c  reason: collision with other inner class name */
    private static final class C0121c implements l1.d<f> {

        /* renamed from: a  reason: collision with root package name */
        static final C0121c f5015a = new C0121c();

        /* renamed from: b  reason: collision with root package name */
        private static final l1.c f5016b = l1.c.d("performance");

        /* renamed from: c  reason: collision with root package name */
        private static final l1.c f5017c = l1.c.d("crashlytics");

        /* renamed from: d  reason: collision with root package name */
        private static final l1.c f5018d = l1.c.d("sessionSamplingRate");

        private C0121c() {
        }

        /* renamed from: b */
        public void a(f fVar, l1.e eVar) {
            eVar.f(f5016b, fVar.b());
            eVar.f(f5017c, fVar.a());
            eVar.g(f5018d, fVar.c());
        }
    }

    private static final class d implements l1.d<q> {

        /* renamed from: a  reason: collision with root package name */
        static final d f5019a = new d();

        /* renamed from: b  reason: collision with root package name */
        private static final l1.c f5020b = l1.c.d("eventType");

        /* renamed from: c  reason: collision with root package name */
        private static final l1.c f5021c = l1.c.d("sessionData");

        /* renamed from: d  reason: collision with root package name */
        private static final l1.c f5022d = l1.c.d("applicationInfo");

        private d() {
        }

        /* renamed from: b */
        public void a(q qVar, l1.e eVar) {
            eVar.f(f5020b, qVar.b());
            eVar.f(f5021c, qVar.c());
            eVar.f(f5022d, qVar.a());
        }
    }

    private static final class e implements l1.d<t> {

        /* renamed from: a  reason: collision with root package name */
        static final e f5023a = new e();

        /* renamed from: b  reason: collision with root package name */
        private static final l1.c f5024b = l1.c.d("sessionId");

        /* renamed from: c  reason: collision with root package name */
        private static final l1.c f5025c = l1.c.d("firstSessionId");

        /* renamed from: d  reason: collision with root package name */
        private static final l1.c f5026d = l1.c.d("sessionIndex");

        /* renamed from: e  reason: collision with root package name */
        private static final l1.c f5027e = l1.c.d("eventTimestampUs");

        /* renamed from: f  reason: collision with root package name */
        private static final l1.c f5028f = l1.c.d("dataCollectionStatus");

        /* renamed from: g  reason: collision with root package name */
        private static final l1.c f5029g = l1.c.d("firebaseInstallationId");

        private e() {
        }

        /* renamed from: b */
        public void a(t tVar, l1.e eVar) {
            eVar.f(f5024b, tVar.e());
            eVar.f(f5025c, tVar.d());
            eVar.d(f5026d, tVar.f());
            eVar.e(f5027e, tVar.b());
            eVar.f(f5028f, tVar.a());
            eVar.f(f5029g, tVar.c());
        }
    }

    private c() {
    }

    public void a(m1.b<?> bVar) {
        bVar.a(q.class, d.f5019a);
        bVar.a(t.class, e.f5023a);
        bVar.a(f.class, C0121c.f5015a);
        bVar.a(b.class, b.f5008a);
        bVar.a(a.class, a.f5003a);
    }
}
