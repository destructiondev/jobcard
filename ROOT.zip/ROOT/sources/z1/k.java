package z1;

import android.content.Context;
import r0.f;
import r0.l;

public final /* synthetic */ class k implements f {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ Context f5048a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ v f5049b;

    public /* synthetic */ k(Context context, v vVar) {
        this.f5048a = context;
        this.f5049b = vVar;
    }

    public final void a(String str, l lVar) {
        l.b(this.f5048a, this.f5049b, str, lVar);
    }
}
