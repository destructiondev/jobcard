package z1;

import com.google.firebase.sessions.FirebaseSessionsRegistrar;
import u0.e;
import u0.h;

public final /* synthetic */ class m implements h {

    /* renamed from: a  reason: collision with root package name */
    public static final /* synthetic */ m f5065a = new m();

    private /* synthetic */ m() {
    }

    public final Object a(e eVar) {
        return FirebaseSessionsRegistrar.m8getComponents$lambda0(eVar);
    }
}
