package z1;

import a2.b;
import a3.s;
import android.app.Application;
import android.content.Context;
import android.util.Log;
import b2.f;
import kotlin.coroutines.jvm.internal.d;
import kotlin.jvm.internal.e;
import kotlin.jvm.internal.i;
import s3.h0;
import v.g;

public final class l {

    /* renamed from: h  reason: collision with root package name */
    public static final a f5050h = new a((e) null);

    /* renamed from: a  reason: collision with root package name */
    private final r0.e f5051a;

    /* renamed from: b  reason: collision with root package name */
    private final b f5052b;

    /* renamed from: c  reason: collision with root package name */
    private final f f5053c;

    /* renamed from: d  reason: collision with root package name */
    private final x f5054d;

    /* renamed from: e  reason: collision with root package name */
    private final s f5055e;

    /* renamed from: f  reason: collision with root package name */
    private final h f5056f;

    /* renamed from: g  reason: collision with root package name */
    private final o f5057g;

    public static final class a {
        private a() {
        }

        public /* synthetic */ a(e eVar) {
            this();
        }
    }

    @kotlin.coroutines.jvm.internal.f(c = "com.google.firebase.sessions.FirebaseSessions", f = "FirebaseSessions.kt", l = {111, 134, 149}, m = "initiateSessionStart")
    static final class b extends d {

        /* renamed from: d  reason: collision with root package name */
        Object f5058d;

        /* renamed from: e  reason: collision with root package name */
        Object f5059e;

        /* renamed from: f  reason: collision with root package name */
        Object f5060f;

        /* renamed from: g  reason: collision with root package name */
        /* synthetic */ Object f5061g;

        /* renamed from: h  reason: collision with root package name */
        final /* synthetic */ l f5062h;

        /* renamed from: i  reason: collision with root package name */
        int f5063i;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        b(l lVar, c3.d<? super b> dVar) {
            super(dVar);
            this.f5062h = lVar;
        }

        public final Object invokeSuspend(Object obj) {
            this.f5061g = obj;
            this.f5063i |= Integer.MIN_VALUE;
            return this.f5062h.d((p) null, this);
        }
    }

    public static final class c implements u {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ l f5064a;

        c(l lVar) {
            this.f5064a = lVar;
        }

        public Object a(p pVar, c3.d<? super s> dVar) {
            Object c4 = this.f5064a.d(pVar, dVar);
            return c4 == d.c() ? c4 : s.f271a;
        }
    }

    public l(r0.e eVar, s1.d dVar, h0 h0Var, h0 h0Var2, r1.b<g> bVar) {
        r0.e eVar2 = eVar;
        s1.d dVar2 = dVar;
        r1.b<g> bVar2 = bVar;
        i.e(eVar2, "firebaseApp");
        i.e(dVar2, "firebaseInstallations");
        i.e(h0Var, "backgroundDispatcher");
        h0 h0Var3 = h0Var2;
        i.e(h0Var3, "blockingDispatcher");
        i.e(bVar2, "transportFactoryProvider");
        this.f5051a = eVar2;
        b a4 = r.f5089a.a(eVar2);
        this.f5052b = a4;
        Context m4 = eVar.m();
        i.d(m4, "firebaseApp.applicationContext");
        h0 h0Var4 = h0Var;
        f fVar = new f(m4, h0Var3, h0Var4, dVar, a4);
        this.f5053c = fVar;
        w wVar = new w();
        this.f5054d = wVar;
        h hVar = new h(bVar2);
        this.f5056f = hVar;
        this.f5057g = new o(dVar2, hVar);
        s sVar = new s(f(), wVar, (j3.a) null, 4, (e) null);
        this.f5055e = sVar;
        v vVar = new v(wVar, h0Var4, new c(this), fVar, sVar);
        Context applicationContext = eVar.m().getApplicationContext();
        if (applicationContext instanceof Application) {
            ((Application) applicationContext).registerActivityLifecycleCallbacks(vVar.d());
            eVar2.h(new k(applicationContext, vVar));
            return;
        }
        Log.e("FirebaseSessions", "Failed to register lifecycle callbacks, unexpected context " + applicationContext.getClass() + '.');
    }

    /* access modifiers changed from: private */
    public static final void b(Context context, v vVar, String str, r0.l lVar) {
        i.e(vVar, "$sessionInitiator");
        Log.w("FirebaseSessions", "FirebaseApp instance deleted. Sessions library will not collect session data.");
        ((Application) context).unregisterActivityLifecycleCallbacks(vVar.d());
    }

    /* access modifiers changed from: private */
    /* JADX WARNING: Removed duplicated region for block: B:18:0x005a  */
    /* JADX WARNING: Removed duplicated region for block: B:24:0x0075  */
    /* JADX WARNING: Removed duplicated region for block: B:27:0x007d  */
    /* JADX WARNING: Removed duplicated region for block: B:49:0x00ea  */
    /* JADX WARNING: Removed duplicated region for block: B:50:0x00ed  */
    /* JADX WARNING: Removed duplicated region for block: B:8:0x0027  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final java.lang.Object d(z1.p r12, c3.d<? super a3.s> r13) {
        /*
            r11 = this;
            boolean r0 = r13 instanceof z1.l.b
            if (r0 == 0) goto L_0x0013
            r0 = r13
            z1.l$b r0 = (z1.l.b) r0
            int r1 = r0.f5063i
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L_0x0013
            int r1 = r1 - r2
            r0.f5063i = r1
            goto L_0x0018
        L_0x0013:
            z1.l$b r0 = new z1.l$b
            r0.<init>(r11, r13)
        L_0x0018:
            java.lang.Object r13 = r0.f5061g
            java.lang.Object r1 = d3.d.c()
            int r2 = r0.f5063i
            r3 = 3
            r4 = 2
            r5 = 1
            java.lang.String r6 = "FirebaseSessions"
            if (r2 == 0) goto L_0x005a
            if (r2 == r5) goto L_0x004e
            if (r2 == r4) goto L_0x003d
            if (r2 != r3) goto L_0x0035
            a3.n.b(r13)     // Catch:{ IllegalStateException -> 0x0032 }
            goto L_0x011a
        L_0x0032:
            r12 = move-exception
            goto L_0x0115
        L_0x0035:
            java.lang.IllegalStateException r12 = new java.lang.IllegalStateException
            java.lang.String r13 = "call to 'resume' before 'invoke' with coroutine"
            r12.<init>(r13)
            throw r12
        L_0x003d:
            java.lang.Object r12 = r0.f5060f
            java.util.Map r12 = (java.util.Map) r12
            java.lang.Object r2 = r0.f5059e
            z1.p r2 = (z1.p) r2
            java.lang.Object r4 = r0.f5058d
            z1.l r4 = (z1.l) r4
            a3.n.b(r13)
            goto L_0x00e2
        L_0x004e:
            java.lang.Object r12 = r0.f5059e
            z1.p r12 = (z1.p) r12
            java.lang.Object r2 = r0.f5058d
            z1.l r2 = (z1.l) r2
            a3.n.b(r13)
            goto L_0x006d
        L_0x005a:
            a3.n.b(r13)
            a2.a r13 = a2.a.f238a
            r0.f5058d = r11
            r0.f5059e = r12
            r0.f5063i = r5
            java.lang.Object r13 = r13.c(r0)
            if (r13 != r1) goto L_0x006c
            return r1
        L_0x006c:
            r2 = r11
        L_0x006d:
            java.util.Map r13 = (java.util.Map) r13
            boolean r7 = r13.isEmpty()
            if (r7 == 0) goto L_0x007d
            java.lang.String r12 = "Sessions SDK did not have any dependent SDKs register as dependencies. Events will not be sent."
        L_0x0077:
            android.util.Log.d(r6, r12)
            a3.s r12 = a3.s.f271a
            return r12
        L_0x007d:
            java.util.Collection r7 = r13.values()
            java.util.Iterator r7 = r7.iterator()
        L_0x0085:
            boolean r8 = r7.hasNext()
            if (r8 == 0) goto L_0x009e
            java.lang.Object r8 = r7.next()
            a2.b r8 = (a2.b) r8
            a2.b$b r9 = new a2.b$b
            java.lang.String r10 = r12.b()
            r9.<init>(r10)
            r8.b(r9)
            goto L_0x0085
        L_0x009e:
            java.util.Collection r7 = r13.values()
            boolean r8 = r7 instanceof java.util.Collection
            if (r8 == 0) goto L_0x00ad
            boolean r8 = r7.isEmpty()
            if (r8 == 0) goto L_0x00ad
            goto L_0x00c4
        L_0x00ad:
            java.util.Iterator r7 = r7.iterator()
        L_0x00b1:
            boolean r8 = r7.hasNext()
            if (r8 == 0) goto L_0x00c4
            java.lang.Object r8 = r7.next()
            a2.b r8 = (a2.b) r8
            boolean r8 = r8.c()
            if (r8 == 0) goto L_0x00b1
            r5 = 0
        L_0x00c4:
            if (r5 == 0) goto L_0x00c9
            java.lang.String r12 = "Data Collection is disabled for all subscribers. Skipping this Session Event"
            goto L_0x0077
        L_0x00c9:
            java.lang.String r5 = "Data Collection is enabled for at least one Subscriber"
            android.util.Log.d(r6, r5)
            b2.f r5 = r2.f5053c
            r0.f5058d = r2
            r0.f5059e = r12
            r0.f5060f = r13
            r0.f5063i = r4
            java.lang.Object r4 = r5.g(r0)
            if (r4 != r1) goto L_0x00df
            return r1
        L_0x00df:
            r4 = r2
            r2 = r12
            r12 = r13
        L_0x00e2:
            b2.f r13 = r4.f5053c
            boolean r13 = r13.d()
            if (r13 != 0) goto L_0x00ed
            java.lang.String r12 = "Sessions SDK disabled. Events will not be sent."
            goto L_0x0077
        L_0x00ed:
            z1.s r13 = r4.f5055e
            boolean r13 = r13.c()
            if (r13 != 0) goto L_0x00f9
            java.lang.String r12 = "Sessions SDK has dropped this session due to sampling."
            goto L_0x0077
        L_0x00f9:
            z1.r r13 = z1.r.f5089a     // Catch:{ IllegalStateException -> 0x0032 }
            r0.e r5 = r4.f5051a     // Catch:{ IllegalStateException -> 0x0032 }
            b2.f r7 = r4.f5053c     // Catch:{ IllegalStateException -> 0x0032 }
            z1.q r12 = r13.c(r5, r2, r7, r12)     // Catch:{ IllegalStateException -> 0x0032 }
            z1.o r13 = r4.f5057g     // Catch:{ IllegalStateException -> 0x0032 }
            r2 = 0
            r0.f5058d = r2     // Catch:{ IllegalStateException -> 0x0032 }
            r0.f5059e = r2     // Catch:{ IllegalStateException -> 0x0032 }
            r0.f5060f = r2     // Catch:{ IllegalStateException -> 0x0032 }
            r0.f5063i = r3     // Catch:{ IllegalStateException -> 0x0032 }
            java.lang.Object r12 = r13.a(r12, r0)     // Catch:{ IllegalStateException -> 0x0032 }
            if (r12 != r1) goto L_0x011a
            return r1
        L_0x0115:
            java.lang.String r13 = "FirebaseApp is not initialized. Sessions library will not collect session data."
            android.util.Log.w(r6, r13, r12)
        L_0x011a:
            a3.s r12 = a3.s.f271a
            return r12
        */
        throw new UnsupportedOperationException("Method not decompiled: z1.l.d(z1.p, c3.d):java.lang.Object");
    }

    private final boolean f() {
        return Math.random() <= this.f5053c.b();
    }

    public final void e(a2.b bVar) {
        i.e(bVar, "subscriber");
        a2.a.f238a.e(bVar);
        Log.d("FirebaseSessions", "Registering Sessions SDK subscriber with name: " + bVar.a() + ", data collection enabled: " + bVar.c());
        if (this.f5055e.e()) {
            bVar.b(new b.C0004b(this.f5055e.d().b()));
        }
    }
}
