package z1;

import kotlin.jvm.internal.i;

public final class a {

    /* renamed from: a  reason: collision with root package name */
    private final String f4992a;

    /* renamed from: b  reason: collision with root package name */
    private final String f4993b;

    /* renamed from: c  reason: collision with root package name */
    private final String f4994c;

    /* renamed from: d  reason: collision with root package name */
    private final String f4995d;

    public a(String str, String str2, String str3, String str4) {
        i.e(str, "packageName");
        i.e(str2, "versionName");
        i.e(str3, "appBuildVersion");
        i.e(str4, "deviceManufacturer");
        this.f4992a = str;
        this.f4993b = str2;
        this.f4994c = str3;
        this.f4995d = str4;
    }

    public final String a() {
        return this.f4994c;
    }

    public final String b() {
        return this.f4995d;
    }

    public final String c() {
        return this.f4992a;
    }

    public final String d() {
        return this.f4993b;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof a)) {
            return false;
        }
        a aVar = (a) obj;
        return i.a(this.f4992a, aVar.f4992a) && i.a(this.f4993b, aVar.f4993b) && i.a(this.f4994c, aVar.f4994c) && i.a(this.f4995d, aVar.f4995d);
    }

    public int hashCode() {
        return (((((this.f4992a.hashCode() * 31) + this.f4993b.hashCode()) * 31) + this.f4994c.hashCode()) * 31) + this.f4995d.hashCode();
    }

    public String toString() {
        return "AndroidApplicationInfo(packageName=" + this.f4992a + ", versionName=" + this.f4993b + ", appBuildVersion=" + this.f4994c + ", deviceManufacturer=" + this.f4995d + ')';
    }
}
