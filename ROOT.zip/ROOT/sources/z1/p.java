package z1;

import kotlin.jvm.internal.i;
import r3.a;

public final class p {

    /* renamed from: a  reason: collision with root package name */
    private final String f5082a;

    /* renamed from: b  reason: collision with root package name */
    private final String f5083b;

    /* renamed from: c  reason: collision with root package name */
    private final int f5084c;

    /* renamed from: d  reason: collision with root package name */
    private final long f5085d;

    public p(String str, String str2, int i4, long j4) {
        i.e(str, "sessionId");
        i.e(str2, "firstSessionId");
        this.f5082a = str;
        this.f5083b = str2;
        this.f5084c = i4;
        this.f5085d = j4;
    }

    public final String a() {
        return this.f5083b;
    }

    public final String b() {
        return this.f5082a;
    }

    public final int c() {
        return this.f5084c;
    }

    public final long d() {
        return this.f5085d;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof p)) {
            return false;
        }
        p pVar = (p) obj;
        return i.a(this.f5082a, pVar.f5082a) && i.a(this.f5083b, pVar.f5083b) && this.f5084c == pVar.f5084c && this.f5085d == pVar.f5085d;
    }

    public int hashCode() {
        return (((((this.f5082a.hashCode() * 31) + this.f5083b.hashCode()) * 31) + this.f5084c) * 31) + a.a(this.f5085d);
    }

    public String toString() {
        return "SessionDetails(sessionId=" + this.f5082a + ", firstSessionId=" + this.f5083b + ", sessionIndex=" + this.f5084c + ", sessionStartTimestampUs=" + this.f5085d + ')';
    }
}
