package z1;

import n1.f;

public enum j implements f {
    EVENT_TYPE_UNKNOWN(0),
    SESSION_START(1);
    

    /* renamed from: d  reason: collision with root package name */
    private final int f5047d;

    private j(int i4) {
        this.f5047d = i4;
    }

    public int a() {
        return this.f5047d;
    }
}
