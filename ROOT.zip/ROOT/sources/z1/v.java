package z1;

import a3.n;
import a3.s;
import android.app.Activity;
import android.app.Application;
import android.os.Bundle;
import b2.f;
import c3.d;
import c3.g;
import j3.p;
import kotlin.coroutines.jvm.internal.k;
import kotlin.jvm.internal.i;
import s3.l0;
import s3.m0;
import s3.n0;
import s3.t1;

public final class v {

    /* renamed from: a  reason: collision with root package name */
    private final x f5104a;

    /* renamed from: b  reason: collision with root package name */
    private final g f5105b;
    /* access modifiers changed from: private */

    /* renamed from: c  reason: collision with root package name */
    public final u f5106c;

    /* renamed from: d  reason: collision with root package name */
    private final f f5107d;

    /* renamed from: e  reason: collision with root package name */
    private final s f5108e;

    /* renamed from: f  reason: collision with root package name */
    private long f5109f;

    /* renamed from: g  reason: collision with root package name */
    private final Application.ActivityLifecycleCallbacks f5110g = new a(this);

    public static final class a implements Application.ActivityLifecycleCallbacks {

        /* renamed from: d  reason: collision with root package name */
        final /* synthetic */ v f5111d;

        a(v vVar) {
            this.f5111d = vVar;
        }

        public void onActivityCreated(Activity activity, Bundle bundle) {
            i.e(activity, "activity");
        }

        public void onActivityDestroyed(Activity activity) {
            i.e(activity, "activity");
        }

        public void onActivityPaused(Activity activity) {
            i.e(activity, "activity");
            this.f5111d.b();
        }

        public void onActivityResumed(Activity activity) {
            i.e(activity, "activity");
            this.f5111d.c();
        }

        public void onActivitySaveInstanceState(Activity activity, Bundle bundle) {
            i.e(activity, "activity");
            i.e(bundle, "outState");
        }

        public void onActivityStarted(Activity activity) {
            i.e(activity, "activity");
        }

        public void onActivityStopped(Activity activity) {
            i.e(activity, "activity");
        }
    }

    @kotlin.coroutines.jvm.internal.f(c = "com.google.firebase.sessions.SessionInitiator$initiateSession$1", f = "SessionInitiator.kt", l = {63}, m = "invokeSuspend")
    static final class b extends k implements p<l0, d<? super s>, Object> {

        /* renamed from: d  reason: collision with root package name */
        int f5112d;

        /* renamed from: e  reason: collision with root package name */
        final /* synthetic */ v f5113e;

        /* renamed from: f  reason: collision with root package name */
        final /* synthetic */ p f5114f;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        b(v vVar, p pVar, d<? super b> dVar) {
            super(2, dVar);
            this.f5113e = vVar;
            this.f5114f = pVar;
        }

        public final d<s> create(Object obj, d<?> dVar) {
            return new b(this.f5113e, this.f5114f, dVar);
        }

        public final Object invoke(l0 l0Var, d<? super s> dVar) {
            return ((b) create(l0Var, dVar)).invokeSuspend(s.f271a);
        }

        public final Object invokeSuspend(Object obj) {
            Object c4 = d.c();
            int i4 = this.f5112d;
            if (i4 == 0) {
                n.b(obj);
                u a4 = this.f5113e.f5106c;
                p pVar = this.f5114f;
                this.f5112d = 1;
                if (a4.a(pVar, this) == c4) {
                    return c4;
                }
            } else if (i4 == 1) {
                n.b(obj);
            } else {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            return s.f271a;
        }
    }

    public v(x xVar, g gVar, u uVar, f fVar, s sVar) {
        i.e(xVar, "timeProvider");
        i.e(gVar, "backgroundDispatcher");
        i.e(uVar, "sessionInitiateListener");
        i.e(fVar, "sessionsSettings");
        i.e(sVar, "sessionGenerator");
        this.f5104a = xVar;
        this.f5105b = gVar;
        this.f5106c = uVar;
        this.f5107d = fVar;
        this.f5108e = sVar;
        this.f5109f = xVar.a();
        e();
    }

    private final void e() {
        t1 unused = j.b(m0.a(this.f5105b), (g) null, (n0) null, new b(this, this.f5108e.a(), (d<? super b>) null), 3, (Object) null);
    }

    public final void b() {
        this.f5109f = this.f5104a.a();
    }

    public final void c() {
        if (r3.b.h(r3.b.F(this.f5104a.a(), this.f5109f), this.f5107d.c()) > 0) {
            e();
        }
    }

    public final Application.ActivityLifecycleCallbacks d() {
        return this.f5110g;
    }
}
