package z1;

public final /* synthetic */ class e {
}
