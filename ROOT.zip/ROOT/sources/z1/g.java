package z1;

import v.e;

public final /* synthetic */ class g implements e {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ h f5041a;

    public /* synthetic */ g(h hVar) {
        this.f5041a = hVar;
    }

    public final Object a(Object obj) {
        return this.f5041a.c((q) obj);
    }
}
