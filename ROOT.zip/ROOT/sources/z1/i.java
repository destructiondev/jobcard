package z1;

public interface i {
    void a(q qVar);
}
