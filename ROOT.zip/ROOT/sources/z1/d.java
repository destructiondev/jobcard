package z1;

import n1.f;

public enum d implements f {
    COLLECTION_UNKNOWN(0),
    COLLECTION_SDK_NOT_INSTALLED(1),
    COLLECTION_ENABLED(2),
    COLLECTION_DISABLED(3),
    COLLECTION_DISABLED_REMOTE(4),
    COLLECTION_SAMPLED(5);
    

    /* renamed from: d  reason: collision with root package name */
    private final int f5037d;

    private d(int i4) {
        this.f5037d = i4;
    }

    public int a() {
        return this.f5037d;
    }
}
