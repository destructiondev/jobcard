package z1;

import kotlin.coroutines.jvm.internal.f;
import kotlin.jvm.internal.e;
import kotlin.jvm.internal.i;
import s1.d;

public final class o {

    /* renamed from: c  reason: collision with root package name */
    public static final a f5072c = new a((e) null);

    /* renamed from: a  reason: collision with root package name */
    private final d f5073a;

    /* renamed from: b  reason: collision with root package name */
    private final i f5074b;

    public static final class a {
        private a() {
        }

        public /* synthetic */ a(e eVar) {
            this();
        }
    }

    @f(c = "com.google.firebase.sessions.SessionCoordinator", f = "SessionCoordinator.kt", l = {36}, m = "attemptLoggingSessionEvent")
    static final class b extends kotlin.coroutines.jvm.internal.d {

        /* renamed from: d  reason: collision with root package name */
        Object f5075d;

        /* renamed from: e  reason: collision with root package name */
        Object f5076e;

        /* renamed from: f  reason: collision with root package name */
        Object f5077f;

        /* renamed from: g  reason: collision with root package name */
        Object f5078g;

        /* renamed from: h  reason: collision with root package name */
        /* synthetic */ Object f5079h;

        /* renamed from: i  reason: collision with root package name */
        final /* synthetic */ o f5080i;

        /* renamed from: j  reason: collision with root package name */
        int f5081j;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        b(o oVar, c3.d<? super b> dVar) {
            super(dVar);
            this.f5080i = oVar;
        }

        public final Object invokeSuspend(Object obj) {
            this.f5079h = obj;
            this.f5081j |= Integer.MIN_VALUE;
            return this.f5080i.a((q) null, this);
        }
    }

    public o(d dVar, i iVar) {
        i.e(dVar, "firebaseInstallations");
        i.e(iVar, "eventGDTLogger");
        this.f5073a = dVar;
        this.f5074b = iVar;
    }

    /* JADX WARNING: Removed duplicated region for block: B:15:0x0045  */
    /* JADX WARNING: Removed duplicated region for block: B:8:0x0025  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final java.lang.Object a(z1.q r7, c3.d<? super a3.s> r8) {
        /*
            r6 = this;
            boolean r0 = r8 instanceof z1.o.b
            if (r0 == 0) goto L_0x0013
            r0 = r8
            z1.o$b r0 = (z1.o.b) r0
            int r1 = r0.f5081j
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L_0x0013
            int r1 = r1 - r2
            r0.f5081j = r1
            goto L_0x0018
        L_0x0013:
            z1.o$b r0 = new z1.o$b
            r0.<init>(r6, r8)
        L_0x0018:
            java.lang.Object r8 = r0.f5079h
            java.lang.Object r1 = d3.d.c()
            int r2 = r0.f5081j
            r3 = 1
            java.lang.String r4 = "SessionCoordinator"
            if (r2 == 0) goto L_0x0045
            if (r2 != r3) goto L_0x003d
            java.lang.Object r7 = r0.f5078g
            z1.t r7 = (z1.t) r7
            java.lang.Object r1 = r0.f5077f
            z1.t r1 = (z1.t) r1
            java.lang.Object r2 = r0.f5076e
            z1.q r2 = (z1.q) r2
            java.lang.Object r0 = r0.f5075d
            z1.o r0 = (z1.o) r0
            a3.n.b(r8)     // Catch:{ Exception -> 0x003b }
            goto L_0x006d
        L_0x003b:
            r7 = move-exception
            goto L_0x007a
        L_0x003d:
            java.lang.IllegalStateException r7 = new java.lang.IllegalStateException
            java.lang.String r8 = "call to 'resume' before 'invoke' with coroutine"
            r7.<init>(r8)
            throw r7
        L_0x0045:
            a3.n.b(r8)
            z1.t r8 = r7.c()
            s1.d r2 = r6.f5073a     // Catch:{ Exception -> 0x0075 }
            p0.j r2 = r2.a()     // Catch:{ Exception -> 0x0075 }
            java.lang.String r5 = "firebaseInstallations.id"
            kotlin.jvm.internal.i.d(r2, r5)     // Catch:{ Exception -> 0x0075 }
            r0.f5075d = r6     // Catch:{ Exception -> 0x0075 }
            r0.f5076e = r7     // Catch:{ Exception -> 0x0075 }
            r0.f5077f = r8     // Catch:{ Exception -> 0x0075 }
            r0.f5078g = r8     // Catch:{ Exception -> 0x0075 }
            r0.f5081j = r3     // Catch:{ Exception -> 0x0075 }
            java.lang.Object r0 = x3.b.a(r2, r0)     // Catch:{ Exception -> 0x0075 }
            if (r0 != r1) goto L_0x0068
            return r1
        L_0x0068:
            r2 = r7
            r7 = r8
            r1 = r7
            r8 = r0
            r0 = r6
        L_0x006d:
            java.lang.String r3 = "{\n        firebaseInstallations.id.await()\n      }"
            kotlin.jvm.internal.i.d(r8, r3)     // Catch:{ Exception -> 0x003b }
            java.lang.String r8 = (java.lang.String) r8     // Catch:{ Exception -> 0x003b }
            goto L_0x0096
        L_0x0075:
            r0 = move-exception
            r2 = r7
            r1 = r8
            r7 = r0
            r0 = r6
        L_0x007a:
            java.lang.StringBuilder r8 = new java.lang.StringBuilder
            r8.<init>()
            java.lang.String r3 = "Error getting Firebase Installation ID: "
            r8.append(r3)
            r8.append(r7)
            java.lang.String r7 = ". Using an empty ID"
            r8.append(r7)
            java.lang.String r7 = r8.toString()
            android.util.Log.e(r4, r7)
            java.lang.String r8 = ""
            r7 = r1
        L_0x0096:
            r7.g(r8)
            z1.i r7 = r0.f5074b     // Catch:{ RuntimeException -> 0x00bb }
            r7.a(r2)     // Catch:{ RuntimeException -> 0x00bb }
            java.lang.StringBuilder r7 = new java.lang.StringBuilder     // Catch:{ RuntimeException -> 0x00bb }
            r7.<init>()     // Catch:{ RuntimeException -> 0x00bb }
            java.lang.String r8 = "Successfully logged Session Start event: "
            r7.append(r8)     // Catch:{ RuntimeException -> 0x00bb }
            z1.t r8 = r2.c()     // Catch:{ RuntimeException -> 0x00bb }
            java.lang.String r8 = r8.e()     // Catch:{ RuntimeException -> 0x00bb }
            r7.append(r8)     // Catch:{ RuntimeException -> 0x00bb }
            java.lang.String r7 = r7.toString()     // Catch:{ RuntimeException -> 0x00bb }
            android.util.Log.i(r4, r7)     // Catch:{ RuntimeException -> 0x00bb }
            goto L_0x00c1
        L_0x00bb:
            r7 = move-exception
            java.lang.String r8 = "Error logging Session Start event to DataTransport: "
            android.util.Log.e(r4, r8, r7)
        L_0x00c1:
            a3.s r7 = a3.s.f271a
            return r7
        */
        throw new UnsupportedOperationException("Method not decompiled: z1.o.a(z1.q, c3.d):java.lang.Object");
    }
}
