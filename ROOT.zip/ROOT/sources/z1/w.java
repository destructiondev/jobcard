package z1;

import android.os.SystemClock;
import kotlin.jvm.internal.e;
import r3.b;
import r3.d;

public final class w implements x {

    /* renamed from: a  reason: collision with root package name */
    public static final a f5115a = new a((e) null);

    public static final class a {
        private a() {
        }

        public /* synthetic */ a(e eVar) {
            this();
        }
    }

    public long a() {
        b.a aVar = b.f4198e;
        return d.p(SystemClock.elapsedRealtime(), r3.e.MILLISECONDS);
    }

    public long b() {
        return System.currentTimeMillis() * 1000;
    }
}
