package z1;

import kotlin.jvm.internal.i;

public final class q {

    /* renamed from: a  reason: collision with root package name */
    private final j f5086a;

    /* renamed from: b  reason: collision with root package name */
    private final t f5087b;

    /* renamed from: c  reason: collision with root package name */
    private final b f5088c;

    public q(j jVar, t tVar, b bVar) {
        i.e(jVar, "eventType");
        i.e(tVar, "sessionData");
        i.e(bVar, "applicationInfo");
        this.f5086a = jVar;
        this.f5087b = tVar;
        this.f5088c = bVar;
    }

    public final b a() {
        return this.f5088c;
    }

    public final j b() {
        return this.f5086a;
    }

    public final t c() {
        return this.f5087b;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof q)) {
            return false;
        }
        q qVar = (q) obj;
        return this.f5086a == qVar.f5086a && i.a(this.f5087b, qVar.f5087b) && i.a(this.f5088c, qVar.f5088c);
    }

    public int hashCode() {
        return (((this.f5086a.hashCode() * 31) + this.f5087b.hashCode()) * 31) + this.f5088c.hashCode();
    }

    public String toString() {
        return "SessionEvent(eventType=" + this.f5086a + ", sessionData=" + this.f5087b + ", applicationInfo=" + this.f5088c + ')';
    }
}
