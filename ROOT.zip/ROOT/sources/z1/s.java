package z1;

import java.util.Locale;
import java.util.UUID;
import kotlin.jvm.internal.e;
import kotlin.jvm.internal.h;
import kotlin.jvm.internal.i;

public final class s {

    /* renamed from: a  reason: collision with root package name */
    private final boolean f5091a;

    /* renamed from: b  reason: collision with root package name */
    private final x f5092b;

    /* renamed from: c  reason: collision with root package name */
    private final j3.a<UUID> f5093c;

    /* renamed from: d  reason: collision with root package name */
    private final String f5094d;

    /* renamed from: e  reason: collision with root package name */
    private int f5095e;

    /* renamed from: f  reason: collision with root package name */
    private p f5096f;

    /* synthetic */ class a extends h implements j3.a<UUID> {

        /* renamed from: d  reason: collision with root package name */
        public static final a f5097d = new a();

        a() {
            super(0, UUID.class, "randomUUID", "randomUUID()Ljava/util/UUID;", 0);
        }

        /* renamed from: c */
        public final UUID invoke() {
            return UUID.randomUUID();
        }
    }

    public s(boolean z3, x xVar, j3.a<UUID> aVar) {
        i.e(xVar, "timeProvider");
        i.e(aVar, "uuidGenerator");
        this.f5091a = z3;
        this.f5092b = xVar;
        this.f5093c = aVar;
        this.f5094d = b();
        this.f5095e = -1;
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public /* synthetic */ s(boolean z3, x xVar, j3.a aVar, int i4, e eVar) {
        this(z3, xVar, (i4 & 4) != 0 ? a.f5097d : aVar);
    }

    private final String b() {
        String uuid = this.f5093c.invoke().toString();
        i.d(uuid, "uuidGenerator().toString()");
        String lowerCase = o.m(uuid, "-", "", false, 4, (Object) null).toLowerCase(Locale.ROOT);
        i.d(lowerCase, "this as java.lang.String).toLowerCase(Locale.ROOT)");
        return lowerCase;
    }

    public final p a() {
        int i4 = this.f5095e + 1;
        this.f5095e = i4;
        this.f5096f = new p(i4 == 0 ? this.f5094d : b(), this.f5094d, this.f5095e, this.f5092b.b());
        return d();
    }

    public final boolean c() {
        return this.f5091a;
    }

    public final p d() {
        p pVar = this.f5096f;
        if (pVar != null) {
            return pVar;
        }
        i.p("currentSession");
        return null;
    }

    public final boolean e() {
        return this.f5096f != null;
    }
}
