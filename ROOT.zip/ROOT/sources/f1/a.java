package f1;

import java.io.File;
import java.io.FilenameFilter;

public final /* synthetic */ class a implements FilenameFilter {

    /* renamed from: a  reason: collision with root package name */
    public static final /* synthetic */ a f2064a = new a();

    private /* synthetic */ a() {
    }

    public final boolean accept(File file, String str) {
        return e.t(file, str);
    }
}
