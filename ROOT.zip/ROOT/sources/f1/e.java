package f1;

import a1.m;
import a1.u;
import c1.b0;
import c1.c0;
import d1.h;
import h1.i;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.SortedSet;
import java.util.TreeSet;
import java.util.concurrent.atomic.AtomicInteger;
import x0.f;

public class e {

    /* renamed from: e  reason: collision with root package name */
    private static final Charset f2068e = Charset.forName("UTF-8");

    /* renamed from: f  reason: collision with root package name */
    private static final int f2069f = 15;

    /* renamed from: g  reason: collision with root package name */
    private static final h f2070g = new h();

    /* renamed from: h  reason: collision with root package name */
    private static final Comparator<? super File> f2071h = c.f2066a;

    /* renamed from: i  reason: collision with root package name */
    private static final FilenameFilter f2072i = b.f2065a;

    /* renamed from: a  reason: collision with root package name */
    private final AtomicInteger f2073a = new AtomicInteger(0);

    /* renamed from: b  reason: collision with root package name */
    private final f f2074b;

    /* renamed from: c  reason: collision with root package name */
    private final i f2075c;

    /* renamed from: d  reason: collision with root package name */
    private final m f2076d;

    public e(f fVar, i iVar, m mVar) {
        this.f2074b = fVar;
        this.f2075c = iVar;
        this.f2076d = mVar;
    }

    private static String A(File file) {
        byte[] bArr = new byte[8192];
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        FileInputStream fileInputStream = new FileInputStream(file);
        while (true) {
            try {
                int read = fileInputStream.read(bArr);
                if (read > 0) {
                    byteArrayOutputStream.write(bArr, 0, read);
                } else {
                    String str = new String(byteArrayOutputStream.toByteArray(), f2068e);
                    fileInputStream.close();
                    return str;
                }
            } catch (Throwable th) {
                th.addSuppressed(th);
            }
        }
        throw th;
    }

    private void B(File file, b0.d dVar, String str, b0.a aVar) {
        String d4 = this.f2076d.d(str);
        try {
            h hVar = f2070g;
            F(this.f2074b.g(str), hVar.G(hVar.F(A(file)).s(dVar).p(aVar).o(d4)));
        } catch (IOException e4) {
            f f4 = f.f();
            f4.l("Could not synthesize final native report file for " + file, e4);
        }
    }

    private void C(String str, long j4) {
        boolean z3;
        List<File> p4 = this.f2074b.p(str, f2072i);
        if (p4.isEmpty()) {
            f f4 = f.f();
            f4.i("Session " + str + " has no events.");
            return;
        }
        Collections.sort(p4);
        ArrayList arrayList = new ArrayList();
        Iterator<File> it = p4.iterator();
        loop0:
        while (true) {
            z3 = false;
            while (true) {
                if (!it.hasNext()) {
                    break loop0;
                }
                File next = it.next();
                try {
                    arrayList.add(f2070g.h(A(next)));
                    if (z3 || s(next.getName())) {
                        z3 = true;
                    }
                } catch (IOException e4) {
                    f f5 = f.f();
                    f5.l("Could not add event to report for " + next, e4);
                }
            }
        }
        if (arrayList.isEmpty()) {
            f f6 = f.f();
            f6.k("Could not parse event files for session " + str);
            return;
        }
        String j5 = b1.i.j(str, this.f2074b);
        String d4 = this.f2076d.d(str);
        D(this.f2074b.o(str, "report"), arrayList, j4, z3, j5, d4);
    }

    private void D(File file, List<b0.e.d> list, long j4, boolean z3, String str, String str2) {
        try {
            h hVar = f2070g;
            b0 q4 = hVar.F(A(file)).t(j4, z3, str).o(str2).q(c0.h(list));
            b0.e m4 = q4.m();
            if (m4 != null) {
                f f4 = f.f();
                f4.b("appQualitySessionId: " + str2);
                F(z3 ? this.f2074b.j(m4.i()) : this.f2074b.l(m4.i()), hVar.G(q4));
            }
        } catch (IOException e4) {
            f f5 = f.f();
            f5.l("Could not synthesize final report file for " + file, e4);
        }
    }

    private int E(String str, int i4) {
        List<File> p4 = this.f2074b.p(str, a.f2064a);
        Collections.sort(p4, d.f2067a);
        return f(p4, i4);
    }

    private static void F(File file, String str) {
        OutputStreamWriter outputStreamWriter = new OutputStreamWriter(new FileOutputStream(file), f2068e);
        try {
            outputStreamWriter.write(str);
            outputStreamWriter.close();
            return;
        } catch (Throwable th) {
            th.addSuppressed(th);
        }
        throw th;
    }

    private static void G(File file, String str, long j4) {
        OutputStreamWriter outputStreamWriter = new OutputStreamWriter(new FileOutputStream(file), f2068e);
        try {
            outputStreamWriter.write(str);
            file.setLastModified(h(j4));
            outputStreamWriter.close();
            return;
        } catch (Throwable th) {
            th.addSuppressed(th);
        }
        throw th;
    }

    private SortedSet<String> e(String str) {
        this.f2074b.b();
        SortedSet<String> p4 = p();
        if (str != null) {
            p4.remove(str);
        }
        if (p4.size() <= 8) {
            return p4;
        }
        while (p4.size() > 8) {
            String last = p4.last();
            f f4 = f.f();
            f4.b("Removing session over cap: " + last);
            this.f2074b.c(last);
            p4.remove(last);
        }
        return p4;
    }

    private static int f(List<File> list, int i4) {
        int size = list.size();
        for (File next : list) {
            if (size <= i4) {
                return size;
            }
            f.s(next);
            size--;
        }
        return size;
    }

    private void g() {
        int i4 = this.f2075c.b().f2146a.f2158b;
        List<File> n4 = n();
        int size = n4.size();
        if (size > i4) {
            for (File delete : n4.subList(i4, size)) {
                delete.delete();
            }
        }
    }

    private static long h(long j4) {
        return j4 * 1000;
    }

    private void j(List<File> list) {
        for (File delete : list) {
            delete.delete();
        }
    }

    private static String m(int i4, boolean z3) {
        String format = String.format(Locale.US, "%010d", new Object[]{Integer.valueOf(i4)});
        String str = z3 ? "_" : "";
        return "event" + format + str;
    }

    private List<File> n() {
        ArrayList arrayList = new ArrayList();
        arrayList.addAll(this.f2074b.k());
        arrayList.addAll(this.f2074b.h());
        Comparator<? super File> comparator = f2071h;
        Collections.sort(arrayList, comparator);
        List<File> m4 = this.f2074b.m();
        Collections.sort(m4, comparator);
        arrayList.addAll(m4);
        return arrayList;
    }

    private static String o(String str) {
        return str.substring(0, f2069f);
    }

    private static boolean s(String str) {
        return str.startsWith("event") && str.endsWith("_");
    }

    /* access modifiers changed from: private */
    public static boolean t(File file, String str) {
        return str.startsWith("event") && !str.endsWith("_");
    }

    /* access modifiers changed from: private */
    public static int x(File file, File file2) {
        return o(file.getName()).compareTo(o(file2.getName()));
    }

    public void i() {
        j(this.f2074b.m());
        j(this.f2074b.k());
        j(this.f2074b.h());
    }

    public void k(String str, long j4) {
        for (String next : e(str)) {
            f f4 = f.f();
            f4.i("Finalizing report for session " + next);
            C(next, j4);
            this.f2074b.c(next);
        }
        g();
    }

    public void l(String str, b0.d dVar, b0.a aVar) {
        File o4 = this.f2074b.o(str, "report");
        f f4 = f.f();
        f4.b("Writing native session report for " + str + " to file: " + o4);
        B(o4, dVar, str, aVar);
    }

    public SortedSet<String> p() {
        return new TreeSet(this.f2074b.d()).descendingSet();
    }

    public long q(String str) {
        return this.f2074b.o(str, "start-time").lastModified();
    }

    public boolean r() {
        return !this.f2074b.m().isEmpty() || !this.f2074b.k().isEmpty() || !this.f2074b.h().isEmpty();
    }

    public List<u> w() {
        List<File> n4 = n();
        ArrayList arrayList = new ArrayList();
        for (File next : n4) {
            try {
                arrayList.add(u.a(f2070g.F(A(next)), next.getName(), next));
            } catch (IOException e4) {
                f f4 = f.f();
                f4.l("Could not load report file " + next + "; deleting", e4);
                next.delete();
            }
        }
        return arrayList;
    }

    public void y(b0.e.d dVar, String str, boolean z3) {
        int i4 = this.f2075c.b().f2146a.f2157a;
        try {
            F(this.f2074b.o(str, m(this.f2073a.getAndIncrement(), z3)), f2070g.i(dVar));
        } catch (IOException e4) {
            f f4 = f.f();
            f4.l("Could not persist event for session " + str, e4);
        }
        E(str, i4);
    }

    public void z(b0 b0Var) {
        b0.e m4 = b0Var.m();
        if (m4 == null) {
            f.f().b("Could not get session for report");
            return;
        }
        String i4 = m4.i();
        try {
            F(this.f2074b.o(i4, "report"), f2070g.G(b0Var));
            G(this.f2074b.o(i4, "start-time"), "", m4.l());
        } catch (IOException e4) {
            f f4 = f.f();
            f4.c("Could not persist report for session " + i4, e4);
        }
    }
}
