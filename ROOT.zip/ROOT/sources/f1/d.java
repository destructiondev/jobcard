package f1;

import java.io.File;
import java.util.Comparator;

public final /* synthetic */ class d implements Comparator {

    /* renamed from: a  reason: collision with root package name */
    public static final /* synthetic */ d f2067a = new d();

    private /* synthetic */ d() {
    }

    public final int compare(Object obj, Object obj2) {
        return e.x((File) obj, (File) obj2);
    }
}
