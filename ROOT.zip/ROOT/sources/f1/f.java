package f1;

import android.app.Application;
import android.content.Context;
import android.os.Build;
import java.io.File;
import java.io.FilenameFilter;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class f {

    /* renamed from: a  reason: collision with root package name */
    private final File f2077a;

    /* renamed from: b  reason: collision with root package name */
    private final File f2078b;

    /* renamed from: c  reason: collision with root package name */
    private final File f2079c;

    /* renamed from: d  reason: collision with root package name */
    private final File f2080d;

    /* renamed from: e  reason: collision with root package name */
    private final File f2081e;

    /* renamed from: f  reason: collision with root package name */
    private final File f2082f;

    public f(Context context) {
        String str;
        File filesDir = context.getFilesDir();
        this.f2077a = filesDir;
        if (v()) {
            str = ".com.google.firebase.crashlytics.files.v2" + File.pathSeparator + u(Application.getProcessName());
        } else {
            str = ".com.google.firebase.crashlytics.files.v1";
        }
        File q4 = q(new File(filesDir, str));
        this.f2078b = q4;
        this.f2079c = q(new File(q4, "open-sessions"));
        this.f2080d = q(new File(q4, "reports"));
        this.f2081e = q(new File(q4, "priority-reports"));
        this.f2082f = q(new File(q4, "native-reports"));
    }

    private void a(File file) {
        if (file.exists() && s(file)) {
            x0.f f4 = x0.f.f();
            f4.b("Deleted previous Crashlytics file system: " + file.getPath());
        }
    }

    private File n(String str) {
        return r(new File(this.f2079c, str));
    }

    /* JADX WARNING: Code restructure failed: missing block: B:15:0x0050, code lost:
        return r4;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private static synchronized java.io.File q(java.io.File r4) {
        /*
            java.lang.Class<f1.f> r0 = f1.f.class
            monitor-enter(r0)
            boolean r1 = r4.exists()     // Catch:{ all -> 0x0051 }
            if (r1 == 0) goto L_0x0031
            boolean r1 = r4.isDirectory()     // Catch:{ all -> 0x0051 }
            if (r1 == 0) goto L_0x0011
            monitor-exit(r0)
            return r4
        L_0x0011:
            x0.f r1 = x0.f.f()     // Catch:{ all -> 0x0051 }
            java.lang.StringBuilder r2 = new java.lang.StringBuilder     // Catch:{ all -> 0x0051 }
            r2.<init>()     // Catch:{ all -> 0x0051 }
            java.lang.String r3 = "Unexpected non-directory file: "
            r2.append(r3)     // Catch:{ all -> 0x0051 }
            r2.append(r4)     // Catch:{ all -> 0x0051 }
            java.lang.String r3 = "; deleting file and creating new directory."
            r2.append(r3)     // Catch:{ all -> 0x0051 }
            java.lang.String r2 = r2.toString()     // Catch:{ all -> 0x0051 }
            r1.b(r2)     // Catch:{ all -> 0x0051 }
            r4.delete()     // Catch:{ all -> 0x0051 }
        L_0x0031:
            boolean r1 = r4.mkdirs()     // Catch:{ all -> 0x0051 }
            if (r1 != 0) goto L_0x004f
            x0.f r1 = x0.f.f()     // Catch:{ all -> 0x0051 }
            java.lang.StringBuilder r2 = new java.lang.StringBuilder     // Catch:{ all -> 0x0051 }
            r2.<init>()     // Catch:{ all -> 0x0051 }
            java.lang.String r3 = "Could not create Crashlytics-specific directory: "
            r2.append(r3)     // Catch:{ all -> 0x0051 }
            r2.append(r4)     // Catch:{ all -> 0x0051 }
            java.lang.String r2 = r2.toString()     // Catch:{ all -> 0x0051 }
            r1.d(r2)     // Catch:{ all -> 0x0051 }
        L_0x004f:
            monitor-exit(r0)
            return r4
        L_0x0051:
            r4 = move-exception
            monitor-exit(r0)
            throw r4
        */
        throw new UnsupportedOperationException("Method not decompiled: f1.f.q(java.io.File):java.io.File");
    }

    private static File r(File file) {
        file.mkdirs();
        return file;
    }

    static boolean s(File file) {
        File[] listFiles = file.listFiles();
        if (listFiles != null) {
            for (File s4 : listFiles) {
                s(s4);
            }
        }
        return file.delete();
    }

    private static <T> List<T> t(T[] tArr) {
        return tArr == null ? Collections.emptyList() : Arrays.asList(tArr);
    }

    static String u(String str) {
        return str.replaceAll("[^a-zA-Z0-9.]", "_");
    }

    private static boolean v() {
        return Build.VERSION.SDK_INT >= 28;
    }

    public void b() {
        a(new File(this.f2077a, ".com.google.firebase.crashlytics"));
        a(new File(this.f2077a, ".com.google.firebase.crashlytics-ndk"));
        if (v()) {
            a(new File(this.f2077a, ".com.google.firebase.crashlytics.files.v1"));
        }
    }

    public boolean c(String str) {
        return s(new File(this.f2079c, str));
    }

    public List<String> d() {
        return t(this.f2079c.list());
    }

    public File e(String str) {
        return new File(this.f2078b, str);
    }

    public List<File> f(FilenameFilter filenameFilter) {
        return t(this.f2078b.listFiles(filenameFilter));
    }

    public File g(String str) {
        return new File(this.f2082f, str);
    }

    public List<File> h() {
        return t(this.f2082f.listFiles());
    }

    public File i(String str) {
        return r(new File(n(str), "native"));
    }

    public File j(String str) {
        return new File(this.f2081e, str);
    }

    public List<File> k() {
        return t(this.f2081e.listFiles());
    }

    public File l(String str) {
        return new File(this.f2080d, str);
    }

    public List<File> m() {
        return t(this.f2080d.listFiles());
    }

    public File o(String str, String str2) {
        return new File(n(str), str2);
    }

    public List<File> p(String str, FilenameFilter filenameFilter) {
        return t(n(str).listFiles(filenameFilter));
    }
}
