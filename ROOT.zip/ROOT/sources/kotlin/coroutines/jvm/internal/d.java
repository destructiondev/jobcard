package kotlin.coroutines.jvm.internal;

import c3.e;
import c3.g;
import kotlin.jvm.internal.i;

public abstract class d extends a {
    private final g _context;
    private transient c3.d<Object> intercepted;

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public d(c3.d<Object> dVar) {
        this(dVar, dVar != null ? dVar.getContext() : null);
    }

    public d(c3.d<Object> dVar, g gVar) {
        super(dVar);
        this._context = gVar;
    }

    public g getContext() {
        g gVar = this._context;
        i.b(gVar);
        return gVar;
    }

    public final c3.d<Object> intercepted() {
        c3.d<Object> dVar = this.intercepted;
        if (dVar == null) {
            e eVar = (e) getContext().a(e.f1631a);
            if (eVar == null || (dVar = eVar.m(this)) == null) {
                dVar = this;
            }
            this.intercepted = dVar;
        }
        return dVar;
    }

    /* access modifiers changed from: protected */
    public void releaseIntercepted() {
        c3.d<Object> dVar = this.intercepted;
        if (!(dVar == null || dVar == this)) {
            g.b a4 = getContext().a(e.f1631a);
            i.b(a4);
            ((e) a4).e(dVar);
        }
        this.intercepted = c.f3435d;
    }
}
