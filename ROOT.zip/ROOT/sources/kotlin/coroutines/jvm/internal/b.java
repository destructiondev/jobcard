package kotlin.coroutines.jvm.internal;

public final class b {
    public static final Boolean a(boolean z3) {
        return Boolean.valueOf(z3);
    }

    public static final Integer b(int i4) {
        return new Integer(i4);
    }

    public static final Long c(long j4) {
        return new Long(j4);
    }
}
