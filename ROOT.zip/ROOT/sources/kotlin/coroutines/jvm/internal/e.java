package kotlin.coroutines.jvm.internal;

public interface e {
    e getCallerFrame();
}
