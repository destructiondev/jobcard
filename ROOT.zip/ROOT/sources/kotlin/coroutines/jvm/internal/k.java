package kotlin.coroutines.jvm.internal;

import c3.d;
import kotlin.jvm.internal.f;
import kotlin.jvm.internal.i;
import kotlin.jvm.internal.s;

public abstract class k extends d implements f<Object> {
    private final int arity;

    public k(int i4) {
        this(i4, (d<Object>) null);
    }

    public k(int i4, d<Object> dVar) {
        super(dVar);
        this.arity = i4;
    }

    public int getArity() {
        return this.arity;
    }

    public String toString() {
        if (getCompletion() != null) {
            return super.toString();
        }
        String f4 = s.f(this);
        i.d(f4, "renderLambdaToString(this)");
        return f4;
    }
}
