package kotlin.coroutines.jvm.internal;

import c3.d;
import kotlin.jvm.internal.i;

public final class h {
    public static final <T> d<T> a(d<? super T> dVar) {
        i.e(dVar, "completion");
        return dVar;
    }

    public static final void b(d<?> dVar) {
        i.e(dVar, "frame");
    }

    public static final void c(d<?> dVar) {
        i.e(dVar, "frame");
    }
}
