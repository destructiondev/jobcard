package kotlin.jvm.internal;

public class o extends n {
    public o(Class cls, String str, String str2, int i4) {
        super(cls, str, str2, i4);
    }

    public Object a(Object obj, Object obj2) {
        return j().call(obj, obj2);
    }
}
