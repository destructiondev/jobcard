package kotlin.jvm.internal;

import o3.c;
import o3.d;
import o3.e;
import o3.f;
import o3.g;

public class t {
    public e a(g gVar) {
        return gVar;
    }

    public c b(Class cls) {
        return new c(cls);
    }

    public d c(Class cls, String str) {
        return new k(cls, str);
    }

    public f d(l lVar) {
        return lVar;
    }

    public g e(n nVar) {
        return nVar;
    }

    public String f(f fVar) {
        String obj = fVar.getClass().getGenericInterfaces()[0].toString();
        return obj.startsWith("kotlin.jvm.functions.") ? obj.substring(21) : obj;
    }

    public String g(j jVar) {
        return f(jVar);
    }
}
