package kotlin.jvm.internal;

public final class k implements b {

    /* renamed from: d  reason: collision with root package name */
    private final Class<?> f3451d;

    /* renamed from: e  reason: collision with root package name */
    private final String f3452e;

    public k(Class<?> cls, String str) {
        i.e(cls, "jClass");
        i.e(str, "moduleName");
        this.f3451d = cls;
        this.f3452e = str;
    }

    public Class<?> c() {
        return this.f3451d;
    }

    public boolean equals(Object obj) {
        return (obj instanceof k) && i.a(c(), ((k) obj).c());
    }

    public int hashCode() {
        return c().hashCode();
    }

    public String toString() {
        return c().toString() + " (Kotlin reflection is not available)";
    }
}
