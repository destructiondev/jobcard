package kotlin.jvm.internal;

import j3.b;
import j3.d;
import j3.e;
import j3.f;
import j3.g;
import j3.h;
import j3.i;
import j3.j;
import j3.k;
import j3.l;
import j3.m;
import j3.n;
import j3.o;
import j3.p;
import j3.q;
import j3.r;
import j3.s;
import j3.t;
import j3.u;
import j3.v;
import j3.w;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class c implements o3.c<Object>, b {

    /* renamed from: e  reason: collision with root package name */
    public static final a f3443e = new a((e) null);

    /* renamed from: f  reason: collision with root package name */
    private static final Map<Class<? extends a3.c<?>>, Integer> f3444f;

    /* renamed from: g  reason: collision with root package name */
    private static final HashMap<String, String> f3445g;

    /* renamed from: h  reason: collision with root package name */
    private static final HashMap<String, String> f3446h;

    /* renamed from: i  reason: collision with root package name */
    private static final HashMap<String, String> f3447i;
    /* access modifiers changed from: private */

    /* renamed from: j  reason: collision with root package name */
    public static final Map<String, String> f3448j;

    /* renamed from: d  reason: collision with root package name */
    private final Class<?> f3449d;

    public static final class a {
        private a() {
        }

        public /* synthetic */ a(e eVar) {
            this();
        }

        public final String a(Class<?> cls) {
            String str;
            i.e(cls, "jClass");
            String str2 = null;
            if (!cls.isAnonymousClass()) {
                if (cls.isLocalClass()) {
                    String simpleName = cls.getSimpleName();
                    Method enclosingMethod = cls.getEnclosingMethod();
                    if (enclosingMethod != null) {
                        i.d(simpleName, "name");
                        String V = p.V(simpleName, enclosingMethod.getName() + '$', (String) null, 2, (Object) null);
                        if (V != null) {
                            return V;
                        }
                    }
                    Constructor<?> enclosingConstructor = cls.getEnclosingConstructor();
                    i.d(simpleName, "name");
                    if (enclosingConstructor == null) {
                        return p.U(simpleName, '$', (String) null, 2, (Object) null);
                    }
                    return p.V(simpleName, enclosingConstructor.getName() + '$', (String) null, 2, (Object) null);
                } else if (cls.isArray()) {
                    Class<?> componentType = cls.getComponentType();
                    if (componentType.isPrimitive() && (str = (String) c.f3448j.get(componentType.getName())) != null) {
                        str2 = str + "Array";
                    }
                    if (str2 == null) {
                        return "Array";
                    }
                } else {
                    String str3 = (String) c.f3448j.get(cls.getName());
                    return str3 == null ? cls.getSimpleName() : str3;
                }
            }
            return str2;
        }
    }

    static {
        int i4 = 0;
        List d4 = m.d(j3.a.class, l.class, p.class, q.class, r.class, s.class, t.class, u.class, v.class, w.class, b.class, j3.c.class, d.class, e.class, f.class, g.class, h.class, i.class, j.class, k.class, m.class, n.class, o.class);
        ArrayList arrayList = new ArrayList(n.g(d4, 10));
        for (Object next : d4) {
            int i5 = i4 + 1;
            if (i4 < 0) {
                m.f();
            }
            arrayList.add(a3.p.a((Class) next, Integer.valueOf(i4)));
            i4 = i5;
        }
        f3444f = e0.i(arrayList);
        HashMap<String, String> hashMap = new HashMap<>();
        hashMap.put("boolean", "kotlin.Boolean");
        hashMap.put("char", "kotlin.Char");
        hashMap.put("byte", "kotlin.Byte");
        hashMap.put("short", "kotlin.Short");
        hashMap.put("int", "kotlin.Int");
        hashMap.put("float", "kotlin.Float");
        hashMap.put("long", "kotlin.Long");
        hashMap.put("double", "kotlin.Double");
        f3445g = hashMap;
        HashMap<String, String> hashMap2 = new HashMap<>();
        hashMap2.put("java.lang.Boolean", "kotlin.Boolean");
        hashMap2.put("java.lang.Character", "kotlin.Char");
        hashMap2.put("java.lang.Byte", "kotlin.Byte");
        hashMap2.put("java.lang.Short", "kotlin.Short");
        hashMap2.put("java.lang.Integer", "kotlin.Int");
        hashMap2.put("java.lang.Float", "kotlin.Float");
        hashMap2.put("java.lang.Long", "kotlin.Long");
        hashMap2.put("java.lang.Double", "kotlin.Double");
        f3446h = hashMap2;
        HashMap<String, String> hashMap3 = new HashMap<>();
        hashMap3.put("java.lang.Object", "kotlin.Any");
        hashMap3.put("java.lang.String", "kotlin.String");
        hashMap3.put("java.lang.CharSequence", "kotlin.CharSequence");
        hashMap3.put("java.lang.Throwable", "kotlin.Throwable");
        hashMap3.put("java.lang.Cloneable", "kotlin.Cloneable");
        hashMap3.put("java.lang.Number", "kotlin.Number");
        hashMap3.put("java.lang.Comparable", "kotlin.Comparable");
        hashMap3.put("java.lang.Enum", "kotlin.Enum");
        hashMap3.put("java.lang.annotation.Annotation", "kotlin.Annotation");
        hashMap3.put("java.lang.Iterable", "kotlin.collections.Iterable");
        hashMap3.put("java.util.Iterator", "kotlin.collections.Iterator");
        hashMap3.put("java.util.Collection", "kotlin.collections.Collection");
        hashMap3.put("java.util.List", "kotlin.collections.List");
        hashMap3.put("java.util.Set", "kotlin.collections.Set");
        hashMap3.put("java.util.ListIterator", "kotlin.collections.ListIterator");
        hashMap3.put("java.util.Map", "kotlin.collections.Map");
        hashMap3.put("java.util.Map$Entry", "kotlin.collections.Map.Entry");
        hashMap3.put("kotlin.jvm.internal.StringCompanionObject", "kotlin.String.Companion");
        hashMap3.put("kotlin.jvm.internal.EnumCompanionObject", "kotlin.Enum.Companion");
        hashMap3.putAll(hashMap);
        hashMap3.putAll(hashMap2);
        Collection<String> values = hashMap.values();
        i.d(values, "primitiveFqNames.values");
        for (String str : values) {
            StringBuilder sb = new StringBuilder();
            sb.append("kotlin.jvm.internal.");
            i.d(str, "kotlinName");
            sb.append(p.X(str, '.', (String) null, 2, (Object) null));
            sb.append("CompanionObject");
            String sb2 = sb.toString();
            a3.l a4 = a3.p.a(sb2, str + ".Companion");
            hashMap3.put(a4.c(), a4.d());
        }
        for (Map.Entry next2 : f3444f.entrySet()) {
            int intValue = ((Number) next2.getValue()).intValue();
            String name = ((Class) next2.getKey()).getName();
            hashMap3.put(name, "kotlin.Function" + intValue);
        }
        f3447i = hashMap3;
        LinkedHashMap linkedHashMap = new LinkedHashMap(d0.a(hashMap3.size()));
        for (Map.Entry entry : hashMap3.entrySet()) {
            linkedHashMap.put(entry.getKey(), p.X((String) entry.getValue(), '.', (String) null, 2, (Object) null));
        }
        f3448j = linkedHashMap;
    }

    public c(Class<?> cls) {
        i.e(cls, "jClass");
        this.f3449d = cls;
    }

    public String b() {
        return f3443e.a(c());
    }

    public Class<?> c() {
        return this.f3449d;
    }

    public boolean equals(Object obj) {
        return (obj instanceof c) && i.a(i3.a.b(this), i3.a.b((o3.c) obj));
    }

    public int hashCode() {
        return i3.a.b(this).hashCode();
    }

    public String toString() {
        return c().toString() + " (Kotlin reflection is not available)";
    }
}
