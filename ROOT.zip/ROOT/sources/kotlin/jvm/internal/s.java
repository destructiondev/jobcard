package kotlin.jvm.internal;

import o3.c;
import o3.d;
import o3.e;
import o3.f;
import o3.g;

public class s {

    /* renamed from: a  reason: collision with root package name */
    private static final t f3456a;

    /* renamed from: b  reason: collision with root package name */
    private static final c[] f3457b = new c[0];

    static {
        t tVar = null;
        try {
            tVar = (t) Class.forName("kotlin.reflect.jvm.internal.ReflectionFactoryImpl").newInstance();
        } catch (ClassCastException | ClassNotFoundException | IllegalAccessException | InstantiationException unused) {
        }
        if (tVar == null) {
            tVar = new t();
        }
        f3456a = tVar;
    }

    public static e a(g gVar) {
        return f3456a.a(gVar);
    }

    public static c b(Class cls) {
        return f3456a.b(cls);
    }

    public static d c(Class cls) {
        return f3456a.c(cls, "");
    }

    public static f d(l lVar) {
        return f3456a.d(lVar);
    }

    public static g e(n nVar) {
        return f3456a.e(nVar);
    }

    public static String f(f fVar) {
        return f3456a.f(fVar);
    }

    public static String g(j jVar) {
        return f3456a.g(jVar);
    }
}
