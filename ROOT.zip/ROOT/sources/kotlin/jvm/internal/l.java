package kotlin.jvm.internal;

import o3.b;
import o3.f;

public abstract class l extends p implements f {
    public l(Object obj, Class cls, String str, String str2, int i4) {
        super(obj, cls, str, str2, i4);
    }

    /* access modifiers changed from: protected */
    public b computeReflected() {
        return s.d(this);
    }

    public Object invoke() {
        return get();
    }
}
