package kotlin.jvm.internal;

import a3.c;

public interface f<R> extends c<R> {
    int getArity();
}
