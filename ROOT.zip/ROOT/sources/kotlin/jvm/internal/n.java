package kotlin.jvm.internal;

import o3.b;
import o3.g;

public abstract class n extends p implements g {
    public n(Class cls, String str, String str2, int i4) {
        super(a.NO_RECEIVER, cls, str, str2, i4);
    }

    /* access modifiers changed from: protected */
    public b computeReflected() {
        return s.e(this);
    }

    public Object invoke(Object obj, Object obj2) {
        return a(obj, obj2);
    }

    public g.a j() {
        return ((g) getReflected()).j();
    }
}
