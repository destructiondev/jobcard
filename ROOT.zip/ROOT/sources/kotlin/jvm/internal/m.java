package kotlin.jvm.internal;

public class m extends l {
    public m(Object obj, Class cls, String str, String str2, int i4) {
        super(obj, cls, str, str2, i4);
    }
}
