package kotlin.jvm.internal;

public final class u {

    /* renamed from: a  reason: collision with root package name */
    public static final u f3458a = new u();

    private u() {
    }
}
