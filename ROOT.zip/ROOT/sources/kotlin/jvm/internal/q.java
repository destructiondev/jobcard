package kotlin.jvm.internal;

import java.io.Serializable;

public final class q implements Serializable {

    /* renamed from: d  reason: collision with root package name */
    public boolean f3454d;

    public String toString() {
        return String.valueOf(this.f3454d);
    }
}
