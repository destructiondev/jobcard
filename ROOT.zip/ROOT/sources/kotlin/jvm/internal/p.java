package kotlin.jvm.internal;

import o3.b;
import o3.h;

public abstract class p extends a implements h {

    /* renamed from: d  reason: collision with root package name */
    private final boolean f3453d;

    public p() {
        this.f3453d = false;
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public p(Object obj, Class cls, String str, String str2, int i4) {
        super(obj, cls, str, str2, (i4 & 1) == 1);
        boolean z3 = false;
        this.f3453d = (i4 & 2) == 2 ? true : z3;
    }

    /* access modifiers changed from: protected */
    /* renamed from: c */
    public h getReflected() {
        if (!this.f3453d) {
            return (h) super.getReflected();
        }
        throw new UnsupportedOperationException("Kotlin reflection is not yet supported for synthetic Java properties");
    }

    public b compute() {
        return this.f3453d ? this : super.compute();
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (obj instanceof p) {
            p pVar = (p) obj;
            return getOwner().equals(pVar.getOwner()) && getName().equals(pVar.getName()) && getSignature().equals(pVar.getSignature()) && i.a(getBoundReceiver(), pVar.getBoundReceiver());
        } else if (obj instanceof h) {
            return obj.equals(compute());
        } else {
            return false;
        }
    }

    public int hashCode() {
        return (((getOwner().hashCode() * 31) + getName().hashCode()) * 31) + getSignature().hashCode();
    }

    public String toString() {
        b compute = compute();
        if (compute != this) {
            return compute.toString();
        }
        return "property " + getName() + " (Kotlin reflection is not available)";
    }
}
