package kotlin.jvm.internal;

import o3.d;

public interface b extends d {
    Class<?> c();
}
