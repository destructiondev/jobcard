package kotlin.jvm.internal;

import java.io.Serializable;

public abstract class j<R> implements f<R>, Serializable {
    private final int arity;

    public j(int i4) {
        this.arity = i4;
    }

    public int getArity() {
        return this.arity;
    }

    public String toString() {
        String g4 = s.g(this);
        i.d(g4, "renderLambdaToString(this)");
        return g4;
    }
}
