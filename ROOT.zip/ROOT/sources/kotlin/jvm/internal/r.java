package kotlin.jvm.internal;

import java.io.Serializable;

public final class r<T> implements Serializable {

    /* renamed from: d  reason: collision with root package name */
    public T f3455d;

    public String toString() {
        return String.valueOf(this.f3455d);
    }
}
