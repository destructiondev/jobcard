package kotlin.jvm.internal;

import o3.c;
import o3.d;

public class h extends g {
    public h(int i4, Class cls, String str, String str2, int i5) {
        super(i4, a.NO_RECEIVER, cls, str, str2, i5);
    }

    public h(int i4, Object obj, Class cls, String str, String str2, int i5) {
        super(i4, obj, cls, str, str2, i5);
    }

    public h(int i4, d dVar, String str, String str2) {
        super(i4, a.NO_RECEIVER, ((b) dVar).c(), str, str2, (dVar instanceof c) ^ true ? 1 : 0);
    }
}
