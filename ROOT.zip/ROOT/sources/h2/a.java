package h2;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Path;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewTreeObserver;
import android.view.accessibility.AccessibilityEvent;
import android.widget.FrameLayout;
import io.flutter.embedding.engine.mutatorsstack.FlutterMutatorsStack;
import x2.h;

public class a extends FrameLayout {

    /* renamed from: d  reason: collision with root package name */
    private FlutterMutatorsStack f2183d;

    /* renamed from: e  reason: collision with root package name */
    private float f2184e;

    /* renamed from: f  reason: collision with root package name */
    private int f2185f;

    /* renamed from: g  reason: collision with root package name */
    private int f2186g;

    /* renamed from: h  reason: collision with root package name */
    private int f2187h;

    /* renamed from: i  reason: collision with root package name */
    private int f2188i;

    /* renamed from: j  reason: collision with root package name */
    private final io.flutter.embedding.android.a f2189j;

    /* renamed from: k  reason: collision with root package name */
    ViewTreeObserver.OnGlobalFocusChangeListener f2190k;

    /* renamed from: h2.a$a  reason: collision with other inner class name */
    class C0064a implements ViewTreeObserver.OnGlobalFocusChangeListener {

        /* renamed from: d  reason: collision with root package name */
        final /* synthetic */ View.OnFocusChangeListener f2191d;

        /* renamed from: e  reason: collision with root package name */
        final /* synthetic */ View f2192e;

        C0064a(View.OnFocusChangeListener onFocusChangeListener, View view) {
            this.f2191d = onFocusChangeListener;
            this.f2192e = view;
        }

        public void onGlobalFocusChanged(View view, View view2) {
            View.OnFocusChangeListener onFocusChangeListener = this.f2191d;
            View view3 = this.f2192e;
            onFocusChangeListener.onFocusChange(view3, h.c(view3));
        }
    }

    public a(Context context, float f4, io.flutter.embedding.android.a aVar) {
        super(context, (AttributeSet) null);
        this.f2184e = f4;
        this.f2189j = aVar;
    }

    private Matrix getPlatformViewMatrix() {
        Matrix matrix = new Matrix(this.f2183d.getFinalMatrix());
        float f4 = this.f2184e;
        matrix.preScale(1.0f / f4, 1.0f / f4);
        matrix.postTranslate((float) (-this.f2185f), (float) (-this.f2186g));
        return matrix;
    }

    public void a(FlutterMutatorsStack flutterMutatorsStack, int i4, int i5, int i6, int i7) {
        this.f2183d = flutterMutatorsStack;
        this.f2185f = i4;
        this.f2186g = i5;
        FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(i6, i7);
        layoutParams.leftMargin = i4;
        layoutParams.topMargin = i5;
        setLayoutParams(layoutParams);
        setWillNotDraw(false);
    }

    public void b() {
        ViewTreeObserver.OnGlobalFocusChangeListener onGlobalFocusChangeListener;
        ViewTreeObserver viewTreeObserver = getViewTreeObserver();
        if (viewTreeObserver.isAlive() && (onGlobalFocusChangeListener = this.f2190k) != null) {
            this.f2190k = null;
            viewTreeObserver.removeOnGlobalFocusChangeListener(onGlobalFocusChangeListener);
        }
    }

    public void dispatchDraw(Canvas canvas) {
        canvas.save();
        canvas.concat(getPlatformViewMatrix());
        super.dispatchDraw(canvas);
        canvas.restore();
    }

    public void draw(Canvas canvas) {
        canvas.save();
        for (Path path : this.f2183d.getFinalClippingPaths()) {
            Path path2 = new Path(path);
            path2.offset((float) (-this.f2185f), (float) (-this.f2186g));
            canvas.clipPath(path2);
        }
        super.draw(canvas);
        canvas.restore();
    }

    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        return true;
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        int i4;
        float f4;
        if (this.f2189j == null) {
            return super.onTouchEvent(motionEvent);
        }
        Matrix matrix = new Matrix();
        int action = motionEvent.getAction();
        if (action == 0) {
            int i5 = this.f2185f;
            this.f2187h = i5;
            i4 = this.f2186g;
            this.f2188i = i4;
            f4 = (float) i5;
        } else if (action != 2) {
            f4 = (float) this.f2185f;
            i4 = this.f2186g;
        } else {
            matrix.postTranslate((float) this.f2187h, (float) this.f2188i);
            this.f2187h = this.f2185f;
            this.f2188i = this.f2186g;
            return this.f2189j.g(motionEvent, matrix);
        }
        matrix.postTranslate(f4, (float) i4);
        return this.f2189j.g(motionEvent, matrix);
    }

    public boolean requestSendAccessibilityEvent(View view, AccessibilityEvent accessibilityEvent) {
        View childAt = getChildAt(0);
        if (childAt == null || childAt.getImportantForAccessibility() != 4) {
            return super.requestSendAccessibilityEvent(view, accessibilityEvent);
        }
        return false;
    }

    public void setOnDescendantFocusChangeListener(View.OnFocusChangeListener onFocusChangeListener) {
        b();
        ViewTreeObserver viewTreeObserver = getViewTreeObserver();
        if (viewTreeObserver.isAlive() && this.f2190k == null) {
            C0064a aVar = new C0064a(onFocusChangeListener, this);
            this.f2190k = aVar;
            viewTreeObserver.addOnGlobalFocusChangeListener(aVar);
        }
    }
}
