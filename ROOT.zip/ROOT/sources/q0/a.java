package q0;

import java.util.concurrent.Future;

public interface a<V> extends Future<V> {
}
