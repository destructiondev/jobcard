package v2;

import java.util.ArrayList;
import java.util.List;
import r2.a;
import r2.c;
import r2.h;
import r2.q;
import v2.a;

public final /* synthetic */ class j {
    public static h<Object> a() {
        return new q();
    }

    public static /* synthetic */ void b(a.b bVar, Object obj, a.e eVar) {
        ArrayList<Object> arrayList = new ArrayList<>();
        try {
            arrayList.add(0, bVar.d((String) ((ArrayList) obj).get(0)));
        } catch (Throwable th) {
            arrayList = a.a(th);
        }
        eVar.a(arrayList);
    }

    public static /* synthetic */ void c(a.b bVar, Object obj, a.e eVar) {
        ArrayList<Object> arrayList = new ArrayList<>();
        ArrayList arrayList2 = (ArrayList) obj;
        try {
            arrayList.add(0, bVar.a((String) arrayList2.get(0), (Boolean) arrayList2.get(1)));
        } catch (Throwable th) {
            arrayList = a.a(th);
        }
        eVar.a(arrayList);
    }

    public static /* synthetic */ void d(a.b bVar, Object obj, a.e eVar) {
        ArrayList<Object> arrayList = new ArrayList<>();
        ArrayList arrayList2 = (ArrayList) obj;
        try {
            arrayList.add(0, bVar.h((String) arrayList2.get(0), (String) arrayList2.get(1)));
        } catch (Throwable th) {
            arrayList = a.a(th);
        }
        eVar.a(arrayList);
    }

    public static /* synthetic */ void e(a.b bVar, Object obj, a.e eVar) {
        Long l4;
        ArrayList<Object> arrayList = new ArrayList<>();
        ArrayList arrayList2 = (ArrayList) obj;
        String str = (String) arrayList2.get(0);
        Number number = (Number) arrayList2.get(1);
        if (number == null) {
            l4 = null;
        } else {
            try {
                l4 = Long.valueOf(number.longValue());
            } catch (Throwable th) {
                arrayList = a.a(th);
            }
        }
        arrayList.add(0, bVar.e(str, l4));
        eVar.a(arrayList);
    }

    public static /* synthetic */ void f(a.b bVar, Object obj, a.e eVar) {
        ArrayList<Object> arrayList = new ArrayList<>();
        ArrayList arrayList2 = (ArrayList) obj;
        try {
            arrayList.add(0, bVar.b((String) arrayList2.get(0), (Double) arrayList2.get(1)));
        } catch (Throwable th) {
            arrayList = a.a(th);
        }
        eVar.a(arrayList);
    }

    public static /* synthetic */ void g(a.b bVar, Object obj, a.e eVar) {
        ArrayList<Object> arrayList = new ArrayList<>();
        ArrayList arrayList2 = (ArrayList) obj;
        try {
            arrayList.add(0, bVar.j((String) arrayList2.get(0), (List) arrayList2.get(1)));
        } catch (Throwable th) {
            arrayList = a.a(th);
        }
        eVar.a(arrayList);
    }

    public static /* synthetic */ void h(a.b bVar, Object obj, a.e eVar) {
        ArrayList<Object> arrayList = new ArrayList<>();
        ArrayList arrayList2 = (ArrayList) obj;
        try {
            arrayList.add(0, bVar.i((String) arrayList2.get(0), (List) arrayList2.get(1)));
        } catch (Throwable th) {
            arrayList = a.a(th);
        }
        eVar.a(arrayList);
    }

    public static /* synthetic */ void i(a.b bVar, Object obj, a.e eVar) {
        ArrayList<Object> arrayList = new ArrayList<>();
        ArrayList arrayList2 = (ArrayList) obj;
        try {
            arrayList.add(0, bVar.f((String) arrayList2.get(0), (List) arrayList2.get(1)));
        } catch (Throwable th) {
            arrayList = a.a(th);
        }
        eVar.a(arrayList);
    }

    public static void j(c cVar, a.b bVar) {
        r2.a aVar = new r2.a(cVar, "dev.flutter.pigeon.SharedPreferencesApi.remove", a(), cVar.f());
        if (bVar != null) {
            aVar.e(new b(bVar));
        } else {
            aVar.e((a.d) null);
        }
        r2.a aVar2 = new r2.a(cVar, "dev.flutter.pigeon.SharedPreferencesApi.setBool", a(), cVar.f());
        if (bVar != null) {
            aVar2.e(new c(bVar));
        } else {
            aVar2.e((a.d) null);
        }
        r2.a aVar3 = new r2.a(cVar, "dev.flutter.pigeon.SharedPreferencesApi.setString", a(), cVar.f());
        if (bVar != null) {
            aVar3.e(new d(bVar));
        } else {
            aVar3.e((a.d) null);
        }
        r2.a aVar4 = new r2.a(cVar, "dev.flutter.pigeon.SharedPreferencesApi.setInt", a(), cVar.f());
        if (bVar != null) {
            aVar4.e(new e(bVar));
        } else {
            aVar4.e((a.d) null);
        }
        r2.a aVar5 = new r2.a(cVar, "dev.flutter.pigeon.SharedPreferencesApi.setDouble", a(), cVar.f());
        if (bVar != null) {
            aVar5.e(new f(bVar));
        } else {
            aVar5.e((a.d) null);
        }
        r2.a aVar6 = new r2.a(cVar, "dev.flutter.pigeon.SharedPreferencesApi.setStringList", a(), cVar.f());
        if (bVar != null) {
            aVar6.e(new g(bVar));
        } else {
            aVar6.e((a.d) null);
        }
        r2.a aVar7 = new r2.a(cVar, "dev.flutter.pigeon.SharedPreferencesApi.clear", a(), cVar.f());
        if (bVar != null) {
            aVar7.e(new h(bVar));
        } else {
            aVar7.e((a.d) null);
        }
        r2.a aVar8 = new r2.a(cVar, "dev.flutter.pigeon.SharedPreferencesApi.getAll", a(), cVar.f());
        if (bVar != null) {
            aVar8.e(new i(bVar));
        } else {
            aVar8.e((a.d) null);
        }
    }
}
