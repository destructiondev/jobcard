package v2;

import r2.a;
import v2.a;

public final /* synthetic */ class d implements a.d {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ a.b f4610a;

    public /* synthetic */ d(a.b bVar) {
        this.f4610a = bVar;
    }

    public final void a(Object obj, a.e eVar) {
        j.d(this.f4610a, obj, eVar);
    }
}
