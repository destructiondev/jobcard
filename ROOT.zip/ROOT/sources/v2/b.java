package v2;

import r2.a;
import v2.a;

public final /* synthetic */ class b implements a.d {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ a.b f4608a;

    public /* synthetic */ b(a.b bVar) {
        this.f4608a = bVar;
    }

    public final void a(Object obj, a.e eVar) {
        j.b(this.f4608a, obj, eVar);
    }
}
