package v2;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Base64;
import android.util.Log;
import i2.a;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import r2.c;
import v2.a;

public class l implements i2.a, a.b {

    /* renamed from: a  reason: collision with root package name */
    private SharedPreferences f4616a;

    /* renamed from: b  reason: collision with root package name */
    private k f4617b;

    static class a implements k {
        a() {
        }

        public String a(List<String> list) {
            try {
                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                ObjectOutputStream objectOutputStream = new ObjectOutputStream(byteArrayOutputStream);
                objectOutputStream.writeObject(list);
                objectOutputStream.flush();
                return Base64.encodeToString(byteArrayOutputStream.toByteArray(), 0);
            } catch (IOException e4) {
                throw new RuntimeException(e4);
            }
        }

        public List<String> b(String str) {
            try {
                return (List) new ObjectInputStream(new ByteArrayInputStream(Base64.decode(str, 0))).readObject();
            } catch (IOException | ClassNotFoundException e4) {
                throw new RuntimeException(e4);
            }
        }
    }

    public l() {
        this(new a());
    }

    l(k kVar) {
        this.f4617b = kVar;
    }

    private Map<String, Object> k(String str, Set<String> set) {
        Map<String, ?> all = this.f4616a.getAll();
        HashMap hashMap = new HashMap();
        for (String next : all.keySet()) {
            if (next.startsWith(str) && (set == null || set.contains(next))) {
                hashMap.put(next, m(next, all.get(next)));
            }
        }
        return hashMap;
    }

    private void l(c cVar, Context context) {
        this.f4616a = context.getSharedPreferences("FlutterSharedPreferences", 0);
        try {
            j.j(cVar, this);
        } catch (Exception e4) {
            Log.e("SharedPreferencesPlugin", "Received exception while setting up SharedPreferencesPlugin", e4);
        }
    }

    private Object m(String str, Object obj) {
        if (obj instanceof String) {
            String str2 = (String) obj;
            if (str2.startsWith("VGhpcyBpcyB0aGUgcHJlZml4IGZvciBhIGxpc3Qu")) {
                return this.f4617b.b(str2.substring(40));
            }
            if (str2.startsWith("VGhpcyBpcyB0aGUgcHJlZml4IGZvciBCaWdJbnRlZ2Vy")) {
                return new BigInteger(str2.substring(44), 36);
            }
            if (str2.startsWith("VGhpcyBpcyB0aGUgcHJlZml4IGZvciBEb3VibGUu")) {
                return Double.valueOf(str2.substring(40));
            }
        } else if (obj instanceof Set) {
            ArrayList arrayList = new ArrayList((Set) obj);
            SharedPreferences.Editor remove = this.f4616a.edit().remove(str);
            remove.putString(str, "VGhpcyBpcyB0aGUgcHJlZml4IGZvciBhIGxpc3Qu" + this.f4617b.a(arrayList)).apply();
            return arrayList;
        }
        return obj;
    }

    public Boolean a(String str, Boolean bool) {
        return Boolean.valueOf(this.f4616a.edit().putBoolean(str, bool.booleanValue()).commit());
    }

    public Boolean b(String str, Double d4) {
        String d5 = Double.toString(d4.doubleValue());
        SharedPreferences.Editor edit = this.f4616a.edit();
        return Boolean.valueOf(edit.putString(str, "VGhpcyBpcyB0aGUgcHJlZml4IGZvciBEb3VibGUu" + d5).commit());
    }

    public void c(a.b bVar) {
        l(bVar.b(), bVar.a());
    }

    public Boolean d(String str) {
        return Boolean.valueOf(this.f4616a.edit().remove(str).commit());
    }

    public Boolean e(String str, Long l4) {
        return Boolean.valueOf(this.f4616a.edit().putLong(str, l4.longValue()).commit());
    }

    public Map<String, Object> f(String str, List<String> list) {
        return k(str, list == null ? null : new HashSet(list));
    }

    public void g(a.b bVar) {
        j.j(bVar.b(), (a.b) null);
    }

    public Boolean h(String str, String str2) {
        if (!str2.startsWith("VGhpcyBpcyB0aGUgcHJlZml4IGZvciBhIGxpc3Qu") && !str2.startsWith("VGhpcyBpcyB0aGUgcHJlZml4IGZvciBCaWdJbnRlZ2Vy") && !str2.startsWith("VGhpcyBpcyB0aGUgcHJlZml4IGZvciBEb3VibGUu")) {
            return Boolean.valueOf(this.f4616a.edit().putString(str, str2).commit());
        }
        throw new RuntimeException("StorageError: This string cannot be stored as it clashes with special identifier prefixes");
    }

    public Boolean i(String str, List<String> list) {
        SharedPreferences.Editor edit = this.f4616a.edit();
        Map<String, ?> all = this.f4616a.getAll();
        ArrayList arrayList = new ArrayList();
        for (String next : all.keySet()) {
            if (next.startsWith(str) && (list == null || list.contains(next))) {
                arrayList.add(next);
            }
        }
        Iterator it = arrayList.iterator();
        while (it.hasNext()) {
            edit.remove((String) it.next());
        }
        return Boolean.valueOf(edit.commit());
    }

    public Boolean j(String str, List<String> list) {
        SharedPreferences.Editor edit = this.f4616a.edit();
        return Boolean.valueOf(edit.putString(str, "VGhpcyBpcyB0aGUgcHJlZml4IGZvciBhIGxpc3Qu" + this.f4617b.a(list)).commit());
    }
}
