package v2;

import r2.a;
import v2.a;

public final /* synthetic */ class e implements a.d {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ a.b f4611a;

    public /* synthetic */ e(a.b bVar) {
        this.f4611a = bVar;
    }

    public final void a(Object obj, a.e eVar) {
        j.e(this.f4611a, obj, eVar);
    }
}
