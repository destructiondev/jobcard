package v2;

import r2.a;
import v2.a;

public final /* synthetic */ class c implements a.d {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ a.b f4609a;

    public /* synthetic */ c(a.b bVar) {
        this.f4609a = bVar;
    }

    public final void a(Object obj, a.e eVar) {
        j.c(this.f4609a, obj, eVar);
    }
}
