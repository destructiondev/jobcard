package v2;

import r2.a;
import v2.a;

public final /* synthetic */ class i implements a.d {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ a.b f4615a;

    public /* synthetic */ i(a.b bVar) {
        this.f4615a = bVar;
    }

    public final void a(Object obj, a.e eVar) {
        j.i(this.f4615a, obj, eVar);
    }
}
