package v2;

import r2.a;
import v2.a;

public final /* synthetic */ class g implements a.d {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ a.b f4613a;

    public /* synthetic */ g(a.b bVar) {
        this.f4613a = bVar;
    }

    public final void a(Object obj, a.e eVar) {
        j.g(this.f4613a, obj, eVar);
    }
}
