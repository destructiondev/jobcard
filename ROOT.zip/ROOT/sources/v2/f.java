package v2;

import r2.a;
import v2.a;

public final /* synthetic */ class f implements a.d {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ a.b f4612a;

    public /* synthetic */ f(a.b bVar) {
        this.f4612a = bVar;
    }

    public final void a(Object obj, a.e eVar) {
        j.f(this.f4612a, obj, eVar);
    }
}
