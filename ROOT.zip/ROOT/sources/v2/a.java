package v2;

import android.util.Log;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class a {

    /* renamed from: v2.a$a  reason: collision with other inner class name */
    public static class C0114a extends RuntimeException {

        /* renamed from: d  reason: collision with root package name */
        public final String f4606d;

        /* renamed from: e  reason: collision with root package name */
        public final Object f4607e;
    }

    public interface b {
        Boolean a(String str, Boolean bool);

        Boolean b(String str, Double d4);

        Boolean d(String str);

        Boolean e(String str, Long l4);

        Map<String, Object> f(String str, List<String> list);

        Boolean h(String str, String str2);

        Boolean i(String str, List<String> list);

        Boolean j(String str, List<String> list);
    }

    protected static ArrayList<Object> a(Throwable th) {
        Object obj;
        ArrayList<Object> arrayList = new ArrayList<>(3);
        if (th instanceof C0114a) {
            C0114a aVar = (C0114a) th;
            arrayList.add(aVar.f4606d);
            arrayList.add(aVar.getMessage());
            obj = aVar.f4607e;
        } else {
            arrayList.add(th.toString());
            arrayList.add(th.getClass().getSimpleName());
            obj = "Cause: " + th.getCause() + ", Stacktrace: " + Log.getStackTraceString(th);
        }
        arrayList.add(obj);
        return arrayList;
    }
}
