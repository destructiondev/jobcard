package v2;

import java.util.List;

public interface k {
    String a(List<String> list);

    List<String> b(String str);
}
