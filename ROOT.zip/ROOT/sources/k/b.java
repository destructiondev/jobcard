package k;

public final class b<T> implements j.b<T> {
}
