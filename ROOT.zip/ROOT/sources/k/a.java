package k;

import c3.d;
import j.b;

public final class a<T> implements b<T> {
    public Object a(j.a aVar, d<? super T> dVar) {
        throw aVar;
    }
}
