package p2;

public interface b {
    void c();

    void f();
}
