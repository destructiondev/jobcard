package p2;

import android.graphics.Rect;
import android.graphics.SurfaceTexture;
import android.os.Handler;
import android.view.Surface;
import io.flutter.embedding.engine.FlutterJNI;
import io.flutter.embedding.engine.renderer.SurfaceTextureWrapper;
import io.flutter.view.d;
import java.lang.ref.WeakReference;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.atomic.AtomicLong;

public class a implements io.flutter.view.d {
    /* access modifiers changed from: private */

    /* renamed from: a  reason: collision with root package name */
    public final FlutterJNI f3842a;

    /* renamed from: b  reason: collision with root package name */
    private final AtomicLong f3843b = new AtomicLong(0);

    /* renamed from: c  reason: collision with root package name */
    private Surface f3844c;
    /* access modifiers changed from: private */

    /* renamed from: d  reason: collision with root package name */
    public boolean f3845d = false;
    /* access modifiers changed from: private */

    /* renamed from: e  reason: collision with root package name */
    public Handler f3846e = new Handler();

    /* renamed from: f  reason: collision with root package name */
    private final Set<WeakReference<d.b>> f3847f = new HashSet();

    /* renamed from: g  reason: collision with root package name */
    private final b f3848g;

    /* renamed from: p2.a$a  reason: collision with other inner class name */
    class C0094a implements b {
        C0094a() {
        }

        public void c() {
            boolean unused = a.this.f3845d = false;
        }

        public void f() {
            boolean unused = a.this.f3845d = true;
        }
    }

    public static final class b {

        /* renamed from: a  reason: collision with root package name */
        public final Rect f3850a;

        /* renamed from: b  reason: collision with root package name */
        public final d f3851b;

        /* renamed from: c  reason: collision with root package name */
        public final c f3852c;

        public b(Rect rect, d dVar) {
            this.f3850a = rect;
            this.f3851b = dVar;
            this.f3852c = c.UNKNOWN;
        }

        public b(Rect rect, d dVar, c cVar) {
            this.f3850a = rect;
            this.f3851b = dVar;
            this.f3852c = cVar;
        }
    }

    public enum c {
        UNKNOWN(0),
        POSTURE_FLAT(1),
        POSTURE_HALF_OPENED(2);
        

        /* renamed from: d  reason: collision with root package name */
        public final int f3857d;

        private c(int i4) {
            this.f3857d = i4;
        }
    }

    public enum d {
        UNKNOWN(0),
        FOLD(1),
        HINGE(2),
        CUTOUT(3);
        

        /* renamed from: d  reason: collision with root package name */
        public final int f3863d;

        private d(int i4) {
            this.f3863d = i4;
        }
    }

    static final class e implements Runnable {

        /* renamed from: d  reason: collision with root package name */
        private final long f3864d;

        /* renamed from: e  reason: collision with root package name */
        private final FlutterJNI f3865e;

        e(long j4, FlutterJNI flutterJNI) {
            this.f3864d = j4;
            this.f3865e = flutterJNI;
        }

        public void run() {
            if (this.f3865e.isAttached()) {
                d2.b.f("FlutterRenderer", "Releasing a SurfaceTexture (" + this.f3864d + ").");
                this.f3865e.unregisterTexture(this.f3864d);
            }
        }
    }

    final class f implements d.c, d.b {
        /* access modifiers changed from: private */

        /* renamed from: a  reason: collision with root package name */
        public final long f3866a;

        /* renamed from: b  reason: collision with root package name */
        private final SurfaceTextureWrapper f3867b;
        /* access modifiers changed from: private */

        /* renamed from: c  reason: collision with root package name */
        public boolean f3868c;

        /* renamed from: d  reason: collision with root package name */
        private d.b f3869d;
        /* access modifiers changed from: private */

        /* renamed from: e  reason: collision with root package name */
        public d.a f3870e;

        /* renamed from: f  reason: collision with root package name */
        private final Runnable f3871f;

        /* renamed from: g  reason: collision with root package name */
        private SurfaceTexture.OnFrameAvailableListener f3872g = new b();

        /* renamed from: p2.a$f$a  reason: collision with other inner class name */
        class C0095a implements Runnable {
            C0095a() {
            }

            public void run() {
                if (f.this.f3870e != null) {
                    f.this.f3870e.a();
                }
            }
        }

        class b implements SurfaceTexture.OnFrameAvailableListener {
            b() {
            }

            public void onFrameAvailable(SurfaceTexture surfaceTexture) {
                if (!f.this.f3868c && a.this.f3842a.isAttached()) {
                    f fVar = f.this;
                    a.this.l(fVar.f3866a);
                }
            }
        }

        f(long j4, SurfaceTexture surfaceTexture) {
            C0095a aVar = new C0095a();
            this.f3871f = aVar;
            this.f3866a = j4;
            this.f3867b = new SurfaceTextureWrapper(surfaceTexture, aVar);
            d().setOnFrameAvailableListener(this.f3872g, new Handler());
        }

        public long a() {
            return this.f3866a;
        }

        public void b(d.b bVar) {
            this.f3869d = bVar;
        }

        public void c(d.a aVar) {
            this.f3870e = aVar;
        }

        public SurfaceTexture d() {
            return this.f3867b.surfaceTexture();
        }

        /* access modifiers changed from: protected */
        public void finalize() {
            try {
                if (!this.f3868c) {
                    a.this.f3846e.post(new e(this.f3866a, a.this.f3842a));
                    super.finalize();
                }
            } finally {
                super.finalize();
            }
        }

        public SurfaceTextureWrapper h() {
            return this.f3867b;
        }

        public void onTrimMemory(int i4) {
            d.b bVar = this.f3869d;
            if (bVar != null) {
                bVar.onTrimMemory(i4);
            }
        }
    }

    public static final class g {

        /* renamed from: a  reason: collision with root package name */
        public float f3876a = 1.0f;

        /* renamed from: b  reason: collision with root package name */
        public int f3877b = 0;

        /* renamed from: c  reason: collision with root package name */
        public int f3878c = 0;

        /* renamed from: d  reason: collision with root package name */
        public int f3879d = 0;

        /* renamed from: e  reason: collision with root package name */
        public int f3880e = 0;

        /* renamed from: f  reason: collision with root package name */
        public int f3881f = 0;

        /* renamed from: g  reason: collision with root package name */
        public int f3882g = 0;

        /* renamed from: h  reason: collision with root package name */
        public int f3883h = 0;

        /* renamed from: i  reason: collision with root package name */
        public int f3884i = 0;

        /* renamed from: j  reason: collision with root package name */
        public int f3885j = 0;

        /* renamed from: k  reason: collision with root package name */
        public int f3886k = 0;

        /* renamed from: l  reason: collision with root package name */
        public int f3887l = 0;

        /* renamed from: m  reason: collision with root package name */
        public int f3888m = 0;

        /* renamed from: n  reason: collision with root package name */
        public int f3889n = 0;

        /* renamed from: o  reason: collision with root package name */
        public int f3890o = 0;

        /* renamed from: p  reason: collision with root package name */
        public int f3891p = -1;

        /* renamed from: q  reason: collision with root package name */
        public List<b> f3892q = new ArrayList();

        /* access modifiers changed from: package-private */
        public boolean a() {
            return this.f3877b > 0 && this.f3878c > 0 && this.f3876a > 0.0f;
        }
    }

    public a(FlutterJNI flutterJNI) {
        C0094a aVar = new C0094a();
        this.f3848g = aVar;
        this.f3842a = flutterJNI;
        flutterJNI.addIsDisplayingFlutterUiListener(aVar);
    }

    private void h() {
        Iterator<WeakReference<d.b>> it = this.f3847f.iterator();
        while (it.hasNext()) {
            if (((d.b) it.next().get()) == null) {
                it.remove();
            }
        }
    }

    /* access modifiers changed from: private */
    public void l(long j4) {
        this.f3842a.markTextureFrameAvailable(j4);
    }

    private void o(long j4, SurfaceTextureWrapper surfaceTextureWrapper) {
        this.f3842a.registerTexture(j4, surfaceTextureWrapper);
    }

    public d.c a() {
        d2.b.f("FlutterRenderer", "Creating a SurfaceTexture.");
        return n(new SurfaceTexture(0));
    }

    public void f(b bVar) {
        this.f3842a.addIsDisplayingFlutterUiListener(bVar);
        if (this.f3845d) {
            bVar.f();
        }
    }

    /* access modifiers changed from: package-private */
    public void g(d.b bVar) {
        h();
        this.f3847f.add(new WeakReference(bVar));
    }

    public void i(ByteBuffer byteBuffer, int i4) {
        this.f3842a.dispatchPointerDataPacket(byteBuffer, i4);
    }

    public boolean j() {
        return this.f3845d;
    }

    public boolean k() {
        return this.f3842a.getIsSoftwareRenderingEnabled();
    }

    public void m(int i4) {
        Iterator<WeakReference<d.b>> it = this.f3847f.iterator();
        while (it.hasNext()) {
            d.b bVar = (d.b) it.next().get();
            if (bVar != null) {
                bVar.onTrimMemory(i4);
            } else {
                it.remove();
            }
        }
    }

    public d.c n(SurfaceTexture surfaceTexture) {
        surfaceTexture.detachFromGLContext();
        f fVar = new f(this.f3843b.getAndIncrement(), surfaceTexture);
        d2.b.f("FlutterRenderer", "New SurfaceTexture ID: " + fVar.a());
        o(fVar.a(), fVar.h());
        g(fVar);
        return fVar;
    }

    public void p(b bVar) {
        this.f3842a.removeIsDisplayingFlutterUiListener(bVar);
    }

    public void q(boolean z3) {
        this.f3842a.setSemanticsEnabled(z3);
    }

    public void r(g gVar) {
        g gVar2 = gVar;
        if (gVar.a()) {
            d2.b.f("FlutterRenderer", "Setting viewport metrics\nSize: " + gVar2.f3877b + " x " + gVar2.f3878c + "\nPadding - L: " + gVar2.f3882g + ", T: " + gVar2.f3879d + ", R: " + gVar2.f3880e + ", B: " + gVar2.f3881f + "\nInsets - L: " + gVar2.f3886k + ", T: " + gVar2.f3883h + ", R: " + gVar2.f3884i + ", B: " + gVar2.f3885j + "\nSystem Gesture Insets - L: " + gVar2.f3890o + ", T: " + gVar2.f3887l + ", R: " + gVar2.f3888m + ", B: " + gVar2.f3888m + "\nDisplay Features: " + gVar2.f3892q.size());
            int[] iArr = new int[(gVar2.f3892q.size() * 4)];
            int[] iArr2 = new int[gVar2.f3892q.size()];
            int[] iArr3 = new int[gVar2.f3892q.size()];
            for (int i4 = 0; i4 < gVar2.f3892q.size(); i4++) {
                b bVar = gVar2.f3892q.get(i4);
                int i5 = i4 * 4;
                Rect rect = bVar.f3850a;
                iArr[i5] = rect.left;
                iArr[i5 + 1] = rect.top;
                iArr[i5 + 2] = rect.right;
                iArr[i5 + 3] = rect.bottom;
                iArr2[i4] = bVar.f3851b.f3863d;
                iArr3[i4] = bVar.f3852c.f3857d;
            }
            int[] iArr4 = iArr3;
            FlutterJNI flutterJNI = this.f3842a;
            flutterJNI.setViewportMetrics(gVar2.f3876a, gVar2.f3877b, gVar2.f3878c, gVar2.f3879d, gVar2.f3880e, gVar2.f3881f, gVar2.f3882g, gVar2.f3883h, gVar2.f3884i, gVar2.f3885j, gVar2.f3886k, gVar2.f3887l, gVar2.f3888m, gVar2.f3889n, gVar2.f3890o, gVar2.f3891p, iArr, iArr2, iArr4);
        }
    }

    public void s(Surface surface, boolean z3) {
        if (this.f3844c != null && !z3) {
            t();
        }
        this.f3844c = surface;
        this.f3842a.onSurfaceCreated(surface);
    }

    public void t() {
        this.f3842a.onSurfaceDestroyed();
        this.f3844c = null;
        if (this.f3845d) {
            this.f3848g.c();
        }
        this.f3845d = false;
    }

    public void u(int i4, int i5) {
        this.f3842a.onSurfaceChanged(i4, i5);
    }

    public void v(Surface surface) {
        this.f3844c = surface;
        this.f3842a.onSurfaceWindowChanged(surface);
    }
}
