package p2;

public interface c {
    void a();

    void b(a aVar);

    void c();

    a getAttachedRenderer();
}
