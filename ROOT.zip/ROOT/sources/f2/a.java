package f2;

import io.flutter.embedding.engine.FlutterJNI;
import q2.b;

public interface a {
    void a(b bVar);

    String b(int i4, String str);

    void c();

    void d(int i4, String str);

    boolean e(int i4, String str);

    void f(FlutterJNI flutterJNI);
}
