package r0;

import l0.b;

public class k extends Exception {
    @Deprecated
    protected k() {
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public k(String str) {
        super(str);
        b.c(str, "Detail message must not be empty");
    }
}
