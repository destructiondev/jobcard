package r0;

import android.content.Context;
import com.google.firebase.FirebaseCommonRegistrar;
import y1.h;

public final /* synthetic */ class h implements h.a {

    /* renamed from: a  reason: collision with root package name */
    public static final /* synthetic */ h f4147a = new h();

    private /* synthetic */ h() {
    }

    public final String a(Object obj) {
        return FirebaseCommonRegistrar.e((Context) obj);
    }
}
