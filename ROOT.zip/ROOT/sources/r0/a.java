package r0;

final class a extends m {

    /* renamed from: a  reason: collision with root package name */
    private final long f4124a;

    /* renamed from: b  reason: collision with root package name */
    private final long f4125b;

    /* renamed from: c  reason: collision with root package name */
    private final long f4126c;

    a(long j4, long j5, long j6) {
        this.f4124a = j4;
        this.f4125b = j5;
        this.f4126c = j6;
    }

    public long b() {
        return this.f4125b;
    }

    public long c() {
        return this.f4124a;
    }

    public long d() {
        return this.f4126c;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof m)) {
            return false;
        }
        m mVar = (m) obj;
        return this.f4124a == mVar.c() && this.f4125b == mVar.b() && this.f4126c == mVar.d();
    }

    public int hashCode() {
        long j4 = this.f4124a;
        long j5 = this.f4125b;
        long j6 = this.f4126c;
        return ((int) ((j6 >>> 32) ^ j6)) ^ ((((((int) (j4 ^ (j4 >>> 32))) ^ 1000003) * 1000003) ^ ((int) (j5 ^ (j5 >>> 32)))) * 1000003);
    }

    public String toString() {
        return "StartupTime{epochMillis=" + this.f4124a + ", elapsedRealtime=" + this.f4125b + ", uptimeMillis=" + this.f4126c + "}";
    }
}
