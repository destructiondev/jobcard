package r0;

public interface f {
    void a(String str, l lVar);
}
