package r0;

import android.os.SystemClock;

public abstract class m {
    public static m a(long j4, long j5, long j6) {
        return new a(j4, j5, j6);
    }

    public static m e() {
        return a(System.currentTimeMillis(), SystemClock.elapsedRealtime(), SystemClock.uptimeMillis());
    }

    public abstract long b();

    public abstract long c();

    public abstract long d();
}
