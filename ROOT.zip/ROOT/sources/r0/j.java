package r0;

import android.content.Context;
import com.google.firebase.FirebaseCommonRegistrar;
import y1.h;

public final /* synthetic */ class j implements h.a {

    /* renamed from: a  reason: collision with root package name */
    public static final /* synthetic */ j f4149a = new j();

    private /* synthetic */ j() {
    }

    public final String a(Object obj) {
        return FirebaseCommonRegistrar.g((Context) obj);
    }
}
