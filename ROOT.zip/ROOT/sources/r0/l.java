package r0;

import android.content.Context;
import android.text.TextUtils;
import l0.c;
import m0.g;

public final class l {

    /* renamed from: a  reason: collision with root package name */
    private final String f4150a;

    /* renamed from: b  reason: collision with root package name */
    private final String f4151b;

    /* renamed from: c  reason: collision with root package name */
    private final String f4152c;

    /* renamed from: d  reason: collision with root package name */
    private final String f4153d;

    /* renamed from: e  reason: collision with root package name */
    private final String f4154e;

    /* renamed from: f  reason: collision with root package name */
    private final String f4155f;

    /* renamed from: g  reason: collision with root package name */
    private final String f4156g;

    public static final class b {

        /* renamed from: a  reason: collision with root package name */
        private String f4157a;

        /* renamed from: b  reason: collision with root package name */
        private String f4158b;

        /* renamed from: c  reason: collision with root package name */
        private String f4159c;

        /* renamed from: d  reason: collision with root package name */
        private String f4160d;

        /* renamed from: e  reason: collision with root package name */
        private String f4161e;

        /* renamed from: f  reason: collision with root package name */
        private String f4162f;

        /* renamed from: g  reason: collision with root package name */
        private String f4163g;

        public l a() {
            return new l(this.f4158b, this.f4157a, this.f4159c, this.f4160d, this.f4161e, this.f4162f, this.f4163g);
        }

        public b b(String str) {
            this.f4157a = l0.b.c(str, "ApiKey must be set.");
            return this;
        }

        public b c(String str) {
            this.f4158b = l0.b.c(str, "ApplicationId must be set.");
            return this;
        }

        public b d(String str) {
            this.f4159c = str;
            return this;
        }

        public b e(String str) {
            this.f4160d = str;
            return this;
        }

        public b f(String str) {
            this.f4161e = str;
            return this;
        }

        public b g(String str) {
            this.f4163g = str;
            return this;
        }

        public b h(String str) {
            this.f4162f = str;
            return this;
        }
    }

    private l(String str, String str2, String str3, String str4, String str5, String str6, String str7) {
        l0.b.h(!g.a(str), "ApplicationId must be set.");
        this.f4151b = str;
        this.f4150a = str2;
        this.f4152c = str3;
        this.f4153d = str4;
        this.f4154e = str5;
        this.f4155f = str6;
        this.f4156g = str7;
    }

    public static l a(Context context) {
        c cVar = new c(context);
        String a4 = cVar.a("google_app_id");
        if (TextUtils.isEmpty(a4)) {
            return null;
        }
        return new l(a4, cVar.a("google_api_key"), cVar.a("firebase_database_url"), cVar.a("ga_trackingId"), cVar.a("gcm_defaultSenderId"), cVar.a("google_storage_bucket"), cVar.a("project_id"));
    }

    public String b() {
        return this.f4150a;
    }

    public String c() {
        return this.f4151b;
    }

    public String d() {
        return this.f4152c;
    }

    public String e() {
        return this.f4153d;
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof l)) {
            return false;
        }
        l lVar = (l) obj;
        return l0.a.a(this.f4151b, lVar.f4151b) && l0.a.a(this.f4150a, lVar.f4150a) && l0.a.a(this.f4152c, lVar.f4152c) && l0.a.a(this.f4153d, lVar.f4153d) && l0.a.a(this.f4154e, lVar.f4154e) && l0.a.a(this.f4155f, lVar.f4155f) && l0.a.a(this.f4156g, lVar.f4156g);
    }

    public String f() {
        return this.f4154e;
    }

    public String g() {
        return this.f4156g;
    }

    public String h() {
        return this.f4155f;
    }

    public int hashCode() {
        return l0.a.b(this.f4151b, this.f4150a, this.f4152c, this.f4153d, this.f4154e, this.f4155f, this.f4156g);
    }

    public String toString() {
        return l0.a.c(this).a("applicationId", this.f4151b).a("apiKey", this.f4150a).a("databaseUrl", this.f4152c).a("gcmSenderId", this.f4154e).a("storageBucket", this.f4155f).a("projectId", this.f4156g).toString();
    }
}
