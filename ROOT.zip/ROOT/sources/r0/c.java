package r0;

import r0.e;

public final /* synthetic */ class c implements e.a {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ e f4128a;

    public /* synthetic */ c(e eVar) {
        this.f4128a = eVar;
    }

    public final void a(boolean z3) {
        this.f4128a.A(z3);
    }
}
