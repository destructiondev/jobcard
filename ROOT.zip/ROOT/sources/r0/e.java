package r0;

import android.app.Application;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.text.TextUtils;
import android.util.Log;
import com.google.firebase.FirebaseCommonRegistrar;
import com.google.firebase.components.ComponentDiscoveryService;
import com.google.firebase.components.ComponentRegistrar;
import com.google.firebase.concurrent.ExecutorsRegistrar;
import com.google.firebase.provider.FirebaseInitProvider;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;
import k0.a;
import q1.f;
import u0.g;
import u0.o;
import u0.x;
import v0.k;

public class e {
    /* access modifiers changed from: private */

    /* renamed from: k  reason: collision with root package name */
    public static final Object f4131k = new Object();

    /* renamed from: l  reason: collision with root package name */
    static final Map<String, e> f4132l = new f.a();

    /* renamed from: a  reason: collision with root package name */
    private final Context f4133a;

    /* renamed from: b  reason: collision with root package name */
    private final String f4134b;

    /* renamed from: c  reason: collision with root package name */
    private final l f4135c;

    /* renamed from: d  reason: collision with root package name */
    private final o f4136d;
    /* access modifiers changed from: private */

    /* renamed from: e  reason: collision with root package name */
    public final AtomicBoolean f4137e = new AtomicBoolean(false);

    /* renamed from: f  reason: collision with root package name */
    private final AtomicBoolean f4138f = new AtomicBoolean();

    /* renamed from: g  reason: collision with root package name */
    private final x<x1.a> f4139g;

    /* renamed from: h  reason: collision with root package name */
    private final r1.b<f> f4140h;

    /* renamed from: i  reason: collision with root package name */
    private final List<a> f4141i = new CopyOnWriteArrayList();

    /* renamed from: j  reason: collision with root package name */
    private final List<f> f4142j = new CopyOnWriteArrayList();

    public interface a {
        void a(boolean z3);
    }

    private static class b implements a.C0082a {

        /* renamed from: a  reason: collision with root package name */
        private static AtomicReference<b> f4143a = new AtomicReference<>();

        private b() {
        }

        /* access modifiers changed from: private */
        public static void c(Context context) {
            if (m0.e.a() && (context.getApplicationContext() instanceof Application)) {
                Application application = (Application) context.getApplicationContext();
                if (f4143a.get() == null) {
                    b bVar = new b();
                    if (f4143a.compareAndSet((Object) null, bVar)) {
                        k0.a.c(application);
                        k0.a.b().a(bVar);
                    }
                }
            }
        }

        public void a(boolean z3) {
            synchronized (e.f4131k) {
                Iterator it = new ArrayList(e.f4132l.values()).iterator();
                while (it.hasNext()) {
                    e eVar = (e) it.next();
                    if (eVar.f4137e.get()) {
                        eVar.C(z3);
                    }
                }
            }
        }
    }

    private static class c extends BroadcastReceiver {

        /* renamed from: b  reason: collision with root package name */
        private static AtomicReference<c> f4144b = new AtomicReference<>();

        /* renamed from: a  reason: collision with root package name */
        private final Context f4145a;

        public c(Context context) {
            this.f4145a = context;
        }

        /* access modifiers changed from: private */
        public static void b(Context context) {
            if (f4144b.get() == null) {
                c cVar = new c(context);
                if (f4144b.compareAndSet((Object) null, cVar)) {
                    context.registerReceiver(cVar, new IntentFilter("android.intent.action.USER_UNLOCKED"));
                }
            }
        }

        public void c() {
            this.f4145a.unregisterReceiver(this);
        }

        public void onReceive(Context context, Intent intent) {
            synchronized (e.f4131k) {
                for (e d4 : e.f4132l.values()) {
                    d4.t();
                }
            }
            c();
        }
    }

    protected e(Context context, String str, l lVar) {
        this.f4133a = (Context) l0.b.f(context);
        this.f4134b = l0.b.b(str);
        this.f4135c = (l) l0.b.f(lVar);
        m b4 = FirebaseInitProvider.b();
        c2.c.b("Firebase");
        c2.c.b("ComponentDiscovery");
        List<r1.b<ComponentRegistrar>> b5 = g.c(context, ComponentDiscoveryService.class).b();
        c2.c.a();
        c2.c.b("Runtime");
        o.b g4 = o.m(k.INSTANCE).d(b5).c(new FirebaseCommonRegistrar()).c(new ExecutorsRegistrar()).b(u0.c.s(context, Context.class, new Class[0])).b(u0.c.s(this, e.class, new Class[0])).b(u0.c.s(lVar, l.class, new Class[0])).g(new c2.b());
        if (androidx.core.os.f.a(context) && FirebaseInitProvider.c()) {
            g4.b(u0.c.s(b4, m.class, new Class[0]));
        }
        o e4 = g4.e();
        this.f4136d = e4;
        c2.c.a();
        this.f4139g = new x<>(new d(this, context));
        this.f4140h = e4.d(f.class);
        g(new c(this));
        c2.c.a();
    }

    /* access modifiers changed from: private */
    public /* synthetic */ void A(boolean z3) {
        if (!z3) {
            this.f4140h.get().k();
        }
    }

    private static String B(String str) {
        return str.trim();
    }

    /* access modifiers changed from: private */
    public void C(boolean z3) {
        Log.d("FirebaseApp", "Notifying background state change listeners.");
        for (a a4 : this.f4141i) {
            a4.a(z3);
        }
    }

    private void D() {
        for (f a4 : this.f4142j) {
            a4.a(this.f4134b, this.f4135c);
        }
    }

    private void i() {
        l0.b.h(!this.f4138f.get(), "FirebaseApp was deleted");
    }

    private static List<String> l() {
        ArrayList arrayList = new ArrayList();
        synchronized (f4131k) {
            for (e q4 : f4132l.values()) {
                arrayList.add(q4.q());
            }
        }
        Collections.sort(arrayList);
        return arrayList;
    }

    public static List<e> n(Context context) {
        ArrayList arrayList;
        synchronized (f4131k) {
            arrayList = new ArrayList(f4132l.values());
        }
        return arrayList;
    }

    public static e o() {
        e eVar;
        synchronized (f4131k) {
            eVar = f4132l.get("[DEFAULT]");
            if (eVar != null) {
                eVar.f4140h.get().k();
            } else {
                throw new IllegalStateException("Default FirebaseApp is not initialized in this process " + m0.f.a() + ". Make sure to call FirebaseApp.initializeApp(Context) first.");
            }
        }
        return eVar;
    }

    public static e p(String str) {
        e eVar;
        String str2;
        synchronized (f4131k) {
            eVar = f4132l.get(B(str));
            if (eVar != null) {
                eVar.f4140h.get().k();
            } else {
                List<String> l4 = l();
                if (l4.isEmpty()) {
                    str2 = "";
                } else {
                    str2 = "Available app names: " + TextUtils.join(", ", l4);
                }
                throw new IllegalStateException(String.format("FirebaseApp with name %s doesn't exist. %s", new Object[]{str, str2}));
            }
        }
        return eVar;
    }

    /* access modifiers changed from: private */
    public void t() {
        if (!androidx.core.os.f.a(this.f4133a)) {
            Log.i("FirebaseApp", "Device in Direct Boot Mode: postponing initialization of Firebase APIs for app " + q());
            c.b(this.f4133a);
            return;
        }
        Log.i("FirebaseApp", "Device unlocked: initializing all Firebase APIs for app " + q());
        this.f4136d.p(y());
        this.f4140h.get().k();
    }

    public static e u(Context context) {
        synchronized (f4131k) {
            if (f4132l.containsKey("[DEFAULT]")) {
                e o4 = o();
                return o4;
            }
            l a4 = l.a(context);
            if (a4 == null) {
                Log.w("FirebaseApp", "Default FirebaseApp failed to initialize because no default options were found. This usually means that com.google.gms:google-services was not applied to your gradle project.");
                return null;
            }
            e v4 = v(context, a4);
            return v4;
        }
    }

    public static e v(Context context, l lVar) {
        return w(context, lVar, "[DEFAULT]");
    }

    public static e w(Context context, l lVar, String str) {
        e eVar;
        b.c(context);
        String B = B(str);
        if (context.getApplicationContext() != null) {
            context = context.getApplicationContext();
        }
        synchronized (f4131k) {
            Map<String, e> map = f4132l;
            boolean z3 = !map.containsKey(B);
            l0.b.h(z3, "FirebaseApp name " + B + " already exists!");
            l0.b.g(context, "Application context cannot be null.");
            eVar = new e(context, B, lVar);
            map.put(B, eVar);
        }
        eVar.t();
        return eVar;
    }

    /* access modifiers changed from: private */
    public /* synthetic */ x1.a z(Context context) {
        return new x1.a(context, s(), (p1.c) this.f4136d.a(p1.c.class));
    }

    public void E(boolean z3) {
        boolean z4;
        i();
        if (this.f4137e.compareAndSet(!z3, z3)) {
            boolean d4 = k0.a.b().d();
            if (z3 && d4) {
                z4 = true;
            } else if (!z3 && d4) {
                z4 = false;
            } else {
                return;
            }
            C(z4);
        }
    }

    public void F(Boolean bool) {
        i();
        this.f4139g.get().e(bool);
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof e)) {
            return false;
        }
        return this.f4134b.equals(((e) obj).q());
    }

    public void g(a aVar) {
        i();
        if (this.f4137e.get() && k0.a.b().d()) {
            aVar.a(true);
        }
        this.f4141i.add(aVar);
    }

    public void h(f fVar) {
        i();
        l0.b.f(fVar);
        this.f4142j.add(fVar);
    }

    public int hashCode() {
        return this.f4134b.hashCode();
    }

    public void j() {
        if (this.f4138f.compareAndSet(false, true)) {
            synchronized (f4131k) {
                f4132l.remove(this.f4134b);
            }
            D();
        }
    }

    public <T> T k(Class<T> cls) {
        i();
        return this.f4136d.a(cls);
    }

    public Context m() {
        i();
        return this.f4133a;
    }

    public String q() {
        i();
        return this.f4134b;
    }

    public l r() {
        i();
        return this.f4135c;
    }

    public String s() {
        return m0.b.a(q().getBytes(Charset.defaultCharset())) + "+" + m0.b.a(r().c().getBytes(Charset.defaultCharset()));
    }

    public String toString() {
        return l0.a.c(this).a("name", this.f4134b).a("options", this.f4135c).toString();
    }

    public boolean x() {
        i();
        return this.f4139g.get().b();
    }

    public boolean y() {
        return "[DEFAULT]".equals(q());
    }
}
