package r0;

public final class b {

    /* renamed from: a  reason: collision with root package name */
    public final boolean f4127a;

    public b(boolean z3) {
        this.f4127a = z3;
    }
}
