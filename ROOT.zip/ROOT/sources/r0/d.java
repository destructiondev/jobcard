package r0;

import android.content.Context;
import r1.b;

public final /* synthetic */ class d implements b {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ e f4129a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ Context f4130b;

    public /* synthetic */ d(e eVar, Context context) {
        this.f4129a = eVar;
        this.f4130b = context;
    }

    public final Object get() {
        return this.f4129a.z(this.f4130b);
    }
}
