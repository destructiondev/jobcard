package r0;

import android.content.Context;
import com.google.firebase.FirebaseCommonRegistrar;
import y1.h;

public final /* synthetic */ class i implements h.a {

    /* renamed from: a  reason: collision with root package name */
    public static final /* synthetic */ i f4148a = new i();

    private /* synthetic */ i() {
    }

    public final String a(Object obj) {
        return FirebaseCommonRegistrar.f((Context) obj);
    }
}
