package e1;

public class c {

    /* renamed from: a  reason: collision with root package name */
    private final int f1893a;

    /* renamed from: b  reason: collision with root package name */
    private final String f1894b;

    public c(int i4, String str) {
        this.f1893a = i4;
        this.f1894b = str;
    }

    public String a() {
        return this.f1894b;
    }

    public int b() {
        return this.f1893a;
    }
}
