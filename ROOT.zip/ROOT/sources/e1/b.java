package e1;

import java.util.Map;

public class b {
    public a a(String str, Map<String, String> map) {
        return new a(str, map);
    }
}
