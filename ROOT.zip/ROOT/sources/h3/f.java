package h3;

import java.io.File;
import kotlin.jvm.internal.i;

class f extends e {
    public static String a(File file) {
        i.e(file, "<this>");
        String name = file.getName();
        i.d(name, "name");
        return p.W(name, '.', "");
    }
}
