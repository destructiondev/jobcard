package h3;

class d extends c {
}
