package h3;

public final class b extends f {
}
