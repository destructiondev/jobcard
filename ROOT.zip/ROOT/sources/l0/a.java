package l0;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public final class a {

    /* renamed from: l0.a$a  reason: collision with other inner class name */
    public static final class C0089a {

        /* renamed from: a  reason: collision with root package name */
        private final List f3657a = new ArrayList();

        /* renamed from: b  reason: collision with root package name */
        private final Object f3658b;

        /* synthetic */ C0089a(Object obj, d dVar) {
            b.f(obj);
            this.f3658b = obj;
        }

        public C0089a a(String str, Object obj) {
            List list = this.f3657a;
            b.f(str);
            String valueOf = String.valueOf(obj);
            list.add(str + "=" + valueOf);
            return this;
        }

        public String toString() {
            StringBuilder sb = new StringBuilder(100);
            sb.append(this.f3658b.getClass().getSimpleName());
            sb.append('{');
            int size = this.f3657a.size();
            for (int i4 = 0; i4 < size; i4++) {
                sb.append((String) this.f3657a.get(i4));
                if (i4 < size - 1) {
                    sb.append(", ");
                }
            }
            sb.append('}');
            return sb.toString();
        }
    }

    public static boolean a(Object obj, Object obj2) {
        return obj == obj2 || (obj != null && obj.equals(obj2));
    }

    public static int b(Object... objArr) {
        return Arrays.hashCode(objArr);
    }

    public static C0089a c(Object obj) {
        return new C0089a(obj, (d) null);
    }
}
