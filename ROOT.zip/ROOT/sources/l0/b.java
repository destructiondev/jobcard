package l0;

import android.text.TextUtils;
import java.util.Objects;
import m0.h;
import org.checkerframework.checker.nullness.qual.EnsuresNonNull;

public final class b {
    public static void a(boolean z3, Object obj) {
        if (!z3) {
            throw new IllegalArgumentException(String.valueOf(obj));
        }
    }

    @EnsuresNonNull({"#1"})
    public static String b(String str) {
        if (!TextUtils.isEmpty(str)) {
            return str;
        }
        throw new IllegalArgumentException("Given String is empty or null");
    }

    @EnsuresNonNull({"#1"})
    public static String c(String str, Object obj) {
        if (!TextUtils.isEmpty(str)) {
            return str;
        }
        throw new IllegalArgumentException(String.valueOf(obj));
    }

    public static void d() {
        e("Must not be called on the main application thread");
    }

    public static void e(String str) {
        if (h.a()) {
            throw new IllegalStateException(str);
        }
    }

    @EnsuresNonNull({"#1"})
    public static <T> T f(T t4) {
        Objects.requireNonNull(t4, "null reference");
        return t4;
    }

    @EnsuresNonNull({"#1"})
    public static <T> T g(T t4, Object obj) {
        if (t4 != null) {
            return t4;
        }
        throw new NullPointerException(String.valueOf(obj));
    }

    public static void h(boolean z3, Object obj) {
        if (!z3) {
            throw new IllegalStateException(String.valueOf(obj));
        }
    }
}
