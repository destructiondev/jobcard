package l0;

import android.content.Context;
import android.content.res.Resources;
import j0.a;

public class c {

    /* renamed from: a  reason: collision with root package name */
    private final Resources f3659a;

    /* renamed from: b  reason: collision with root package name */
    private final String f3660b;

    public c(Context context) {
        b.f(context);
        Resources resources = context.getResources();
        this.f3659a = resources;
        this.f3660b = resources.getResourcePackageName(a.common_google_play_services_unknown_issue);
    }

    public String a(String str) {
        int identifier = this.f3659a.getIdentifier(str, "string", this.f3660b);
        if (identifier == 0) {
            return null;
        }
        return this.f3659a.getString(identifier);
    }
}
