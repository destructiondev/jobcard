package o0;

import android.os.Handler;
import android.os.Looper;

public final class a extends Handler {
    public a(Looper looper) {
        super(looper);
    }
}
