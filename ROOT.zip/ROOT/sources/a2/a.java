package a2;

import a2.b;
import android.util.Log;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import kotlin.coroutines.jvm.internal.d;
import kotlin.coroutines.jvm.internal.f;
import kotlin.jvm.internal.e;
import kotlin.jvm.internal.i;
import kotlinx.coroutines.sync.b;

public final class a {

    /* renamed from: a  reason: collision with root package name */
    public static final a f238a = new a();

    /* renamed from: b  reason: collision with root package name */
    private static final Map<b.a, C0003a> f239b = Collections.synchronizedMap(new LinkedHashMap());

    /* renamed from: a2.a$a  reason: collision with other inner class name */
    private static final class C0003a {

        /* renamed from: a  reason: collision with root package name */
        private final kotlinx.coroutines.sync.b f240a;

        /* renamed from: b  reason: collision with root package name */
        private b f241b;

        public C0003a(kotlinx.coroutines.sync.b bVar, b bVar2) {
            i.e(bVar, "mutex");
            this.f240a = bVar;
            this.f241b = bVar2;
        }

        /* JADX INFO: this call moved to the top of the method (can break code semantics) */
        public /* synthetic */ C0003a(kotlinx.coroutines.sync.b bVar, b bVar2, int i4, e eVar) {
            this(bVar, (i4 & 2) != 0 ? null : bVar2);
        }

        public final kotlinx.coroutines.sync.b a() {
            return this.f240a;
        }

        public final b b() {
            return this.f241b;
        }

        public final void c(b bVar) {
            this.f241b = bVar;
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof C0003a)) {
                return false;
            }
            C0003a aVar = (C0003a) obj;
            return i.a(this.f240a, aVar.f240a) && i.a(this.f241b, aVar.f241b);
        }

        public int hashCode() {
            int hashCode = this.f240a.hashCode() * 31;
            b bVar = this.f241b;
            return hashCode + (bVar == null ? 0 : bVar.hashCode());
        }

        public String toString() {
            return "Dependency(mutex=" + this.f240a + ", subscriber=" + this.f241b + ')';
        }
    }

    @f(c = "com.google.firebase.sessions.api.FirebaseSessionsDependencies", f = "FirebaseSessionsDependencies.kt", l = {107}, m = "getRegisteredSubscribers$com_google_firebase_firebase_sessions")
    static final class b extends d {

        /* renamed from: d  reason: collision with root package name */
        Object f242d;

        /* renamed from: e  reason: collision with root package name */
        Object f243e;

        /* renamed from: f  reason: collision with root package name */
        Object f244f;

        /* renamed from: g  reason: collision with root package name */
        Object f245g;

        /* renamed from: h  reason: collision with root package name */
        Object f246h;

        /* renamed from: i  reason: collision with root package name */
        Object f247i;

        /* renamed from: j  reason: collision with root package name */
        /* synthetic */ Object f248j;

        /* renamed from: k  reason: collision with root package name */
        final /* synthetic */ a f249k;

        /* renamed from: l  reason: collision with root package name */
        int f250l;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        b(a aVar, c3.d<? super b> dVar) {
            super(dVar);
            this.f249k = aVar;
        }

        public final Object invokeSuspend(Object obj) {
            this.f248j = obj;
            this.f250l |= Integer.MIN_VALUE;
            return this.f249k.c(this);
        }
    }

    private a() {
    }

    private final C0003a b(b.a aVar) {
        Map<b.a, C0003a> map = f239b;
        i.d(map, "dependencies");
        C0003a aVar2 = map.get(aVar);
        if (aVar2 != null) {
            i.d(aVar2, "dependencies.getOrElse(s…load time.\"\n      )\n    }");
            return aVar2;
        }
        throw new IllegalStateException("Cannot get dependency " + aVar + ". Dependencies should be added at class load time.");
    }

    public final void a(b.a aVar) {
        i.e(aVar, "subscriberName");
        Map<b.a, C0003a> map = f239b;
        if (map.containsKey(aVar)) {
            Log.d("SessionsDependencies", "Dependency " + aVar + " already added.");
            return;
        }
        i.d(map, "dependencies");
        map.put(aVar, new C0003a(kotlinx.coroutines.sync.d.a(true), (b) null, 2, (e) null));
    }

    /* JADX INFO: finally extract failed */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r6v1, resolved type: java.lang.Object} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r7v1, resolved type: a2.b$a} */
    /* JADX WARNING: Multi-variable type inference failed */
    /* JADX WARNING: Removed duplicated region for block: B:12:0x0048  */
    /* JADX WARNING: Removed duplicated region for block: B:15:0x006f  */
    /* JADX WARNING: Removed duplicated region for block: B:8:0x0024  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final java.lang.Object c(c3.d<? super java.util.Map<a2.b.a, ? extends a2.b>> r11) {
        /*
            r10 = this;
            boolean r0 = r11 instanceof a2.a.b
            if (r0 == 0) goto L_0x0013
            r0 = r11
            a2.a$b r0 = (a2.a.b) r0
            int r1 = r0.f250l
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L_0x0013
            int r1 = r1 - r2
            r0.f250l = r1
            goto L_0x0018
        L_0x0013:
            a2.a$b r0 = new a2.a$b
            r0.<init>(r10, r11)
        L_0x0018:
            java.lang.Object r11 = r0.f248j
            java.lang.Object r1 = d3.d.c()
            int r2 = r0.f250l
            r3 = 0
            r4 = 1
            if (r2 == 0) goto L_0x0048
            if (r2 != r4) goto L_0x0040
            java.lang.Object r2 = r0.f247i
            java.lang.Object r5 = r0.f246h
            java.util.Map r5 = (java.util.Map) r5
            java.lang.Object r6 = r0.f245g
            kotlinx.coroutines.sync.b r6 = (kotlinx.coroutines.sync.b) r6
            java.lang.Object r7 = r0.f244f
            a2.b$a r7 = (a2.b.a) r7
            java.lang.Object r8 = r0.f243e
            java.util.Iterator r8 = (java.util.Iterator) r8
            java.lang.Object r9 = r0.f242d
            java.util.Map r9 = (java.util.Map) r9
            a3.n.b(r11)
            goto L_0x00a0
        L_0x0040:
            java.lang.IllegalStateException r11 = new java.lang.IllegalStateException
            java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
            r11.<init>(r0)
            throw r11
        L_0x0048:
            a3.n.b(r11)
            java.util.Map<a2.b$a, a2.a$a> r11 = f239b
            java.lang.String r2 = "dependencies"
            kotlin.jvm.internal.i.d(r11, r2)
            java.util.LinkedHashMap r2 = new java.util.LinkedHashMap
            int r5 = r11.size()
            int r5 = b3.d0.a(r5)
            r2.<init>(r5)
            java.util.Set r11 = r11.entrySet()
            java.util.Iterator r11 = r11.iterator()
            r8 = r11
            r5 = r2
        L_0x0069:
            boolean r11 = r8.hasNext()
            if (r11 == 0) goto L_0x00b3
            java.lang.Object r11 = r8.next()
            java.util.Map$Entry r11 = (java.util.Map.Entry) r11
            java.lang.Object r2 = r11.getKey()
            java.lang.Object r6 = r11.getKey()
            r7 = r6
            a2.b$a r7 = (a2.b.a) r7
            java.lang.Object r11 = r11.getValue()
            a2.a$a r11 = (a2.a.C0003a) r11
            kotlinx.coroutines.sync.b r6 = r11.a()
            r0.f242d = r5
            r0.f243e = r8
            r0.f244f = r7
            r0.f245g = r6
            r0.f246h = r5
            r0.f247i = r2
            r0.f250l = r4
            java.lang.Object r11 = r6.b(r3, r0)
            if (r11 != r1) goto L_0x009f
            return r1
        L_0x009f:
            r9 = r5
        L_0x00a0:
            a2.a r11 = f238a     // Catch:{ all -> 0x00ae }
            a2.b r11 = r11.d(r7)     // Catch:{ all -> 0x00ae }
            r6.a(r3)
            r5.put(r2, r11)
            r5 = r9
            goto L_0x0069
        L_0x00ae:
            r11 = move-exception
            r6.a(r3)
            throw r11
        L_0x00b3:
            return r5
        */
        throw new UnsupportedOperationException("Method not decompiled: a2.a.c(c3.d):java.lang.Object");
    }

    public final b d(b.a aVar) {
        i.e(aVar, "subscriberName");
        b b4 = b(aVar).b();
        if (b4 != null) {
            return b4;
        }
        throw new IllegalStateException("Subscriber " + aVar + " has not been registered.");
    }

    public final void e(b bVar) {
        i.e(bVar, "subscriber");
        b.a a4 = bVar.a();
        C0003a b4 = b(a4);
        if (b4.b() != null) {
            Log.d("SessionsDependencies", "Subscriber " + a4 + " already registered.");
            return;
        }
        b4.c(bVar);
        b.a.a(b4.a(), (Object) null, 1, (Object) null);
    }
}
