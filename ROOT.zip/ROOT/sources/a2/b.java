package a2;

import kotlin.jvm.internal.i;

public interface b {

    public enum a {
        CRASHLYTICS,
        PERFORMANCE,
        MATT_SAYS_HI
    }

    /* renamed from: a2.b$b  reason: collision with other inner class name */
    public static final class C0004b {

        /* renamed from: a  reason: collision with root package name */
        private final String f255a;

        public C0004b(String str) {
            i.e(str, "sessionId");
            this.f255a = str;
        }

        public final String a() {
            return this.f255a;
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            return (obj instanceof C0004b) && i.a(this.f255a, ((C0004b) obj).f255a);
        }

        public int hashCode() {
            return this.f255a.hashCode();
        }

        public String toString() {
            return "SessionDetails(sessionId=" + this.f255a + ')';
        }
    }

    a a();

    void b(C0004b bVar);

    boolean c();
}
