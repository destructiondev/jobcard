package n1;

public interface f {
    int a();
}
