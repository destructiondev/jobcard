package n1;

import android.util.Base64;
import android.util.JsonWriter;
import java.io.Writer;
import java.util.Collection;
import java.util.Date;
import java.util.Map;
import l1.b;
import l1.c;
import l1.d;
import l1.f;
import l1.g;

final class e implements l1.e, g {

    /* renamed from: a  reason: collision with root package name */
    private e f3707a = null;

    /* renamed from: b  reason: collision with root package name */
    private boolean f3708b = true;

    /* renamed from: c  reason: collision with root package name */
    private final JsonWriter f3709c;

    /* renamed from: d  reason: collision with root package name */
    private final Map<Class<?>, d<?>> f3710d;

    /* renamed from: e  reason: collision with root package name */
    private final Map<Class<?>, f<?>> f3711e;

    /* renamed from: f  reason: collision with root package name */
    private final d<Object> f3712f;

    /* renamed from: g  reason: collision with root package name */
    private final boolean f3713g;

    e(Writer writer, Map<Class<?>, d<?>> map, Map<Class<?>, f<?>> map2, d<Object> dVar, boolean z3) {
        this.f3709c = new JsonWriter(writer);
        this.f3710d = map;
        this.f3711e = map2;
        this.f3712f = dVar;
        this.f3713g = z3;
    }

    private boolean t(Object obj) {
        return obj == null || obj.getClass().isArray() || (obj instanceof Collection) || (obj instanceof Date) || (obj instanceof Enum) || (obj instanceof Number);
    }

    private e w(String str, Object obj) {
        y();
        this.f3709c.name(str);
        if (obj != null) {
            return k(obj, false);
        }
        this.f3709c.nullValue();
        return this;
    }

    private e x(String str, Object obj) {
        if (obj == null) {
            return this;
        }
        y();
        this.f3709c.name(str);
        return k(obj, false);
    }

    private void y() {
        if (this.f3708b) {
            e eVar = this.f3707a;
            if (eVar != null) {
                eVar.y();
                this.f3707a.f3708b = false;
                this.f3707a = null;
                this.f3709c.endObject();
                return;
            }
            return;
        }
        throw new IllegalStateException("Parent context used since this context was created. Cannot use this context anymore.");
    }

    public l1.e c(c cVar, boolean z3) {
        return q(cVar.b(), z3);
    }

    public l1.e d(c cVar, int i4) {
        return n(cVar.b(), i4);
    }

    public l1.e e(c cVar, long j4) {
        return o(cVar.b(), j4);
    }

    public l1.e f(c cVar, Object obj) {
        return p(cVar.b(), obj);
    }

    public l1.e g(c cVar, double d4) {
        return m(cVar.b(), d4);
    }

    public e h(double d4) {
        y();
        this.f3709c.value(d4);
        return this;
    }

    public e i(int i4) {
        y();
        this.f3709c.value((long) i4);
        return this;
    }

    public e j(long j4) {
        y();
        this.f3709c.value(j4);
        return this;
    }

    /* access modifiers changed from: package-private */
    public e k(Object obj, boolean z3) {
        int i4 = 0;
        if (z3 && t(obj)) {
            Object[] objArr = new Object[1];
            objArr[0] = obj == null ? null : obj.getClass();
            throw new b(String.format("%s cannot be encoded inline", objArr));
        } else if (obj == null) {
            this.f3709c.nullValue();
            return this;
        } else if (obj instanceof Number) {
            this.f3709c.value((Number) obj);
            return this;
        } else if (obj.getClass().isArray()) {
            if (obj instanceof byte[]) {
                return s((byte[]) obj);
            }
            this.f3709c.beginArray();
            if (obj instanceof int[]) {
                int[] iArr = (int[]) obj;
                int length = iArr.length;
                while (i4 < length) {
                    this.f3709c.value((long) iArr[i4]);
                    i4++;
                }
            } else if (obj instanceof long[]) {
                long[] jArr = (long[]) obj;
                int length2 = jArr.length;
                while (i4 < length2) {
                    j(jArr[i4]);
                    i4++;
                }
            } else if (obj instanceof double[]) {
                double[] dArr = (double[]) obj;
                int length3 = dArr.length;
                while (i4 < length3) {
                    this.f3709c.value(dArr[i4]);
                    i4++;
                }
            } else if (obj instanceof boolean[]) {
                boolean[] zArr = (boolean[]) obj;
                int length4 = zArr.length;
                while (i4 < length4) {
                    this.f3709c.value(zArr[i4]);
                    i4++;
                }
            } else if (obj instanceof Number[]) {
                for (Number k4 : (Number[]) obj) {
                    k(k4, false);
                }
            } else {
                for (Object k5 : (Object[]) obj) {
                    k(k5, false);
                }
            }
            this.f3709c.endArray();
            return this;
        } else if (obj instanceof Collection) {
            this.f3709c.beginArray();
            for (Object k6 : (Collection) obj) {
                k(k6, false);
            }
            this.f3709c.endArray();
            return this;
        } else if (obj instanceof Map) {
            this.f3709c.beginObject();
            for (Map.Entry entry : ((Map) obj).entrySet()) {
                Object key = entry.getKey();
                try {
                    p((String) key, entry.getValue());
                } catch (ClassCastException e4) {
                    throw new b(String.format("Only String keys are currently supported in maps, got %s of type %s instead.", new Object[]{key, key.getClass()}), e4);
                }
            }
            this.f3709c.endObject();
            return this;
        } else {
            d dVar = this.f3710d.get(obj.getClass());
            if (dVar != null) {
                return v(dVar, obj, z3);
            }
            f fVar = this.f3711e.get(obj.getClass());
            if (fVar != null) {
                fVar.a(obj, this);
                return this;
            } else if (!(obj instanceof Enum)) {
                return v(this.f3712f, obj, z3);
            } else {
                if (obj instanceof f) {
                    i(((f) obj).a());
                } else {
                    a(((Enum) obj).name());
                }
                return this;
            }
        }
    }

    /* renamed from: l */
    public e a(String str) {
        y();
        this.f3709c.value(str);
        return this;
    }

    public e m(String str, double d4) {
        y();
        this.f3709c.name(str);
        return h(d4);
    }

    public e n(String str, int i4) {
        y();
        this.f3709c.name(str);
        return i(i4);
    }

    public e o(String str, long j4) {
        y();
        this.f3709c.name(str);
        return j(j4);
    }

    public e p(String str, Object obj) {
        return this.f3713g ? x(str, obj) : w(str, obj);
    }

    public e q(String str, boolean z3) {
        y();
        this.f3709c.name(str);
        return b(z3);
    }

    /* renamed from: r */
    public e b(boolean z3) {
        y();
        this.f3709c.value(z3);
        return this;
    }

    public e s(byte[] bArr) {
        y();
        if (bArr == null) {
            this.f3709c.nullValue();
        } else {
            this.f3709c.value(Base64.encodeToString(bArr, 2));
        }
        return this;
    }

    /* access modifiers changed from: package-private */
    public void u() {
        y();
        this.f3709c.flush();
    }

    /* access modifiers changed from: package-private */
    public e v(d<Object> dVar, Object obj, boolean z3) {
        if (!z3) {
            this.f3709c.beginObject();
        }
        dVar.a(obj, this);
        if (!z3) {
            this.f3709c.endObject();
        }
        return this;
    }
}
