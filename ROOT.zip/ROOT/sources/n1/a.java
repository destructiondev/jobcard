package n1;

import l1.d;
import l1.e;

public final /* synthetic */ class a implements d {

    /* renamed from: a  reason: collision with root package name */
    public static final /* synthetic */ a f3694a = new a();

    private /* synthetic */ a() {
    }

    public final void a(Object obj, Object obj2) {
        d.l(obj, (e) obj2);
    }
}
