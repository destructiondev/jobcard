package n1;

import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;
import l1.e;
import l1.f;
import l1.g;

public final class d implements m1.b<d> {

    /* renamed from: e  reason: collision with root package name */
    private static final l1.d<Object> f3697e = a.f3694a;

    /* renamed from: f  reason: collision with root package name */
    private static final f<String> f3698f = c.f3696a;

    /* renamed from: g  reason: collision with root package name */
    private static final f<Boolean> f3699g = b.f3695a;

    /* renamed from: h  reason: collision with root package name */
    private static final b f3700h = new b((a) null);
    /* access modifiers changed from: private */

    /* renamed from: a  reason: collision with root package name */
    public final Map<Class<?>, l1.d<?>> f3701a = new HashMap();
    /* access modifiers changed from: private */

    /* renamed from: b  reason: collision with root package name */
    public final Map<Class<?>, f<?>> f3702b = new HashMap();
    /* access modifiers changed from: private */

    /* renamed from: c  reason: collision with root package name */
    public l1.d<Object> f3703c = f3697e;
    /* access modifiers changed from: private */

    /* renamed from: d  reason: collision with root package name */
    public boolean f3704d = false;

    class a implements l1.a {
        a() {
        }

        public String a(Object obj) {
            StringWriter stringWriter = new StringWriter();
            try {
                b(obj, stringWriter);
            } catch (IOException unused) {
            }
            return stringWriter.toString();
        }

        public void b(Object obj, Writer writer) {
            e eVar = new e(writer, d.this.f3701a, d.this.f3702b, d.this.f3703c, d.this.f3704d);
            eVar.k(obj, false);
            eVar.u();
        }
    }

    private static final class b implements f<Date> {

        /* renamed from: a  reason: collision with root package name */
        private static final DateFormat f3706a;

        static {
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US);
            f3706a = simpleDateFormat;
            simpleDateFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
        }

        private b() {
        }

        /* synthetic */ b(a aVar) {
            this();
        }

        /* renamed from: b */
        public void a(Date date, g gVar) {
            gVar.a(f3706a.format(date));
        }
    }

    public d() {
        p(String.class, f3698f);
        p(Boolean.class, f3699g);
        p(Date.class, f3700h);
    }

    /* access modifiers changed from: private */
    public static /* synthetic */ void l(Object obj, e eVar) {
        throw new l1.b("Couldn't find encoder for type " + obj.getClass().getCanonicalName());
    }

    public l1.a i() {
        return new a();
    }

    public d j(m1.a aVar) {
        aVar.a(this);
        return this;
    }

    public d k(boolean z3) {
        this.f3704d = z3;
        return this;
    }

    /* renamed from: o */
    public <T> d a(Class<T> cls, l1.d<? super T> dVar) {
        this.f3701a.put(cls, dVar);
        this.f3702b.remove(cls);
        return this;
    }

    public <T> d p(Class<T> cls, f<? super T> fVar) {
        this.f3702b.put(cls, fVar);
        this.f3701a.remove(cls);
        return this;
    }
}
