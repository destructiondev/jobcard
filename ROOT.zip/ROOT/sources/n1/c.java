package n1;

import l1.f;
import l1.g;

public final /* synthetic */ class c implements f {

    /* renamed from: a  reason: collision with root package name */
    public static final /* synthetic */ c f3696a = new c();

    private /* synthetic */ c() {
    }

    public final void a(Object obj, Object obj2) {
        ((g) obj2).a((String) obj);
    }
}
