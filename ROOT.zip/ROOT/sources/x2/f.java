package x2;

import android.view.View;
import x2.h;

public final /* synthetic */ class f implements h.a {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ Class[] f4933a;

    public /* synthetic */ f(Class[] clsArr) {
        this.f4933a = clsArr;
    }

    public final boolean a(View view) {
        return h.h(this.f4933a, view);
    }
}
