package x2;

import android.view.View;
import x2.h;

public final /* synthetic */ class g implements h.a {

    /* renamed from: a  reason: collision with root package name */
    public static final /* synthetic */ g f4934a = new g();

    private /* synthetic */ g() {
    }

    public final boolean a(View view) {
        return view.hasFocus();
    }
}
