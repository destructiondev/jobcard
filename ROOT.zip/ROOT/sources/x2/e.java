package x2;

import r.a;

public final class e {
    public static void a(String str) {
        a.c(c(str));
    }

    public static void b(String str, int i4) {
        a.a(c(str), i4);
    }

    private static String c(String str) {
        if (str.length() < 124) {
            return str;
        }
        return str.substring(0, 124) + "...";
    }

    public static void d() {
        a.f();
    }

    public static void e(String str, int i4) {
        a.d(c(str), i4);
    }
}
