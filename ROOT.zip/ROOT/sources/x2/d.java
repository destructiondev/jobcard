package x2;

public interface d<T> {
    boolean test(T t4);
}
