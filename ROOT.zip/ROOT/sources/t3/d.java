package t3;

import kotlin.jvm.internal.e;
import s3.d2;
import s3.t0;

public abstract class d extends d2 implements t0 {
    private d() {
    }

    public /* synthetic */ d(e eVar) {
        this();
    }
}
