package t3;

import android.os.Looper;
import java.util.List;
import kotlin.jvm.internal.e;
import kotlinx.coroutines.internal.r;
import s3.d2;

public final class a implements r {
    public int a() {
        return 1073741823;
    }

    public String b() {
        return "For tests Dispatchers.setMain from kotlinx-coroutines-test module can be used";
    }

    public d2 c(List<? extends r> list) {
        Looper mainLooper = Looper.getMainLooper();
        if (mainLooper != null) {
            return new c(e.a(mainLooper, true), (String) null, 2, (e) null);
        }
        throw new IllegalStateException("The main looper is not available");
    }
}
