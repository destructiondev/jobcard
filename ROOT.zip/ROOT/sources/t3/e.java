package t3;

import a3.m;
import a3.n;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.Choreographer;
import java.util.Objects;

public final class e {

    /* renamed from: a  reason: collision with root package name */
    public static final d f4344a;
    private static volatile Choreographer choreographer;

    static {
        Object obj;
        d dVar = null;
        try {
            m.a aVar = m.f265d;
            obj = m.a(new c(a(Looper.getMainLooper(), true), (String) null, 2, (kotlin.jvm.internal.e) null));
        } catch (Throwable th) {
            m.a aVar2 = m.f265d;
            obj = m.a(n.a(th));
        }
        if (!m.c(obj)) {
            dVar = obj;
        }
        f4344a = dVar;
    }

    public static final Handler a(Looper looper, boolean z3) {
        if (!z3) {
            return new Handler(looper);
        }
        if (Build.VERSION.SDK_INT >= 28) {
            Object invoke = Handler.class.getDeclaredMethod("createAsync", new Class[]{Looper.class}).invoke((Object) null, new Object[]{looper});
            Objects.requireNonNull(invoke, "null cannot be cast to non-null type android.os.Handler");
            return (Handler) invoke;
        }
        Class<Handler> cls = Handler.class;
        try {
            return cls.getDeclaredConstructor(new Class[]{Looper.class, Handler.Callback.class, Boolean.TYPE}).newInstance(new Object[]{looper, null, Boolean.TRUE});
        } catch (NoSuchMethodException unused) {
            return new Handler(looper);
        }
    }
}
