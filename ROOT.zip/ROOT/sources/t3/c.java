package t3;

import android.os.Handler;
import android.os.Looper;
import c3.g;
import java.util.concurrent.CancellationException;
import kotlin.jvm.internal.e;
import kotlin.jvm.internal.i;
import s3.x1;
import s3.z0;

public final class c extends d {
    private volatile c _immediate;

    /* renamed from: f  reason: collision with root package name */
    private final Handler f4340f;

    /* renamed from: g  reason: collision with root package name */
    private final String f4341g;

    /* renamed from: h  reason: collision with root package name */
    private final boolean f4342h;

    /* renamed from: i  reason: collision with root package name */
    private final c f4343i;

    public c(Handler handler, String str) {
        this(handler, str, false);
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public /* synthetic */ c(Handler handler, String str, int i4, e eVar) {
        this(handler, (i4 & 2) != 0 ? null : str);
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    private c(Handler handler, String str, boolean z3) {
        super((e) null);
        c cVar = null;
        this.f4340f = handler;
        this.f4341g = str;
        this.f4342h = z3;
        this._immediate = z3 ? this : cVar;
        c cVar2 = this._immediate;
        if (cVar2 == null) {
            cVar2 = new c(handler, str, true);
            this._immediate = cVar2;
        }
        this.f4343i = cVar2;
    }

    private final void N(g gVar, Runnable runnable) {
        x1.c(gVar, new CancellationException("The task was rejected, the handler underlying the dispatcher '" + this + "' was closed"));
        z0.b().I(gVar, runnable);
    }

    public void I(g gVar, Runnable runnable) {
        if (!this.f4340f.post(runnable)) {
            N(gVar, runnable);
        }
    }

    public boolean J(g gVar) {
        return !this.f4342h || !i.a(Looper.myLooper(), this.f4340f.getLooper());
    }

    /* renamed from: O */
    public c L() {
        return this.f4343i;
    }

    public boolean equals(Object obj) {
        return (obj instanceof c) && ((c) obj).f4340f == this.f4340f;
    }

    public int hashCode() {
        return System.identityHashCode(this.f4340f);
    }

    public String toString() {
        String M = M();
        if (M != null) {
            return M;
        }
        String str = this.f4341g;
        if (str == null) {
            str = this.f4340f.toString();
        }
        if (!this.f4342h) {
            return str;
        }
        return str + ".immediate";
    }
}
