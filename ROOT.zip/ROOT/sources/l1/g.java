package l1;

public interface g {
    g a(String str);

    g b(boolean z3);
}
