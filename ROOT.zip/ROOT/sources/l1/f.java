package l1;

public interface f<T> {
    /* synthetic */ void a(Object obj, Object obj2);
}
