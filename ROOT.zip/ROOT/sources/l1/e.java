package l1;

public interface e {
    e c(c cVar, boolean z3);

    e d(c cVar, int i4);

    e e(c cVar, long j4);

    e f(c cVar, Object obj);

    e g(c cVar, double d4);
}
