package l1;

import java.io.Writer;

public interface a {
    String a(Object obj);

    void b(Object obj, Writer writer);
}
