package l1;

public interface d<T> {
    /* synthetic */ void a(Object obj, Object obj2);
}
