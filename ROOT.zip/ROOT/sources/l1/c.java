package l1;

import java.lang.annotation.Annotation;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public final class c {

    /* renamed from: a  reason: collision with root package name */
    private final String f3661a;

    /* renamed from: b  reason: collision with root package name */
    private final Map<Class<?>, Object> f3662b;

    public static final class b {

        /* renamed from: a  reason: collision with root package name */
        private final String f3663a;

        /* renamed from: b  reason: collision with root package name */
        private Map<Class<?>, Object> f3664b = null;

        b(String str) {
            this.f3663a = str;
        }

        public c a() {
            return new c(this.f3663a, this.f3664b == null ? Collections.emptyMap() : Collections.unmodifiableMap(new HashMap(this.f3664b)));
        }

        public <T extends Annotation> b b(T t4) {
            if (this.f3664b == null) {
                this.f3664b = new HashMap();
            }
            this.f3664b.put(t4.annotationType(), t4);
            return this;
        }
    }

    private c(String str, Map<Class<?>, Object> map) {
        this.f3661a = str;
        this.f3662b = map;
    }

    public static b a(String str) {
        return new b(str);
    }

    public static c d(String str) {
        return new c(str, Collections.emptyMap());
    }

    public String b() {
        return this.f3661a;
    }

    public <T extends Annotation> T c(Class<T> cls) {
        return (Annotation) this.f3662b.get(cls);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof c)) {
            return false;
        }
        c cVar = (c) obj;
        return this.f3661a.equals(cVar.f3661a) && this.f3662b.equals(cVar.f3662b);
    }

    public int hashCode() {
        return (this.f3661a.hashCode() * 31) + this.f3662b.hashCode();
    }

    public String toString() {
        return "FieldDescriptor{name=" + this.f3661a + ", properties=" + this.f3662b.values() + "}";
    }
}
