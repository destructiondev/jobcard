package b3;

class s extends r {
}
