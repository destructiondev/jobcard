package b3;

import java.util.Collections;
import java.util.Set;
import kotlin.jvm.internal.i;

class i0 {
    public static final <T> Set<T> a(T t4) {
        Set<T> singleton = Collections.singleton(t4);
        i.d(singleton, "singleton(element)");
        return singleton;
    }
}
