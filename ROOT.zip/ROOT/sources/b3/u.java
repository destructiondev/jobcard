package b3;

import j3.l;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Set;
import kotlin.jvm.internal.i;

class u extends t {
    public static <T> T i(List<? extends T> list) {
        i.e(list, "<this>");
        if (list.isEmpty()) {
            return null;
        }
        return list.get(0);
    }

    public static final <T, A extends Appendable> A j(Iterable<? extends T> iterable, A a4, CharSequence charSequence, CharSequence charSequence2, CharSequence charSequence3, int i4, CharSequence charSequence4, l<? super T, ? extends CharSequence> lVar) {
        i.e(iterable, "<this>");
        i.e(a4, "buffer");
        i.e(charSequence, "separator");
        i.e(charSequence2, "prefix");
        i.e(charSequence3, "postfix");
        i.e(charSequence4, "truncated");
        a4.append(charSequence2);
        int i5 = 0;
        for (Object next : iterable) {
            i5++;
            if (i5 > 1) {
                a4.append(charSequence);
            }
            if (i4 >= 0 && i5 > i4) {
                break;
            }
            g.a(a4, next, lVar);
        }
        if (i4 >= 0 && i5 > i4) {
            a4.append(charSequence4);
        }
        a4.append(charSequence3);
        return a4;
    }

    public static /* synthetic */ Appendable k(Iterable iterable, Appendable appendable, CharSequence charSequence, CharSequence charSequence2, CharSequence charSequence3, int i4, CharSequence charSequence4, l lVar, int i5, Object obj) {
        String str = (i5 & 2) != 0 ? ", " : charSequence;
        CharSequence charSequence5 = "";
        CharSequence charSequence6 = (i5 & 4) != 0 ? charSequence5 : charSequence2;
        if ((i5 & 8) == 0) {
            charSequence5 = charSequence3;
        }
        return j(iterable, appendable, str, charSequence6, charSequence5, (i5 & 16) != 0 ? -1 : i4, (i5 & 32) != 0 ? "..." : charSequence4, (i5 & 64) != 0 ? null : lVar);
    }

    public static final <T> String l(Iterable<? extends T> iterable, CharSequence charSequence, CharSequence charSequence2, CharSequence charSequence3, int i4, CharSequence charSequence4, l<? super T, ? extends CharSequence> lVar) {
        i.e(iterable, "<this>");
        i.e(charSequence, "separator");
        i.e(charSequence2, "prefix");
        i.e(charSequence3, "postfix");
        i.e(charSequence4, "truncated");
        String sb = ((StringBuilder) j(iterable, new StringBuilder(), charSequence, charSequence2, charSequence3, i4, charSequence4, lVar)).toString();
        i.d(sb, "joinTo(StringBuilder(), …ed, transform).toString()");
        return sb;
    }

    public static /* synthetic */ String m(Iterable iterable, CharSequence charSequence, CharSequence charSequence2, CharSequence charSequence3, int i4, CharSequence charSequence4, l lVar, int i5, Object obj) {
        if ((i5 & 1) != 0) {
            charSequence = ", ";
        }
        CharSequence charSequence5 = "";
        CharSequence charSequence6 = (i5 & 2) != 0 ? charSequence5 : charSequence2;
        if ((i5 & 4) == 0) {
            charSequence5 = charSequence3;
        }
        int i6 = (i5 & 8) != 0 ? -1 : i4;
        if ((i5 & 16) != 0) {
            charSequence4 = "...";
        }
        CharSequence charSequence7 = charSequence4;
        if ((i5 & 32) != 0) {
            lVar = null;
        }
        return l(iterable, charSequence, charSequence6, charSequence5, i6, charSequence7, lVar);
    }

    public static <T extends Comparable<? super T>> T n(Iterable<? extends T> iterable) {
        i.e(iterable, "<this>");
        Iterator<? extends T> it = iterable.iterator();
        if (!it.hasNext()) {
            return null;
        }
        T t4 = (Comparable) it.next();
        while (it.hasNext()) {
            T t5 = (Comparable) it.next();
            if (t4.compareTo(t5) > 0) {
                t4 = t5;
            }
        }
        return t4;
    }

    public static <T> T o(Iterable<? extends T> iterable) {
        i.e(iterable, "<this>");
        if (iterable instanceof List) {
            return p((List) iterable);
        }
        Iterator<? extends T> it = iterable.iterator();
        if (it.hasNext()) {
            T next = it.next();
            if (!it.hasNext()) {
                return next;
            }
            throw new IllegalArgumentException("Collection has more than one element.");
        }
        throw new NoSuchElementException("Collection is empty.");
    }

    public static final <T> T p(List<? extends T> list) {
        i.e(list, "<this>");
        int size = list.size();
        if (size == 0) {
            throw new NoSuchElementException("List is empty.");
        } else if (size == 1) {
            return list.get(0);
        } else {
            throw new IllegalArgumentException("List has more than one element.");
        }
    }

    public static final <T, C extends Collection<? super T>> C q(Iterable<? extends T> iterable, C c4) {
        i.e(iterable, "<this>");
        i.e(c4, "destination");
        for (Object add : iterable) {
            c4.add(add);
        }
        return c4;
    }

    public static <T> List<T> r(Iterable<? extends T> iterable) {
        i.e(iterable, "<this>");
        if (!(iterable instanceof Collection)) {
            return m.e(s(iterable));
        }
        Collection collection = (Collection) iterable;
        int size = collection.size();
        if (size == 0) {
            return m.b();
        }
        if (size != 1) {
            return t(collection);
        }
        return l.a(iterable instanceof List ? ((List) iterable).get(0) : iterable.iterator().next());
    }

    public static final <T> List<T> s(Iterable<? extends T> iterable) {
        i.e(iterable, "<this>");
        return iterable instanceof Collection ? t((Collection) iterable) : (List) q(iterable, new ArrayList());
    }

    public static final <T> List<T> t(Collection<? extends T> collection) {
        i.e(collection, "<this>");
        return new ArrayList(collection);
    }

    public static <T> Set<T> u(Iterable<? extends T> iterable) {
        i.e(iterable, "<this>");
        if (!(iterable instanceof Collection)) {
            return j0.c((Set) q(iterable, new LinkedHashSet()));
        }
        Collection collection = (Collection) iterable;
        int size = collection.size();
        if (size == 0) {
            return j0.b();
        }
        if (size != 1) {
            return (Set) q(iterable, new LinkedHashSet(d0.a(collection.size())));
        }
        return i0.a(iterable instanceof List ? ((List) iterable).get(0) : iterable.iterator().next());
    }
}
