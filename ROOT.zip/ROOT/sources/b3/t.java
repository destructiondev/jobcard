package b3;

class t extends s {
}
