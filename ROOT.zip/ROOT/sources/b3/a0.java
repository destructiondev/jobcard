package b3;

import java.util.Iterator;

public abstract class a0 implements Iterator<Long> {
    public abstract long b();

    public /* bridge */ /* synthetic */ Object next() {
        return Long.valueOf(b());
    }

    public void remove() {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }
}
