package b3;

import java.util.Set;
import kotlin.jvm.internal.i;

class j0 extends i0 {
    public static <T> Set<T> b() {
        return y.f1250d;
    }

    public static final <T> Set<T> c(Set<? extends T> set) {
        i.e(set, "<this>");
        int size = set.size();
        return size != 0 ? size != 1 ? set : i0.a(set.iterator().next()) : b();
    }
}
