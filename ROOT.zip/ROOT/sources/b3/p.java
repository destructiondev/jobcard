package b3;

class p extends o {
}
