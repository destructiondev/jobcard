package b3;

import java.util.List;
import kotlin.jvm.internal.e;

public abstract class b<E> extends a<E> implements List<E> {

    /* renamed from: d  reason: collision with root package name */
    public static final a f1241d = new a((e) null);

    public static final class a {
        private a() {
        }

        public /* synthetic */ a(e eVar) {
            this();
        }

        public final void a(int i4, int i5) {
            if (i4 < 0 || i4 >= i5) {
                throw new IndexOutOfBoundsException("index: " + i4 + ", size: " + i5);
            }
        }

        public final void b(int i4, int i5) {
            if (i4 < 0 || i4 > i5) {
                throw new IndexOutOfBoundsException("index: " + i4 + ", size: " + i5);
            }
        }
    }
}
