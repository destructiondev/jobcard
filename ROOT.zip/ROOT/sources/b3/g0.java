package b3;

class g0 extends f0 {
}
