package b3;

import java.util.Collection;

public abstract class a<E> implements Collection<E> {
}
