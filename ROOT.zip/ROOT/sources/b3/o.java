package b3;

class o extends n {
}
