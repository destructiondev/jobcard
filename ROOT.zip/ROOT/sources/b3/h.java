package b3;

import java.util.Arrays;
import java.util.List;
import kotlin.jvm.internal.i;

class h extends g {
    public static <T> List<T> b(T[] tArr) {
        i.e(tArr, "<this>");
        List<T> a4 = j.a(tArr);
        i.d(a4, "asList(this)");
        return a4;
    }

    public static final <T> T[] c(T[] tArr, T[] tArr2, int i4, int i5, int i6) {
        i.e(tArr, "<this>");
        i.e(tArr2, "destination");
        System.arraycopy(tArr, i5, tArr2, i4, i6 - i5);
        return tArr2;
    }

    public static /* synthetic */ Object[] d(Object[] objArr, Object[] objArr2, int i4, int i5, int i6, int i7, Object obj) {
        if ((i7 & 2) != 0) {
            i4 = 0;
        }
        if ((i7 & 4) != 0) {
            i5 = 0;
        }
        if ((i7 & 8) != 0) {
            i6 = objArr.length;
        }
        return c(objArr, objArr2, i4, i5, i6);
    }

    public static <T> void e(T[] tArr, T t4, int i4, int i5) {
        i.e(tArr, "<this>");
        Arrays.fill(tArr, i4, i5, t4);
    }

    public static /* synthetic */ void f(Object[] objArr, Object obj, int i4, int i5, int i6, Object obj2) {
        if ((i6 & 2) != 0) {
            i4 = 0;
        }
        if ((i6 & 4) != 0) {
            i5 = objArr.length;
        }
        e(objArr, obj, i4, i5);
    }
}
