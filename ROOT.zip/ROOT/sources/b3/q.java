package b3;

class q extends p {
}
