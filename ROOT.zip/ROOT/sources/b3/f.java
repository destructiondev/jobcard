package b3;

import java.lang.reflect.Array;
import kotlin.jvm.internal.i;

class f {
    public static final <T> T[] a(T[] tArr, int i4) {
        i.e(tArr, "reference");
        Object newInstance = Array.newInstance(tArr.getClass().getComponentType(), i4);
        i.c(newInstance, "null cannot be cast to non-null type kotlin.Array<T of kotlin.collections.ArraysKt__ArraysJVMKt.arrayOfNulls>");
        return (Object[]) newInstance;
    }
}
