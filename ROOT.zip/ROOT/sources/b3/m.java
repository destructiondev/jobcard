package b3;

import java.util.List;
import kotlin.jvm.internal.i;

class m extends l {
    public static <T> List<T> b() {
        return w.f1248d;
    }

    public static <T> int c(List<? extends T> list) {
        i.e(list, "<this>");
        return list.size() - 1;
    }

    public static <T> List<T> d(T... tArr) {
        i.e(tArr, "elements");
        return tArr.length > 0 ? h.b(tArr) : b();
    }

    public static <T> List<T> e(List<? extends T> list) {
        i.e(list, "<this>");
        int size = list.size();
        return size != 0 ? size != 1 ? list : l.a(list.get(0)) : b();
    }

    public static void f() {
        throw new ArithmeticException("Index overflow has happened.");
    }
}
