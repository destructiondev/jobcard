package b3;

class c0 {
}
