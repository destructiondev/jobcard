package b3;

public final class h0 extends k0 {
}
