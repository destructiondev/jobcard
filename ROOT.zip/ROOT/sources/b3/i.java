package b3;

import java.util.NoSuchElementException;

class i extends h {
    public static final <T> int g(T[] tArr) {
        kotlin.jvm.internal.i.e(tArr, "<this>");
        return tArr.length - 1;
    }

    public static char h(char[] cArr) {
        kotlin.jvm.internal.i.e(cArr, "<this>");
        int length = cArr.length;
        if (length == 0) {
            throw new NoSuchElementException("Array is empty.");
        } else if (length == 1) {
            return cArr[0];
        } else {
            throw new IllegalArgumentException("Array has more than one element.");
        }
    }

    public static <T> T i(T[] tArr) {
        kotlin.jvm.internal.i.e(tArr, "<this>");
        if (tArr.length == 1) {
            return tArr[0];
        }
        return null;
    }
}
