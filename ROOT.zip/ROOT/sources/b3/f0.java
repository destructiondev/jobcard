package b3;

class f0 extends e0 {
}
