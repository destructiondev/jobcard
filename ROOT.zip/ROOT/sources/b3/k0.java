package b3;

class k0 extends j0 {
}
