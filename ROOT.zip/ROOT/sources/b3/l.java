package b3;

import java.util.Collections;
import java.util.List;
import kotlin.jvm.internal.i;

class l {
    public static <T> List<T> a(T t4) {
        List<T> singletonList = Collections.singletonList(t4);
        i.d(singletonList, "singletonList(element)");
        return singletonList;
    }
}
