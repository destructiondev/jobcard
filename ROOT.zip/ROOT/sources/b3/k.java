package b3;

public final class k extends u {
}
