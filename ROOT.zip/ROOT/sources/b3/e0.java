package b3;

import a3.l;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import kotlin.jvm.internal.i;

class e0 extends d0 {
    public static final <K, V> Map<K, V> d() {
        x xVar = x.f1249d;
        i.c(xVar, "null cannot be cast to non-null type kotlin.collections.Map<K of kotlin.collections.MapsKt__MapsKt.emptyMap, V of kotlin.collections.MapsKt__MapsKt.emptyMap>");
        return xVar;
    }

    public static <K, V> Map<K, V> e(l<? extends K, ? extends V>... lVarArr) {
        i.e(lVarArr, "pairs");
        return lVarArr.length > 0 ? l(lVarArr, new LinkedHashMap(d0.a(lVarArr.length))) : d();
    }

    public static final <K, V> Map<K, V> f(Map<K, ? extends V> map) {
        i.e(map, "<this>");
        int size = map.size();
        return size != 0 ? size != 1 ? map : d0.c(map) : d();
    }

    public static final <K, V> void g(Map<? super K, ? super V> map, Iterable<? extends l<? extends K, ? extends V>> iterable) {
        i.e(map, "<this>");
        i.e(iterable, "pairs");
        for (l lVar : iterable) {
            map.put(lVar.a(), lVar.b());
        }
    }

    public static final <K, V> void h(Map<? super K, ? super V> map, l<? extends K, ? extends V>[] lVarArr) {
        i.e(map, "<this>");
        i.e(lVarArr, "pairs");
        for (l<? extends K, ? extends V> lVar : lVarArr) {
            map.put(lVar.a(), lVar.b());
        }
    }

    public static <K, V> Map<K, V> i(Iterable<? extends l<? extends K, ? extends V>> iterable) {
        i.e(iterable, "<this>");
        if (!(iterable instanceof Collection)) {
            return f(j(iterable, new LinkedHashMap()));
        }
        Collection collection = (Collection) iterable;
        int size = collection.size();
        if (size == 0) {
            return d();
        }
        if (size != 1) {
            return j(iterable, new LinkedHashMap(d0.a(collection.size())));
        }
        return d0.b((l) (iterable instanceof List ? ((List) iterable).get(0) : iterable.iterator().next()));
    }

    public static final <K, V, M extends Map<? super K, ? super V>> M j(Iterable<? extends l<? extends K, ? extends V>> iterable, M m4) {
        i.e(iterable, "<this>");
        i.e(m4, "destination");
        g(m4, iterable);
        return m4;
    }

    public static <K, V> Map<K, V> k(Map<? extends K, ? extends V> map) {
        i.e(map, "<this>");
        int size = map.size();
        return size != 0 ? size != 1 ? m(map) : d0.c(map) : d();
    }

    public static final <K, V, M extends Map<? super K, ? super V>> M l(l<? extends K, ? extends V>[] lVarArr, M m4) {
        i.e(lVarArr, "<this>");
        i.e(m4, "destination");
        h(m4, lVarArr);
        return m4;
    }

    public static <K, V> Map<K, V> m(Map<? extends K, ? extends V> map) {
        i.e(map, "<this>");
        return new LinkedHashMap(map);
    }
}
