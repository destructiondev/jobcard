package b3;

class g extends f {
}
