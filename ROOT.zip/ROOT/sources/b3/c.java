package b3;

import java.util.AbstractList;

public abstract class c<E> extends AbstractList<E> {
    protected c() {
    }

    public abstract int h();

    public abstract E i(int i4);

    public final /* bridge */ E remove(int i4) {
        return i(i4);
    }

    public final /* bridge */ int size() {
        return h();
    }
}
