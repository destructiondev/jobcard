package b3;

public final class b0 extends g0 {
}
