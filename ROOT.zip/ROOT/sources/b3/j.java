package b3;

import java.util.Arrays;
import java.util.List;

class j {
    static <T> List<T> a(T[] tArr) {
        return Arrays.asList(tArr);
    }
}
