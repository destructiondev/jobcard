package b3;

import java.util.Collection;
import java.util.Iterator;
import java.util.NoSuchElementException;
import kotlin.jvm.internal.e;
import kotlin.jvm.internal.i;

public final class d<E> extends c<E> {

    /* renamed from: g  reason: collision with root package name */
    public static final a f1242g = new a((e) null);

    /* renamed from: h  reason: collision with root package name */
    private static final Object[] f1243h = new Object[0];

    /* renamed from: d  reason: collision with root package name */
    private int f1244d;

    /* renamed from: e  reason: collision with root package name */
    private Object[] f1245e = f1243h;

    /* renamed from: f  reason: collision with root package name */
    private int f1246f;

    public static final class a {
        private a() {
        }

        public /* synthetic */ a(e eVar) {
            this();
        }

        public final int a(int i4, int i5) {
            int i6 = i4 + (i4 >> 1);
            if (i6 - i5 < 0) {
                i6 = i5;
            }
            return i6 - 2147483639 > 0 ? i5 > 2147483639 ? Integer.MAX_VALUE : 2147483639 : i6;
        }
    }

    private final void l(int i4, Collection<? extends E> collection) {
        Iterator<? extends E> it = collection.iterator();
        int length = this.f1245e.length;
        while (i4 < length && it.hasNext()) {
            this.f1245e[i4] = it.next();
            i4++;
        }
        int i5 = this.f1244d;
        for (int i6 = 0; i6 < i5 && it.hasNext(); i6++) {
            this.f1245e[i6] = it.next();
        }
        this.f1246f = size() + collection.size();
    }

    private final void m(int i4) {
        Object[] objArr = new Object[i4];
        Object[] objArr2 = this.f1245e;
        h.c(objArr2, objArr, 0, this.f1244d, objArr2.length);
        Object[] objArr3 = this.f1245e;
        int length = objArr3.length;
        int i5 = this.f1244d;
        h.c(objArr3, objArr, length - i5, 0, i5);
        this.f1244d = 0;
        this.f1245e = objArr;
    }

    private final int n(int i4) {
        return i4 == 0 ? i.g(this.f1245e) : i4 - 1;
    }

    private final void o(int i4) {
        if (i4 >= 0) {
            Object[] objArr = this.f1245e;
            if (i4 > objArr.length) {
                if (objArr == f1243h) {
                    this.f1245e = new Object[i.a(i4, 10)];
                } else {
                    m(f1242g.a(objArr.length, i4));
                }
            }
        } else {
            throw new IllegalStateException("Deque is too big.");
        }
    }

    private final int p(int i4) {
        if (i4 == i.g(this.f1245e)) {
            return 0;
        }
        return i4 + 1;
    }

    private final int q(int i4) {
        return i4 < 0 ? i4 + this.f1245e.length : i4;
    }

    private final int r(int i4) {
        Object[] objArr = this.f1245e;
        return i4 >= objArr.length ? i4 - objArr.length : i4;
    }

    public void add(int i4, E e4) {
        b.f1241d.b(i4, size());
        if (i4 == size()) {
            k(e4);
        } else if (i4 == 0) {
            j(e4);
        } else {
            o(size() + 1);
            int r4 = r(this.f1244d + i4);
            if (i4 < ((size() + 1) >> 1)) {
                int n4 = n(r4);
                int n5 = n(this.f1244d);
                int i5 = this.f1244d;
                if (n4 >= i5) {
                    Object[] objArr = this.f1245e;
                    objArr[n5] = objArr[i5];
                    h.c(objArr, objArr, i5, i5 + 1, n4 + 1);
                } else {
                    Object[] objArr2 = this.f1245e;
                    h.c(objArr2, objArr2, i5 - 1, i5, objArr2.length);
                    Object[] objArr3 = this.f1245e;
                    objArr3[objArr3.length - 1] = objArr3[0];
                    h.c(objArr3, objArr3, 0, 1, n4 + 1);
                }
                this.f1245e[n4] = e4;
                this.f1244d = n5;
            } else {
                int r5 = r(this.f1244d + size());
                Object[] objArr4 = this.f1245e;
                if (r4 < r5) {
                    h.c(objArr4, objArr4, r4 + 1, r4, r5);
                } else {
                    h.c(objArr4, objArr4, 1, 0, r5);
                    Object[] objArr5 = this.f1245e;
                    objArr5[0] = objArr5[objArr5.length - 1];
                    h.c(objArr5, objArr5, r4 + 1, r4, objArr5.length - 1);
                }
                this.f1245e[r4] = e4;
            }
            this.f1246f = size() + 1;
        }
    }

    public boolean add(E e4) {
        k(e4);
        return true;
    }

    public boolean addAll(int i4, Collection<? extends E> collection) {
        i.e(collection, "elements");
        b.f1241d.b(i4, size());
        if (collection.isEmpty()) {
            return false;
        }
        if (i4 == size()) {
            return addAll(collection);
        }
        o(size() + collection.size());
        int r4 = r(this.f1244d + size());
        int r5 = r(this.f1244d + i4);
        int size = collection.size();
        if (i4 < ((size() + 1) >> 1)) {
            int i5 = this.f1244d;
            int i6 = i5 - size;
            if (r5 < i5) {
                Object[] objArr = this.f1245e;
                h.c(objArr, objArr, i6, i5, objArr.length);
                Object[] objArr2 = this.f1245e;
                if (size >= r5) {
                    h.c(objArr2, objArr2, objArr2.length - size, 0, r5);
                } else {
                    h.c(objArr2, objArr2, objArr2.length - size, 0, size);
                    Object[] objArr3 = this.f1245e;
                    h.c(objArr3, objArr3, 0, size, r5);
                }
            } else if (i6 >= 0) {
                Object[] objArr4 = this.f1245e;
                h.c(objArr4, objArr4, i6, i5, r5);
            } else {
                Object[] objArr5 = this.f1245e;
                i6 += objArr5.length;
                int i7 = r5 - i5;
                int length = objArr5.length - i6;
                if (length >= i7) {
                    h.c(objArr5, objArr5, i6, i5, r5);
                } else {
                    h.c(objArr5, objArr5, i6, i5, i5 + length);
                    Object[] objArr6 = this.f1245e;
                    h.c(objArr6, objArr6, 0, this.f1244d + length, r5);
                }
            }
            this.f1244d = i6;
            l(q(r5 - size), collection);
        } else {
            int i8 = r5 + size;
            if (r5 < r4) {
                int i9 = size + r4;
                Object[] objArr7 = this.f1245e;
                if (i9 > objArr7.length) {
                    if (i8 >= objArr7.length) {
                        i8 -= objArr7.length;
                    } else {
                        int length2 = r4 - (i9 - objArr7.length);
                        h.c(objArr7, objArr7, 0, length2, r4);
                        Object[] objArr8 = this.f1245e;
                        h.c(objArr8, objArr8, i8, r5, length2);
                    }
                }
                h.c(objArr7, objArr7, i8, r5, r4);
            } else {
                Object[] objArr9 = this.f1245e;
                h.c(objArr9, objArr9, size, 0, r4);
                Object[] objArr10 = this.f1245e;
                if (i8 >= objArr10.length) {
                    h.c(objArr10, objArr10, i8 - objArr10.length, r5, objArr10.length);
                } else {
                    h.c(objArr10, objArr10, 0, objArr10.length - size, objArr10.length);
                    Object[] objArr11 = this.f1245e;
                    h.c(objArr11, objArr11, i8, r5, objArr11.length - size);
                }
            }
            l(r5, collection);
        }
        return true;
    }

    public boolean addAll(Collection<? extends E> collection) {
        i.e(collection, "elements");
        if (collection.isEmpty()) {
            return false;
        }
        o(size() + collection.size());
        l(r(this.f1244d + size()), collection);
        return true;
    }

    public void clear() {
        int r4 = r(this.f1244d + size());
        int i4 = this.f1244d;
        if (i4 < r4) {
            h.e(this.f1245e, null, i4, r4);
        } else if (!isEmpty()) {
            Object[] objArr = this.f1245e;
            h.e(objArr, null, this.f1244d, objArr.length);
            h.e(this.f1245e, null, 0, r4);
        }
        this.f1244d = 0;
        this.f1246f = 0;
    }

    public boolean contains(Object obj) {
        return indexOf(obj) != -1;
    }

    public E get(int i4) {
        b.f1241d.a(i4, size());
        return this.f1245e[r(this.f1244d + i4)];
    }

    public int h() {
        return this.f1246f;
    }

    public E i(int i4) {
        b.f1241d.a(i4, size());
        if (i4 == m.c(this)) {
            return t();
        }
        if (i4 == 0) {
            return s();
        }
        int r4 = r(this.f1244d + i4);
        E e4 = this.f1245e[r4];
        if (i4 < (size() >> 1)) {
            int i5 = this.f1244d;
            if (r4 >= i5) {
                Object[] objArr = this.f1245e;
                h.c(objArr, objArr, i5 + 1, i5, r4);
            } else {
                Object[] objArr2 = this.f1245e;
                h.c(objArr2, objArr2, 1, 0, r4);
                Object[] objArr3 = this.f1245e;
                objArr3[0] = objArr3[objArr3.length - 1];
                int i6 = this.f1244d;
                h.c(objArr3, objArr3, i6 + 1, i6, objArr3.length - 1);
            }
            Object[] objArr4 = this.f1245e;
            int i7 = this.f1244d;
            objArr4[i7] = null;
            this.f1244d = p(i7);
        } else {
            int r5 = r(this.f1244d + m.c(this));
            Object[] objArr5 = this.f1245e;
            if (r4 <= r5) {
                h.c(objArr5, objArr5, r4, r4 + 1, r5 + 1);
            } else {
                h.c(objArr5, objArr5, r4, r4 + 1, objArr5.length);
                Object[] objArr6 = this.f1245e;
                objArr6[objArr6.length - 1] = objArr6[0];
                h.c(objArr6, objArr6, 0, 1, r5 + 1);
            }
            this.f1245e[r5] = null;
        }
        this.f1246f = size() - 1;
        return e4;
    }

    public int indexOf(Object obj) {
        int r4 = r(this.f1244d + size());
        int i4 = this.f1244d;
        if (i4 < r4) {
            while (i4 < r4) {
                if (!i.a(obj, this.f1245e[i4])) {
                    i4++;
                }
            }
            return -1;
        } else if (i4 < r4) {
            return -1;
        } else {
            int length = this.f1245e.length;
            while (true) {
                if (i4 >= length) {
                    int i5 = 0;
                    while (i5 < r4) {
                        if (i.a(obj, this.f1245e[i5])) {
                            i4 = i5 + this.f1245e.length;
                        } else {
                            i5++;
                        }
                    }
                    return -1;
                } else if (i.a(obj, this.f1245e[i4])) {
                    break;
                } else {
                    i4++;
                }
            }
        }
        return i4 - this.f1244d;
    }

    public boolean isEmpty() {
        return size() == 0;
    }

    public final void j(E e4) {
        o(size() + 1);
        int n4 = n(this.f1244d);
        this.f1244d = n4;
        this.f1245e[n4] = e4;
        this.f1246f = size() + 1;
    }

    public final void k(E e4) {
        o(size() + 1);
        this.f1245e[r(this.f1244d + size())] = e4;
        this.f1246f = size() + 1;
    }

    public int lastIndexOf(Object obj) {
        int i4;
        int r4 = r(this.f1244d + size());
        int i5 = this.f1244d;
        if (i5 < r4) {
            i4 = r4 - 1;
            if (i5 <= i4) {
                while (!i.a(obj, this.f1245e[i4])) {
                    if (i4 != i5) {
                        i4--;
                    }
                }
            }
            return -1;
        }
        if (i5 > r4) {
            int i6 = r4 - 1;
            while (true) {
                if (-1 >= i6) {
                    int g4 = i.g(this.f1245e);
                    int i7 = this.f1244d;
                    if (i7 <= g4) {
                        while (!i.a(obj, this.f1245e[i4])) {
                            if (i4 != i7) {
                                g4 = i4 - 1;
                            }
                        }
                    }
                } else if (i.a(obj, this.f1245e[i6])) {
                    i4 = i6 + this.f1245e.length;
                    break;
                } else {
                    i6--;
                }
            }
        }
        return -1;
        return i4 - this.f1244d;
    }

    public boolean remove(Object obj) {
        int indexOf = indexOf(obj);
        if (indexOf == -1) {
            return false;
        }
        remove(indexOf);
        return true;
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r1v1, resolved type: boolean} */
    /* JADX WARNING: type inference failed for: r1v0 */
    /* JADX WARNING: type inference failed for: r1v2 */
    /* JADX WARNING: type inference failed for: r1v3, types: [int] */
    /* JADX WARNING: type inference failed for: r1v4 */
    /* JADX WARNING: type inference failed for: r1v6 */
    /* JADX WARNING: type inference failed for: r1v9 */
    /* JADX WARNING: type inference failed for: r1v10 */
    /* JADX WARNING: type inference failed for: r1v12 */
    /* JADX WARNING: Failed to insert additional move for type inference */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean removeAll(java.util.Collection<? extends java.lang.Object> r12) {
        /*
            r11 = this;
            java.lang.String r0 = "elements"
            kotlin.jvm.internal.i.e(r12, r0)
            boolean r0 = r11.isEmpty()
            r1 = 0
            if (r0 != 0) goto L_0x0096
            java.lang.Object[] r0 = r11.f1245e
            int r0 = r0.length
            r2 = 1
            if (r0 != 0) goto L_0x0014
            r0 = 1
            goto L_0x0015
        L_0x0014:
            r0 = 0
        L_0x0015:
            if (r0 == 0) goto L_0x0019
            goto L_0x0096
        L_0x0019:
            int r0 = r11.f1244d
            int r3 = r11.size()
            int r0 = r0 + r3
            int r0 = r11.r(r0)
            int r3 = r11.f1244d
            r4 = 0
            if (r3 >= r0) goto L_0x0049
            r5 = r3
        L_0x002a:
            if (r3 >= r0) goto L_0x0043
            java.lang.Object[] r6 = r11.f1245e
            r6 = r6[r3]
            boolean r7 = r12.contains(r6)
            r7 = r7 ^ r2
            if (r7 == 0) goto L_0x003f
            java.lang.Object[] r7 = r11.f1245e
            int r8 = r5 + 1
            r7[r5] = r6
            r5 = r8
            goto L_0x0040
        L_0x003f:
            r1 = 1
        L_0x0040:
            int r3 = r3 + 1
            goto L_0x002a
        L_0x0043:
            java.lang.Object[] r12 = r11.f1245e
            b3.h.e(r12, r4, r5, r0)
            goto L_0x008b
        L_0x0049:
            java.lang.Object[] r5 = r11.f1245e
            int r5 = r5.length
            r6 = r3
            r7 = 0
        L_0x004e:
            if (r3 >= r5) goto L_0x0069
            java.lang.Object[] r8 = r11.f1245e
            r9 = r8[r3]
            r8[r3] = r4
            boolean r8 = r12.contains(r9)
            r8 = r8 ^ r2
            if (r8 == 0) goto L_0x0065
            java.lang.Object[] r8 = r11.f1245e
            int r10 = r6 + 1
            r8[r6] = r9
            r6 = r10
            goto L_0x0066
        L_0x0065:
            r7 = 1
        L_0x0066:
            int r3 = r3 + 1
            goto L_0x004e
        L_0x0069:
            int r3 = r11.r(r6)
            r5 = r3
        L_0x006e:
            if (r1 >= r0) goto L_0x008a
            java.lang.Object[] r3 = r11.f1245e
            r6 = r3[r1]
            r3[r1] = r4
            boolean r3 = r12.contains(r6)
            r3 = r3 ^ r2
            if (r3 == 0) goto L_0x0086
            java.lang.Object[] r3 = r11.f1245e
            r3[r5] = r6
            int r5 = r11.p(r5)
            goto L_0x0087
        L_0x0086:
            r7 = 1
        L_0x0087:
            int r1 = r1 + 1
            goto L_0x006e
        L_0x008a:
            r1 = r7
        L_0x008b:
            if (r1 == 0) goto L_0x0096
            int r12 = r11.f1244d
            int r5 = r5 - r12
            int r12 = r11.q(r5)
            r11.f1246f = r12
        L_0x0096:
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: b3.d.removeAll(java.util.Collection):boolean");
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r1v1, resolved type: boolean} */
    /* JADX WARNING: type inference failed for: r1v0 */
    /* JADX WARNING: type inference failed for: r1v2 */
    /* JADX WARNING: type inference failed for: r1v3, types: [int] */
    /* JADX WARNING: type inference failed for: r1v4 */
    /* JADX WARNING: type inference failed for: r1v6 */
    /* JADX WARNING: type inference failed for: r1v9 */
    /* JADX WARNING: type inference failed for: r1v10 */
    /* JADX WARNING: type inference failed for: r1v12 */
    /* JADX WARNING: Failed to insert additional move for type inference */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean retainAll(java.util.Collection<? extends java.lang.Object> r12) {
        /*
            r11 = this;
            java.lang.String r0 = "elements"
            kotlin.jvm.internal.i.e(r12, r0)
            boolean r0 = r11.isEmpty()
            r1 = 0
            if (r0 != 0) goto L_0x0093
            java.lang.Object[] r0 = r11.f1245e
            int r0 = r0.length
            r2 = 1
            if (r0 != 0) goto L_0x0014
            r0 = 1
            goto L_0x0015
        L_0x0014:
            r0 = 0
        L_0x0015:
            if (r0 == 0) goto L_0x0019
            goto L_0x0093
        L_0x0019:
            int r0 = r11.f1244d
            int r3 = r11.size()
            int r0 = r0 + r3
            int r0 = r11.r(r0)
            int r3 = r11.f1244d
            r4 = 0
            if (r3 >= r0) goto L_0x0048
            r5 = r3
        L_0x002a:
            if (r3 >= r0) goto L_0x0042
            java.lang.Object[] r6 = r11.f1245e
            r6 = r6[r3]
            boolean r7 = r12.contains(r6)
            if (r7 == 0) goto L_0x003e
            java.lang.Object[] r7 = r11.f1245e
            int r8 = r5 + 1
            r7[r5] = r6
            r5 = r8
            goto L_0x003f
        L_0x003e:
            r1 = 1
        L_0x003f:
            int r3 = r3 + 1
            goto L_0x002a
        L_0x0042:
            java.lang.Object[] r12 = r11.f1245e
            b3.h.e(r12, r4, r5, r0)
            goto L_0x0088
        L_0x0048:
            java.lang.Object[] r5 = r11.f1245e
            int r5 = r5.length
            r6 = r3
            r7 = 0
        L_0x004d:
            if (r3 >= r5) goto L_0x0067
            java.lang.Object[] r8 = r11.f1245e
            r9 = r8[r3]
            r8[r3] = r4
            boolean r8 = r12.contains(r9)
            if (r8 == 0) goto L_0x0063
            java.lang.Object[] r8 = r11.f1245e
            int r10 = r6 + 1
            r8[r6] = r9
            r6 = r10
            goto L_0x0064
        L_0x0063:
            r7 = 1
        L_0x0064:
            int r3 = r3 + 1
            goto L_0x004d
        L_0x0067:
            int r3 = r11.r(r6)
            r5 = r3
        L_0x006c:
            if (r1 >= r0) goto L_0x0087
            java.lang.Object[] r3 = r11.f1245e
            r6 = r3[r1]
            r3[r1] = r4
            boolean r3 = r12.contains(r6)
            if (r3 == 0) goto L_0x0083
            java.lang.Object[] r3 = r11.f1245e
            r3[r5] = r6
            int r5 = r11.p(r5)
            goto L_0x0084
        L_0x0083:
            r7 = 1
        L_0x0084:
            int r1 = r1 + 1
            goto L_0x006c
        L_0x0087:
            r1 = r7
        L_0x0088:
            if (r1 == 0) goto L_0x0093
            int r12 = r11.f1244d
            int r5 = r5 - r12
            int r12 = r11.q(r5)
            r11.f1246f = r12
        L_0x0093:
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: b3.d.retainAll(java.util.Collection):boolean");
    }

    public final E s() {
        if (!isEmpty()) {
            E[] eArr = this.f1245e;
            int i4 = this.f1244d;
            E e4 = eArr[i4];
            eArr[i4] = null;
            this.f1244d = p(i4);
            this.f1246f = size() - 1;
            return e4;
        }
        throw new NoSuchElementException("ArrayDeque is empty.");
    }

    public E set(int i4, E e4) {
        b.f1241d.a(i4, size());
        int r4 = r(this.f1244d + i4);
        E[] eArr = this.f1245e;
        E e5 = eArr[r4];
        eArr[r4] = e4;
        return e5;
    }

    public final E t() {
        if (!isEmpty()) {
            int r4 = r(this.f1244d + m.c(this));
            E[] eArr = this.f1245e;
            E e4 = eArr[r4];
            eArr[r4] = null;
            this.f1246f = size() - 1;
            return e4;
        }
        throw new NoSuchElementException("ArrayDeque is empty.");
    }

    public Object[] toArray() {
        return toArray(new Object[size()]);
    }

    public <T> T[] toArray(T[] tArr) {
        i.e(tArr, "array");
        if (tArr.length < size()) {
            tArr = f.a(tArr, size());
        }
        int r4 = r(this.f1244d + size());
        int i4 = this.f1244d;
        if (i4 < r4) {
            Object[] unused = h.d(this.f1245e, tArr, 0, i4, r4, 2, (Object) null);
        } else if (!isEmpty()) {
            Object[] objArr = this.f1245e;
            h.c(objArr, tArr, 0, this.f1244d, objArr.length);
            Object[] objArr2 = this.f1245e;
            h.c(objArr2, tArr, objArr2.length - this.f1244d, 0, r4);
        }
        if (tArr.length > size()) {
            tArr[size()] = null;
        }
        return tArr;
    }
}
