package b3;

import java.util.Collection;
import kotlin.jvm.internal.i;

class n extends m {
    public static <T> int g(Iterable<? extends T> iterable, int i4) {
        i.e(iterable, "<this>");
        return iterable instanceof Collection ? ((Collection) iterable).size() : i4;
    }
}
