package f0;

import java.io.Closeable;
import x.i;
import x.p;

public interface d extends Closeable {
    k C(p pVar, i iVar);

    Iterable<p> G();

    int f();

    void g(p pVar, long j4);

    void i(Iterable<k> iterable);

    boolean n(p pVar);

    void u(Iterable<k> iterable);

    Iterable<k> w(p pVar);

    long x(p pVar);
}
