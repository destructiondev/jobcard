package f0;

import z.b;
import z2.a;

public final class n0 implements b<m0> {

    /* renamed from: a  reason: collision with root package name */
    private final a<h0.a> f2025a;

    /* renamed from: b  reason: collision with root package name */
    private final a<h0.a> f2026b;

    /* renamed from: c  reason: collision with root package name */
    private final a<e> f2027c;

    /* renamed from: d  reason: collision with root package name */
    private final a<t0> f2028d;

    /* renamed from: e  reason: collision with root package name */
    private final a<String> f2029e;

    public n0(a<h0.a> aVar, a<h0.a> aVar2, a<e> aVar3, a<t0> aVar4, a<String> aVar5) {
        this.f2025a = aVar;
        this.f2026b = aVar2;
        this.f2027c = aVar3;
        this.f2028d = aVar4;
        this.f2029e = aVar5;
    }

    public static n0 a(a<h0.a> aVar, a<h0.a> aVar2, a<e> aVar3, a<t0> aVar4, a<String> aVar5) {
        return new n0(aVar, aVar2, aVar3, aVar4, aVar5);
    }

    public static m0 c(h0.a aVar, h0.a aVar2, Object obj, Object obj2, a<String> aVar3) {
        return new m0(aVar, aVar2, (e) obj, (t0) obj2, aVar3);
    }

    /* renamed from: b */
    public m0 get() {
        return c(this.f2025a.get(), this.f2026b.get(), this.f2027c.get(), this.f2028d.get(), this.f2029e);
    }
}
