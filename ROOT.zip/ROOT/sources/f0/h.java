package f0;

import android.content.Context;
import z.b;
import z.d;
import z2.a;

public final class h implements b<String> {

    /* renamed from: a  reason: collision with root package name */
    private final a<Context> f1994a;

    public h(a<Context> aVar) {
        this.f1994a = aVar;
    }

    public static h a(a<Context> aVar) {
        return new h(aVar);
    }

    public static String c(Context context) {
        return (String) d.c(f.b(context), "Cannot return null from a non-@Nullable @Provides method");
    }

    /* renamed from: b */
    public String get() {
        return c(this.f1994a.get());
    }
}
