package f0;

import android.database.sqlite.SQLiteDatabase;
import f0.m0;

public final /* synthetic */ class w implements m0.b {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ long f2060a;

    public /* synthetic */ w(long j4) {
        this.f2060a = j4;
    }

    public final Object a(Object obj) {
        return m0.g0(this.f2060a, (SQLiteDatabase) obj);
    }
}
