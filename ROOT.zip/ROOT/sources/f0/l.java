package f0;

import android.database.Cursor;
import f0.m0;

public final /* synthetic */ class l implements m0.b {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ long f2007a;

    public /* synthetic */ l(long j4) {
        this.f2007a = j4;
    }

    public final Object a(Object obj) {
        return ((Cursor) obj).moveToNext();
    }
}
