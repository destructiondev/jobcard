package f0;

import android.database.sqlite.SQLiteDatabase;
import f0.m0;

public final /* synthetic */ class c0 implements m0.d {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ SQLiteDatabase f1986a;

    public /* synthetic */ c0(SQLiteDatabase sQLiteDatabase) {
        this.f1986a = sQLiteDatabase;
    }

    public final Object a() {
        return this.f1986a.beginTransaction();
    }
}
