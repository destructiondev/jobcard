package f0;

import z.b;

public final class i implements b<Integer> {

    private static final class a {
        /* access modifiers changed from: private */

        /* renamed from: a  reason: collision with root package name */
        public static final i f1996a = new i();
    }

    public static i a() {
        return a.f1996a;
    }

    public static int c() {
        return f.c();
    }

    /* renamed from: b */
    public Integer get() {
        return Integer.valueOf(c());
    }
}
