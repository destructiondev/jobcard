package f0;

import f0.m0;

public final /* synthetic */ class d0 implements m0.d {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ t0 f1987a;

    public /* synthetic */ d0(t0 t0Var) {
        this.f1987a = t0Var;
    }

    public final Object a() {
        return this.f1987a.getWritableDatabase();
    }
}
