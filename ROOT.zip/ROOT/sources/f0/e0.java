package f0;

import android.database.sqlite.SQLiteDatabase;
import f0.m0;
import x.p;

public final /* synthetic */ class e0 implements m0.b {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ long f1989a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ p f1990b;

    public /* synthetic */ e0(long j4, p pVar) {
        this.f1989a = j4;
        this.f1990b = pVar;
    }

    public final Object a(Object obj) {
        return m0.w0(this.f1989a, this.f1990b, (SQLiteDatabase) obj);
    }
}
