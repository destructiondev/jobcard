package f0;

import android.database.sqlite.SQLiteDatabase;
import f0.t0;

public final /* synthetic */ class r0 implements t0.a {

    /* renamed from: a  reason: collision with root package name */
    public static final /* synthetic */ r0 f2041a = new r0();

    private /* synthetic */ r0() {
    }

    public final void a(SQLiteDatabase sQLiteDatabase) {
        t0.j(sQLiteDatabase);
    }
}
