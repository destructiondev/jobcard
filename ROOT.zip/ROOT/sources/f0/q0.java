package f0;

import android.database.sqlite.SQLiteDatabase;
import f0.t0;

public final /* synthetic */ class q0 implements t0.a {

    /* renamed from: a  reason: collision with root package name */
    public static final /* synthetic */ q0 f2039a = new q0();

    private /* synthetic */ q0() {
    }

    public final void a(SQLiteDatabase sQLiteDatabase) {
        t0.m(sQLiteDatabase);
    }
}
