package f0;

import android.database.Cursor;
import f0.m0;

public final /* synthetic */ class y implements m0.b {

    /* renamed from: a  reason: collision with root package name */
    public static final /* synthetic */ y f2062a = new y();

    private /* synthetic */ y() {
    }

    public final Object a(Object obj) {
        return Boolean.valueOf(((Cursor) obj).moveToNext());
    }
}
