package f0;

import android.database.Cursor;
import f0.m0;
import java.util.List;
import x.p;

public final /* synthetic */ class l0 implements m0.b {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ m0 f2008a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ List f2009b;

    /* renamed from: c  reason: collision with root package name */
    public final /* synthetic */ p f2010c;

    public /* synthetic */ l0(m0 m0Var, List list, p pVar) {
        this.f2008a = m0Var;
        this.f2009b = list;
        this.f2010c = pVar;
    }

    public final Object a(Object obj) {
        return this.f2008a.o0(this.f2009b, this.f2010c, (Cursor) obj);
    }
}
