package f0;

import f0.m0;

public final /* synthetic */ class b0 implements m0.b {

    /* renamed from: a  reason: collision with root package name */
    public static final /* synthetic */ b0 f1985a = new b0();

    private /* synthetic */ b0() {
    }

    public final Object a(Object obj) {
        return m0.c0((Throwable) obj);
    }
}
