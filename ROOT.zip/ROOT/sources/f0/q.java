package f0;

import a0.c;
import android.database.sqlite.SQLiteDatabase;
import f0.m0;

public final /* synthetic */ class q implements m0.b {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ String f2036a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ c.b f2037b;

    /* renamed from: c  reason: collision with root package name */
    public final /* synthetic */ long f2038c;

    public /* synthetic */ q(String str, c.b bVar, long j4) {
        this.f2036a = str;
        this.f2037b = bVar;
        this.f2038c = j4;
    }

    public final Object a(Object obj) {
        return m0.v0(this.f2036a, this.f2037b, this.f2038c, (SQLiteDatabase) obj);
    }
}
