package f0;

import android.database.Cursor;
import f0.m0;
import java.util.Map;

public final /* synthetic */ class r implements m0.b {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ Map f2040a;

    public /* synthetic */ r(Map map) {
        this.f2040a = map;
    }

    public final Object a(Object obj) {
        return m0.p0(this.f2040a, (Cursor) obj);
    }
}
