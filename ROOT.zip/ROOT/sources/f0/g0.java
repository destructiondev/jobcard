package f0;

import android.database.Cursor;
import f0.m0;

public final /* synthetic */ class g0 implements m0.b {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ m0 f1993a;

    public /* synthetic */ g0(m0 m0Var) {
        this.f1993a = m0Var;
    }

    public final Object a(Object obj) {
        return this.f1993a.s0((Cursor) obj);
    }
}
