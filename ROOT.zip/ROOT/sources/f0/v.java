package f0;

import android.database.Cursor;
import f0.m0;

public final /* synthetic */ class v implements m0.b {

    /* renamed from: a  reason: collision with root package name */
    public static final /* synthetic */ v f2059a = new v();

    private /* synthetic */ v() {
    }

    public final Object a(Object obj) {
        return m0.h0((Cursor) obj);
    }
}
