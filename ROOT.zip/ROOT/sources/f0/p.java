package f0;

import android.database.sqlite.SQLiteDatabase;
import f0.m0;

public final /* synthetic */ class p implements m0.b {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ m0 f2033a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ x.p f2034b;

    public /* synthetic */ p(m0 m0Var, x.p pVar) {
        this.f2033a = m0Var;
        this.f2034b = pVar;
    }

    public final Object a(Object obj) {
        return this.f2033a.i0(this.f2034b, (SQLiteDatabase) obj);
    }
}
