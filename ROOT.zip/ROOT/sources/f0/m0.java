package f0;

import a0.a;
import a0.c;
import a0.e;
import a0.f;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabaseLockedException;
import android.os.SystemClock;
import android.util.Base64;
import g0.b;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import x.h;
import x.i;
import x.p;

public class m0 implements d, g0.b, c {

    /* renamed from: i  reason: collision with root package name */
    private static final v.b f2014i = v.b.b("proto");

    /* renamed from: d  reason: collision with root package name */
    private final t0 f2015d;

    /* renamed from: e  reason: collision with root package name */
    private final h0.a f2016e;

    /* renamed from: f  reason: collision with root package name */
    private final h0.a f2017f;

    /* renamed from: g  reason: collision with root package name */
    private final e f2018g;

    /* renamed from: h  reason: collision with root package name */
    private final z2.a<String> f2019h;

    interface b<T, U> {
        U a(T t4);
    }

    private static class c {

        /* renamed from: a  reason: collision with root package name */
        final String f2020a;

        /* renamed from: b  reason: collision with root package name */
        final String f2021b;

        private c(String str, String str2) {
            this.f2020a = str;
            this.f2021b = str2;
        }
    }

    interface d<T> {
        T a();
    }

    m0(h0.a aVar, h0.a aVar2, e eVar, t0 t0Var, z2.a<String> aVar3) {
        this.f2015d = t0Var;
        this.f2016e = aVar;
        this.f2017f = aVar2;
        this.f2018g = eVar;
        this.f2019h = aVar3;
    }

    private static byte[] A0(String str) {
        if (str == null) {
            return null;
        }
        return Base64.decode(str, 0);
    }

    private void B0(a.C0000a aVar, Map<String, List<a0.c>> map) {
        for (Map.Entry next : map.entrySet()) {
            aVar.a(a0.d.c().c((String) next.getKey()).b((List) next.getValue()).a());
        }
    }

    private byte[] C0(long j4) {
        return (byte[]) G0(Q().query("event_payloads", new String[]{"bytes"}, "event_id = ?", new String[]{String.valueOf(j4)}, (String) null, (String) null, "sequence_num"), s.f2042a);
    }

    private <T> T D0(d<T> dVar, b<Throwable, T> bVar) {
        long a4 = this.f2017f.a();
        while (true) {
            try {
                return dVar.a();
            } catch (SQLiteDatabaseLockedException e4) {
                if (this.f2017f.a() >= ((long) this.f2018g.b()) + a4) {
                    return bVar.a(e4);
                }
                SystemClock.sleep(50);
            }
        }
    }

    private static v.b E0(String str) {
        return str == null ? f2014i : v.b.b(str);
    }

    private static String F0(Iterable<k> iterable) {
        StringBuilder sb = new StringBuilder("(");
        Iterator<k> it = iterable.iterator();
        while (it.hasNext()) {
            sb.append(it.next().c());
            if (it.hasNext()) {
                sb.append(',');
            }
        }
        sb.append(')');
        return sb.toString();
    }

    static <T> T G0(Cursor cursor, b<Cursor, T> bVar) {
        try {
            return bVar.a(cursor);
        } finally {
            cursor.close();
        }
    }

    private c.b M(int i4) {
        c.b bVar = c.b.REASON_UNKNOWN;
        if (i4 == bVar.a()) {
            return bVar;
        }
        c.b bVar2 = c.b.MESSAGE_TOO_OLD;
        if (i4 == bVar2.a()) {
            return bVar2;
        }
        c.b bVar3 = c.b.CACHE_FULL;
        if (i4 == bVar3.a()) {
            return bVar3;
        }
        c.b bVar4 = c.b.PAYLOAD_TOO_BIG;
        if (i4 == bVar4.a()) {
            return bVar4;
        }
        c.b bVar5 = c.b.MAX_RETRIES_REACHED;
        if (i4 == bVar5.a()) {
            return bVar5;
        }
        c.b bVar6 = c.b.INVALID_PAYLOD;
        if (i4 == bVar6.a()) {
            return bVar6;
        }
        c.b bVar7 = c.b.SERVER_ERROR;
        if (i4 == bVar7.a()) {
            return bVar7;
        }
        b0.a.b("SQLiteEventStore", "%n is not valid. No matched LogEventDropped-Reason found. Treated it as REASON_UNKNOWN", Integer.valueOf(i4));
        return bVar;
    }

    private void N(SQLiteDatabase sQLiteDatabase) {
        D0(new c0(sQLiteDatabase), b0.f1985a);
    }

    private long O(SQLiteDatabase sQLiteDatabase, p pVar) {
        Long V = V(sQLiteDatabase, pVar);
        if (V != null) {
            return V.longValue();
        }
        ContentValues contentValues = new ContentValues();
        contentValues.put("backend_name", pVar.b());
        contentValues.put("priority", Integer.valueOf(i0.a.a(pVar.d())));
        contentValues.put("next_request_ms", 0);
        if (pVar.c() != null) {
            contentValues.put("extras", Base64.encodeToString(pVar.c(), 0));
        }
        return sQLiteDatabase.insert("transport_contexts", (String) null, contentValues);
    }

    private a0.b R() {
        return a0.b.b().b(e.c().b(P()).c(e.f1988a.f()).a()).a();
    }

    private long S() {
        return Q().compileStatement("PRAGMA page_count").simpleQueryForLong();
    }

    private long T() {
        return Q().compileStatement("PRAGMA page_size").simpleQueryForLong();
    }

    private f U() {
        return (f) W(new w(this.f2016e.a()));
    }

    private Long V(SQLiteDatabase sQLiteDatabase, p pVar) {
        StringBuilder sb = new StringBuilder("backend_name = ? and priority = ?");
        ArrayList arrayList = new ArrayList(Arrays.asList(new String[]{pVar.b(), String.valueOf(i0.a.a(pVar.d()))}));
        if (pVar.c() != null) {
            sb.append(" and extras = ?");
            arrayList.add(Base64.encodeToString(pVar.c(), 0));
        } else {
            sb.append(" and extras is null");
        }
        return (Long) G0(sQLiteDatabase.query("transport_contexts", new String[]{"_id"}, sb.toString(), (String[]) arrayList.toArray(new String[0]), (String) null, (String) null, (String) null), v.f2059a);
    }

    private boolean X() {
        return S() * T() >= this.f2018g.f();
    }

    private List<k> Y(List<k> list, Map<Long, Set<c>> map) {
        ListIterator<k> listIterator = list.listIterator();
        while (listIterator.hasNext()) {
            k next = listIterator.next();
            if (map.containsKey(Long.valueOf(next.c()))) {
                i.a l4 = next.b().l();
                for (c cVar : map.get(Long.valueOf(next.c()))) {
                    l4.c(cVar.f2020a, cVar.f2021b);
                }
                listIterator.set(k.a(next.c(), next.d(), l4.d()));
            }
        }
        return list;
    }

    /* access modifiers changed from: private */
    public /* synthetic */ Object Z(Cursor cursor) {
        while (cursor.moveToNext()) {
            int i4 = cursor.getInt(0);
            c((long) i4, c.b.MESSAGE_TOO_OLD, cursor.getString(1));
        }
        return null;
    }

    /* access modifiers changed from: private */
    public /* synthetic */ Integer a0(long j4, SQLiteDatabase sQLiteDatabase) {
        String[] strArr = {String.valueOf(j4)};
        G0(sQLiteDatabase.rawQuery("SELECT COUNT(*), transport_name FROM events WHERE timestamp_ms < ? GROUP BY transport_name", strArr), new f0(this));
        return Integer.valueOf(sQLiteDatabase.delete("events", "timestamp_ms < ?", strArr));
    }

    /* access modifiers changed from: private */
    public static /* synthetic */ Object c0(Throwable th) {
        throw new g0.a("Timed out while trying to acquire the lock.", th);
    }

    /* access modifiers changed from: private */
    public static /* synthetic */ SQLiteDatabase d0(Throwable th) {
        throw new g0.a("Timed out while trying to open db.", th);
    }

    /* access modifiers changed from: private */
    public static /* synthetic */ Long e0(Cursor cursor) {
        return Long.valueOf(cursor.moveToNext() ? cursor.getLong(0) : 0);
    }

    /* access modifiers changed from: private */
    public static /* synthetic */ f g0(long j4, SQLiteDatabase sQLiteDatabase) {
        return (f) G0(sQLiteDatabase.rawQuery("SELECT last_metrics_upload_ms FROM global_log_event_state LIMIT 1", new String[0]), new l(j4));
    }

    /* access modifiers changed from: private */
    public static /* synthetic */ Long h0(Cursor cursor) {
        if (!cursor.moveToNext()) {
            return null;
        }
        return Long.valueOf(cursor.getLong(0));
    }

    /* access modifiers changed from: private */
    public /* synthetic */ Boolean i0(p pVar, SQLiteDatabase sQLiteDatabase) {
        Long V = V(sQLiteDatabase, pVar);
        if (V == null) {
            return Boolean.FALSE;
        }
        return (Boolean) G0(Q().rawQuery("SELECT 1 FROM events WHERE context_id = ? LIMIT 1", new String[]{V.toString()}), y.f2062a);
    }

    /* access modifiers changed from: private */
    public static /* synthetic */ List j0(SQLiteDatabase sQLiteDatabase) {
        return (List) G0(sQLiteDatabase.rawQuery("SELECT distinct t._id, t.backend_name, t.priority, t.extras FROM transport_contexts AS t, events AS e WHERE e.context_id = t._id", new String[0]), t.f2044a);
    }

    /* access modifiers changed from: private */
    public static /* synthetic */ List k0(Cursor cursor) {
        ArrayList arrayList = new ArrayList();
        while (cursor.moveToNext()) {
            arrayList.add(p.a().b(cursor.getString(1)).d(i0.a.b(cursor.getInt(2))).c(A0(cursor.getString(3))).a());
        }
        return arrayList;
    }

    /* access modifiers changed from: private */
    public /* synthetic */ List l0(p pVar, SQLiteDatabase sQLiteDatabase) {
        List<k> y02 = y0(sQLiteDatabase, pVar, this.f2018g.d());
        for (v.d dVar : v.d.values()) {
            if (dVar != pVar.d()) {
                int d4 = this.f2018g.d() - y02.size();
                if (d4 <= 0) {
                    break;
                }
                y02.addAll(y0(sQLiteDatabase, pVar.f(dVar), d4));
            }
        }
        return Y(y02, z0(sQLiteDatabase, y02));
    }

    /* access modifiers changed from: private */
    public /* synthetic */ a0.a m0(Map map, a.C0000a aVar, Cursor cursor) {
        while (cursor.moveToNext()) {
            String string = cursor.getString(0);
            c.b M = M(cursor.getInt(1));
            long j4 = cursor.getLong(2);
            if (!map.containsKey(string)) {
                map.put(string, new ArrayList());
            }
            ((List) map.get(string)).add(a0.c.c().c(M).b(j4).a());
        }
        B0(aVar, map);
        aVar.e(U());
        aVar.d(R());
        aVar.c(this.f2019h.get());
        return aVar.b();
    }

    /* access modifiers changed from: private */
    public /* synthetic */ a0.a n0(String str, Map map, a.C0000a aVar, SQLiteDatabase sQLiteDatabase) {
        return (a0.a) G0(sQLiteDatabase.rawQuery(str, new String[0]), new m(this, map, aVar));
    }

    /* access modifiers changed from: private */
    public /* synthetic */ Object o0(List list, p pVar, Cursor cursor) {
        while (cursor.moveToNext()) {
            boolean z3 = false;
            long j4 = cursor.getLong(0);
            if (cursor.getInt(7) != 0) {
                z3 = true;
            }
            i.a k4 = i.a().j(cursor.getString(1)).i(cursor.getLong(2)).k(cursor.getLong(3));
            k4.h(z3 ? new h(E0(cursor.getString(4)), cursor.getBlob(5)) : new h(E0(cursor.getString(4)), C0(j4)));
            if (!cursor.isNull(6)) {
                k4.g(Integer.valueOf(cursor.getInt(6)));
            }
            list.add(k.a(j4, pVar, k4.d()));
        }
        return null;
    }

    /* access modifiers changed from: private */
    public static /* synthetic */ Object p0(Map map, Cursor cursor) {
        while (cursor.moveToNext()) {
            long j4 = cursor.getLong(0);
            Set set = (Set) map.get(Long.valueOf(j4));
            if (set == null) {
                set = new HashSet();
                map.put(Long.valueOf(j4), set);
            }
            set.add(new c(cursor.getString(1), cursor.getString(2)));
        }
        return null;
    }

    /* access modifiers changed from: private */
    public /* synthetic */ Long q0(i iVar, p pVar, SQLiteDatabase sQLiteDatabase) {
        if (X()) {
            c(1, c.b.CACHE_FULL, iVar.j());
            return -1L;
        }
        long O = O(sQLiteDatabase, pVar);
        int e4 = this.f2018g.e();
        byte[] a4 = iVar.e().a();
        boolean z3 = a4.length <= e4;
        ContentValues contentValues = new ContentValues();
        contentValues.put("context_id", Long.valueOf(O));
        contentValues.put("transport_name", iVar.j());
        contentValues.put("timestamp_ms", Long.valueOf(iVar.f()));
        contentValues.put("uptime_ms", Long.valueOf(iVar.k()));
        contentValues.put("payload_encoding", iVar.e().b().a());
        contentValues.put("code", iVar.d());
        contentValues.put("num_attempts", 0);
        contentValues.put("inline", Boolean.valueOf(z3));
        contentValues.put("payload", z3 ? a4 : new byte[0]);
        long insert = sQLiteDatabase.insert("events", (String) null, contentValues);
        if (!z3) {
            int ceil = (int) Math.ceil(((double) a4.length) / ((double) e4));
            for (int i4 = 1; i4 <= ceil; i4++) {
                byte[] copyOfRange = Arrays.copyOfRange(a4, (i4 - 1) * e4, Math.min(i4 * e4, a4.length));
                ContentValues contentValues2 = new ContentValues();
                contentValues2.put("event_id", Long.valueOf(insert));
                contentValues2.put("sequence_num", Integer.valueOf(i4));
                contentValues2.put("bytes", copyOfRange);
                sQLiteDatabase.insert("event_payloads", (String) null, contentValues2);
            }
        }
        for (Map.Entry next : iVar.i().entrySet()) {
            ContentValues contentValues3 = new ContentValues();
            contentValues3.put("event_id", Long.valueOf(insert));
            contentValues3.put("name", (String) next.getKey());
            contentValues3.put("value", (String) next.getValue());
            sQLiteDatabase.insert("event_metadata", (String) null, contentValues3);
        }
        return Long.valueOf(insert);
    }

    /* access modifiers changed from: private */
    public static /* synthetic */ byte[] r0(Cursor cursor) {
        ArrayList arrayList = new ArrayList();
        int i4 = 0;
        while (cursor.moveToNext()) {
            byte[] blob = cursor.getBlob(0);
            arrayList.add(blob);
            i4 += blob.length;
        }
        byte[] bArr = new byte[i4];
        int i5 = 0;
        for (int i6 = 0; i6 < arrayList.size(); i6++) {
            byte[] bArr2 = (byte[]) arrayList.get(i6);
            System.arraycopy(bArr2, 0, bArr, i5, bArr2.length);
            i5 += bArr2.length;
        }
        return bArr;
    }

    /* access modifiers changed from: private */
    public /* synthetic */ Object s0(Cursor cursor) {
        while (cursor.moveToNext()) {
            int i4 = cursor.getInt(0);
            c((long) i4, c.b.MAX_RETRIES_REACHED, cursor.getString(1));
        }
        return null;
    }

    /* access modifiers changed from: private */
    public /* synthetic */ Object t0(String str, String str2, SQLiteDatabase sQLiteDatabase) {
        sQLiteDatabase.compileStatement(str).execute();
        G0(sQLiteDatabase.rawQuery(str2, (String[]) null), new g0(this));
        sQLiteDatabase.compileStatement("DELETE FROM events WHERE num_attempts >= 16").execute();
        return null;
    }

    /* access modifiers changed from: private */
    public static /* synthetic */ Boolean u0(Cursor cursor) {
        return Boolean.valueOf(cursor.getCount() > 0);
    }

    /* access modifiers changed from: private */
    public static /* synthetic */ Object v0(String str, c.b bVar, long j4, SQLiteDatabase sQLiteDatabase) {
        if (!((Boolean) G0(sQLiteDatabase.rawQuery("SELECT 1 FROM log_event_dropped WHERE log_source = ? AND reason = ?", new String[]{str, Integer.toString(bVar.a())}), x.f2061a)).booleanValue()) {
            ContentValues contentValues = new ContentValues();
            contentValues.put("log_source", str);
            contentValues.put("reason", Integer.valueOf(bVar.a()));
            contentValues.put("events_dropped_count", Long.valueOf(j4));
            sQLiteDatabase.insert("log_event_dropped", (String) null, contentValues);
        } else {
            sQLiteDatabase.execSQL("UPDATE log_event_dropped SET events_dropped_count = events_dropped_count + " + j4 + " WHERE log_source = ? AND reason = ?", new String[]{str, Integer.toString(bVar.a())});
        }
        return null;
    }

    /* access modifiers changed from: private */
    public static /* synthetic */ Object w0(long j4, p pVar, SQLiteDatabase sQLiteDatabase) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("next_request_ms", Long.valueOf(j4));
        if (sQLiteDatabase.update("transport_contexts", contentValues, "backend_name = ? and priority = ?", new String[]{pVar.b(), String.valueOf(i0.a.a(pVar.d()))}) < 1) {
            contentValues.put("backend_name", pVar.b());
            contentValues.put("priority", Integer.valueOf(i0.a.a(pVar.d())));
            sQLiteDatabase.insert("transport_contexts", (String) null, contentValues);
        }
        return null;
    }

    /* access modifiers changed from: private */
    public /* synthetic */ Object x0(SQLiteDatabase sQLiteDatabase) {
        sQLiteDatabase.compileStatement("DELETE FROM log_event_dropped").execute();
        sQLiteDatabase.compileStatement("UPDATE global_log_event_state SET last_metrics_upload_ms=" + this.f2016e.a()).execute();
        return null;
    }

    private List<k> y0(SQLiteDatabase sQLiteDatabase, p pVar, int i4) {
        ArrayList arrayList = new ArrayList();
        Long V = V(sQLiteDatabase, pVar);
        if (V == null) {
            return arrayList;
        }
        SQLiteDatabase sQLiteDatabase2 = sQLiteDatabase;
        G0(sQLiteDatabase2.query("events", new String[]{"_id", "transport_name", "timestamp_ms", "uptime_ms", "payload_encoding", "payload", "code", "inline"}, "context_id = ?", new String[]{V.toString()}, (String) null, (String) null, (String) null, String.valueOf(i4)), new l0(this, arrayList, pVar));
        return arrayList;
    }

    private Map<Long, Set<c>> z0(SQLiteDatabase sQLiteDatabase, List<k> list) {
        HashMap hashMap = new HashMap();
        StringBuilder sb = new StringBuilder("event_id IN (");
        for (int i4 = 0; i4 < list.size(); i4++) {
            sb.append(list.get(i4).c());
            if (i4 < list.size() - 1) {
                sb.append(',');
            }
        }
        sb.append(')');
        G0(sQLiteDatabase.query("event_metadata", new String[]{"event_id", "name", "value"}, sb.toString(), (String[]) null, (String) null, (String) null, (String) null), new r(hashMap));
        return hashMap;
    }

    public k C(p pVar, i iVar) {
        b0.a.c("SQLiteEventStore", "Storing event with priority=%s, name=%s for destination %s", pVar.d(), iVar.j(), pVar.b());
        long longValue = ((Long) W(new n(this, iVar, pVar))).longValue();
        if (longValue < 1) {
            return null;
        }
        return k.a(longValue, pVar, iVar);
    }

    public Iterable<p> G() {
        return (Iterable) W(z.f2063a);
    }

    /* access modifiers changed from: package-private */
    public long P() {
        return S() * T();
    }

    /* access modifiers changed from: package-private */
    public SQLiteDatabase Q() {
        t0 t0Var = this.f2015d;
        Objects.requireNonNull(t0Var);
        return (SQLiteDatabase) D0(new d0(t0Var), a0.f1981a);
    }

    /* access modifiers changed from: package-private */
    public <T> T W(b<SQLiteDatabase, T> bVar) {
        SQLiteDatabase Q = Q();
        Q.beginTransaction();
        try {
            T a4 = bVar.a(Q);
            Q.setTransactionSuccessful();
            return a4;
        } finally {
            Q.endTransaction();
        }
    }

    public <T> T a(b.a<T> aVar) {
        SQLiteDatabase Q = Q();
        N(Q);
        try {
            T a4 = aVar.a();
            Q.setTransactionSuccessful();
            return a4;
        } finally {
            Q.endTransaction();
        }
    }

    public void b() {
        W(new h0(this));
    }

    public void c(long j4, c.b bVar, String str) {
        W(new q(str, bVar, j4));
    }

    public void close() {
        this.f2015d.close();
    }

    public a0.a d() {
        return (a0.a) W(new k0(this, "SELECT log_source, reason, events_dropped_count FROM log_event_dropped", new HashMap(), a0.a.e()));
    }

    public int f() {
        return ((Integer) W(new i0(this, this.f2016e.a() - this.f2018g.c()))).intValue();
    }

    public void g(p pVar, long j4) {
        W(new e0(j4, pVar));
    }

    public void i(Iterable<k> iterable) {
        if (iterable.iterator().hasNext()) {
            Q().compileStatement("DELETE FROM events WHERE _id in " + F0(iterable)).execute();
        }
    }

    public boolean n(p pVar) {
        return ((Boolean) W(new p(this, pVar))).booleanValue();
    }

    public void u(Iterable<k> iterable) {
        if (iterable.iterator().hasNext()) {
            W(new j0(this, "UPDATE events SET num_attempts = num_attempts + 1 WHERE _id in " + F0(iterable), "SELECT COUNT(*), transport_name FROM events WHERE num_attempts >= 16 GROUP BY transport_name"));
        }
    }

    public Iterable<k> w(p pVar) {
        return (Iterable) W(new o(this, pVar));
    }

    public long x(p pVar) {
        return ((Long) G0(Q().rawQuery("SELECT next_request_ms FROM transport_contexts WHERE backend_name = ? and priority = ?", new String[]{pVar.b(), String.valueOf(i0.a.a(pVar.d()))}), u.f2055a)).longValue();
    }
}
