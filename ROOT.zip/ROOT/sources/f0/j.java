package f0;

import z.b;
import z.d;

public final class j implements b<e> {

    private static final class a {
        /* access modifiers changed from: private */

        /* renamed from: a  reason: collision with root package name */
        public static final j f1999a = new j();
    }

    public static j a() {
        return a.f1999a;
    }

    public static e c() {
        return (e) d.c(f.d(), "Cannot return null from a non-@Nullable @Provides method");
    }

    /* renamed from: b */
    public e get() {
        return c();
    }
}
