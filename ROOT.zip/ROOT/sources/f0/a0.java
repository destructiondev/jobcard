package f0;

import f0.m0;

public final /* synthetic */ class a0 implements m0.b {

    /* renamed from: a  reason: collision with root package name */
    public static final /* synthetic */ a0 f1981a = new a0();

    private /* synthetic */ a0() {
    }

    public final Object a(Object obj) {
        return m0.d0((Throwable) obj);
    }
}
