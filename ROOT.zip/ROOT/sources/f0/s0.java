package f0;

import android.database.sqlite.SQLiteDatabase;
import f0.t0;

public final /* synthetic */ class s0 implements t0.a {

    /* renamed from: a  reason: collision with root package name */
    public static final /* synthetic */ s0 f2043a = new s0();

    private /* synthetic */ s0() {
    }

    public final void a(SQLiteDatabase sQLiteDatabase) {
        t0.o(sQLiteDatabase);
    }
}
