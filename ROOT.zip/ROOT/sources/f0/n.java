package f0;

import android.database.sqlite.SQLiteDatabase;
import f0.m0;
import x.i;
import x.p;

public final /* synthetic */ class n implements m0.b {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ m0 f2022a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ i f2023b;

    /* renamed from: c  reason: collision with root package name */
    public final /* synthetic */ p f2024c;

    public /* synthetic */ n(m0 m0Var, i iVar, p pVar) {
        this.f2022a = m0Var;
        this.f2023b = iVar;
        this.f2024c = pVar;
    }

    public final Object a(Object obj) {
        return this.f2022a.q0(this.f2023b, this.f2024c, (SQLiteDatabase) obj);
    }
}
