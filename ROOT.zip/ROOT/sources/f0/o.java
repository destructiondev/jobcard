package f0;

import android.database.sqlite.SQLiteDatabase;
import f0.m0;
import x.p;

public final /* synthetic */ class o implements m0.b {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ m0 f2030a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ p f2031b;

    public /* synthetic */ o(m0 m0Var, p pVar) {
        this.f2030a = m0Var;
        this.f2031b = pVar;
    }

    public final Object a(Object obj) {
        return this.f2030a.l0(this.f2031b, (SQLiteDatabase) obj);
    }
}
