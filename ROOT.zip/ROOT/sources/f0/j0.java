package f0;

import android.database.sqlite.SQLiteDatabase;
import f0.m0;

public final /* synthetic */ class j0 implements m0.b {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ m0 f2000a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ String f2001b;

    /* renamed from: c  reason: collision with root package name */
    public final /* synthetic */ String f2002c;

    public /* synthetic */ j0(m0 m0Var, String str, String str2) {
        this.f2000a = m0Var;
        this.f2001b = str;
        this.f2002c = str2;
    }

    public final Object a(Object obj) {
        return this.f2000a.t0(this.f2001b, this.f2002c, (SQLiteDatabase) obj);
    }
}
