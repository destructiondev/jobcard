package f0;

import android.content.Context;
import z.b;
import z2.a;

public final class u0 implements b<t0> {

    /* renamed from: a  reason: collision with root package name */
    private final a<Context> f2056a;

    /* renamed from: b  reason: collision with root package name */
    private final a<String> f2057b;

    /* renamed from: c  reason: collision with root package name */
    private final a<Integer> f2058c;

    public u0(a<Context> aVar, a<String> aVar2, a<Integer> aVar3) {
        this.f2056a = aVar;
        this.f2057b = aVar2;
        this.f2058c = aVar3;
    }

    public static u0 a(a<Context> aVar, a<String> aVar2, a<Integer> aVar3) {
        return new u0(aVar, aVar2, aVar3);
    }

    public static t0 c(Context context, String str, int i4) {
        return new t0(context, str, i4);
    }

    /* renamed from: b */
    public t0 get() {
        return c(this.f2056a.get(), this.f2057b.get(), this.f2058c.get().intValue());
    }
}
