package f0;

import android.database.sqlite.SQLiteDatabase;
import f0.m0;

public final /* synthetic */ class i0 implements m0.b {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ m0 f1997a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ long f1998b;

    public /* synthetic */ i0(m0 m0Var, long j4) {
        this.f1997a = m0Var;
        this.f1998b = j4;
    }

    public final Object a(Object obj) {
        return this.f1997a.a0(this.f1998b, (SQLiteDatabase) obj);
    }
}
