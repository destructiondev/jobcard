package f0;

import android.database.Cursor;
import f0.m0;

public final /* synthetic */ class t implements m0.b {

    /* renamed from: a  reason: collision with root package name */
    public static final /* synthetic */ t f2044a = new t();

    private /* synthetic */ t() {
    }

    public final Object a(Object obj) {
        return m0.k0((Cursor) obj);
    }
}
