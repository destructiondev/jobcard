package f0;

import x.i;
import x.p;

public abstract class k {
    public static k a(long j4, p pVar, i iVar) {
        return new b(j4, pVar, iVar);
    }

    public abstract i b();

    public abstract long c();

    public abstract p d();
}
