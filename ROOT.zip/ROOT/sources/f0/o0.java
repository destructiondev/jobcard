package f0;

import android.database.sqlite.SQLiteDatabase;
import f0.t0;

public final /* synthetic */ class o0 implements t0.a {

    /* renamed from: a  reason: collision with root package name */
    public static final /* synthetic */ o0 f2032a = new o0();

    private /* synthetic */ o0() {
    }

    public final void a(SQLiteDatabase sQLiteDatabase) {
        t0.k(sQLiteDatabase);
    }
}
