package f0;

import f0.e;

final class a extends e {

    /* renamed from: b  reason: collision with root package name */
    private final long f1971b;

    /* renamed from: c  reason: collision with root package name */
    private final int f1972c;

    /* renamed from: d  reason: collision with root package name */
    private final int f1973d;

    /* renamed from: e  reason: collision with root package name */
    private final long f1974e;

    /* renamed from: f  reason: collision with root package name */
    private final int f1975f;

    static final class b extends e.a {

        /* renamed from: a  reason: collision with root package name */
        private Long f1976a;

        /* renamed from: b  reason: collision with root package name */
        private Integer f1977b;

        /* renamed from: c  reason: collision with root package name */
        private Integer f1978c;

        /* renamed from: d  reason: collision with root package name */
        private Long f1979d;

        /* renamed from: e  reason: collision with root package name */
        private Integer f1980e;

        b() {
        }

        /* access modifiers changed from: package-private */
        public e a() {
            String str = "";
            if (this.f1976a == null) {
                str = str + " maxStorageSizeInBytes";
            }
            if (this.f1977b == null) {
                str = str + " loadBatchSize";
            }
            if (this.f1978c == null) {
                str = str + " criticalSectionEnterTimeoutMs";
            }
            if (this.f1979d == null) {
                str = str + " eventCleanUpAge";
            }
            if (this.f1980e == null) {
                str = str + " maxBlobByteSizePerRow";
            }
            if (str.isEmpty()) {
                return new a(this.f1976a.longValue(), this.f1977b.intValue(), this.f1978c.intValue(), this.f1979d.longValue(), this.f1980e.intValue());
            }
            throw new IllegalStateException("Missing required properties:" + str);
        }

        /* access modifiers changed from: package-private */
        public e.a b(int i4) {
            this.f1978c = Integer.valueOf(i4);
            return this;
        }

        /* access modifiers changed from: package-private */
        public e.a c(long j4) {
            this.f1979d = Long.valueOf(j4);
            return this;
        }

        /* access modifiers changed from: package-private */
        public e.a d(int i4) {
            this.f1977b = Integer.valueOf(i4);
            return this;
        }

        /* access modifiers changed from: package-private */
        public e.a e(int i4) {
            this.f1980e = Integer.valueOf(i4);
            return this;
        }

        /* access modifiers changed from: package-private */
        public e.a f(long j4) {
            this.f1976a = Long.valueOf(j4);
            return this;
        }
    }

    private a(long j4, int i4, int i5, long j5, int i6) {
        this.f1971b = j4;
        this.f1972c = i4;
        this.f1973d = i5;
        this.f1974e = j5;
        this.f1975f = i6;
    }

    /* access modifiers changed from: package-private */
    public int b() {
        return this.f1973d;
    }

    /* access modifiers changed from: package-private */
    public long c() {
        return this.f1974e;
    }

    /* access modifiers changed from: package-private */
    public int d() {
        return this.f1972c;
    }

    /* access modifiers changed from: package-private */
    public int e() {
        return this.f1975f;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof e)) {
            return false;
        }
        e eVar = (e) obj;
        return this.f1971b == eVar.f() && this.f1972c == eVar.d() && this.f1973d == eVar.b() && this.f1974e == eVar.c() && this.f1975f == eVar.e();
    }

    /* access modifiers changed from: package-private */
    public long f() {
        return this.f1971b;
    }

    public int hashCode() {
        long j4 = this.f1971b;
        long j5 = this.f1974e;
        return this.f1975f ^ ((((((((((int) (j4 ^ (j4 >>> 32))) ^ 1000003) * 1000003) ^ this.f1972c) * 1000003) ^ this.f1973d) * 1000003) ^ ((int) ((j5 >>> 32) ^ j5))) * 1000003);
    }

    public String toString() {
        return "EventStoreConfig{maxStorageSizeInBytes=" + this.f1971b + ", loadBatchSize=" + this.f1972c + ", criticalSectionEnterTimeoutMs=" + this.f1973d + ", eventCleanUpAge=" + this.f1974e + ", maxBlobByteSizePerRow=" + this.f1975f + "}";
    }
}
