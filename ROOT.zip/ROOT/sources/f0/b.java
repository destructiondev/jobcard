package f0;

import java.util.Objects;
import x.i;
import x.p;

final class b extends k {

    /* renamed from: a  reason: collision with root package name */
    private final long f1982a;

    /* renamed from: b  reason: collision with root package name */
    private final p f1983b;

    /* renamed from: c  reason: collision with root package name */
    private final i f1984c;

    b(long j4, p pVar, i iVar) {
        this.f1982a = j4;
        Objects.requireNonNull(pVar, "Null transportContext");
        this.f1983b = pVar;
        Objects.requireNonNull(iVar, "Null event");
        this.f1984c = iVar;
    }

    public i b() {
        return this.f1984c;
    }

    public long c() {
        return this.f1982a;
    }

    public p d() {
        return this.f1983b;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof k)) {
            return false;
        }
        k kVar = (k) obj;
        return this.f1982a == kVar.c() && this.f1983b.equals(kVar.d()) && this.f1984c.equals(kVar.b());
    }

    public int hashCode() {
        long j4 = this.f1982a;
        return this.f1984c.hashCode() ^ ((((((int) (j4 ^ (j4 >>> 32))) ^ 1000003) * 1000003) ^ this.f1983b.hashCode()) * 1000003);
    }

    public String toString() {
        return "PersistedEvent{id=" + this.f1982a + ", transportContext=" + this.f1983b + ", event=" + this.f1984c + "}";
    }
}
