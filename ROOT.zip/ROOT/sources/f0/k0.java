package f0;

import a0.a;
import android.database.sqlite.SQLiteDatabase;
import f0.m0;
import java.util.Map;

public final /* synthetic */ class k0 implements m0.b {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ m0 f2003a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ String f2004b;

    /* renamed from: c  reason: collision with root package name */
    public final /* synthetic */ Map f2005c;

    /* renamed from: d  reason: collision with root package name */
    public final /* synthetic */ a.C0000a f2006d;

    public /* synthetic */ k0(m0 m0Var, String str, Map map, a.C0000a aVar) {
        this.f2003a = m0Var;
        this.f2004b = str;
        this.f2005c = map;
        this.f2006d = aVar;
    }

    public final Object a(Object obj) {
        return this.f2003a.n0(this.f2004b, this.f2005c, this.f2006d, (SQLiteDatabase) obj);
    }
}
