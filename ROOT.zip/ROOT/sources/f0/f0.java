package f0;

import android.database.Cursor;
import f0.m0;

public final /* synthetic */ class f0 implements m0.b {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ m0 f1991a;

    public /* synthetic */ f0(m0 m0Var) {
        this.f1991a = m0Var;
    }

    public final Object a(Object obj) {
        return this.f1991a.Z((Cursor) obj);
    }
}
