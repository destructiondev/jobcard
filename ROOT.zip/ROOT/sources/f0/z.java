package f0;

import android.database.sqlite.SQLiteDatabase;
import f0.m0;

public final /* synthetic */ class z implements m0.b {

    /* renamed from: a  reason: collision with root package name */
    public static final /* synthetic */ z f2063a = new z();

    private /* synthetic */ z() {
    }

    public final Object a(Object obj) {
        return m0.j0((SQLiteDatabase) obj);
    }
}
