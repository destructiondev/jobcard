package f0;

import android.content.Context;

public abstract class f {
    static String a() {
        return "com.google.android.datatransport.events";
    }

    static String b(Context context) {
        return context.getPackageName();
    }

    static int c() {
        return t0.f2046g;
    }

    static e d() {
        return e.f1988a;
    }
}
