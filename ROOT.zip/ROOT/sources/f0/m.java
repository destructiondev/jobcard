package f0;

import a0.a;
import android.database.Cursor;
import f0.m0;
import java.util.Map;

public final /* synthetic */ class m implements m0.b {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ m0 f2011a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ Map f2012b;

    /* renamed from: c  reason: collision with root package name */
    public final /* synthetic */ a.C0000a f2013c;

    public /* synthetic */ m(m0 m0Var, Map map, a.C0000a aVar) {
        this.f2011a = m0Var;
        this.f2012b = map;
        this.f2013c = aVar;
    }

    public final Object a(Object obj) {
        return this.f2011a.m0(this.f2012b, this.f2013c, (Cursor) obj);
    }
}
