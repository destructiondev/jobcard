package j3;

import a3.c;

public interface p<P1, P2, R> extends c<R> {
    R invoke(P1 p12, P2 p22);
}
