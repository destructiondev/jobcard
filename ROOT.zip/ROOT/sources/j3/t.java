package j3;

import a3.c;

public interface t<P1, P2, P3, P4, P5, P6, R> extends c<R> {
}
