package j3;

import a3.c;

public interface q<P1, P2, P3, R> extends c<R> {
    R i(P1 p12, P2 p22, P3 p32);
}
