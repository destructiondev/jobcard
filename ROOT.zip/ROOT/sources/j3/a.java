package j3;

import a3.c;

public interface a<R> extends c<R> {
    R invoke();
}
