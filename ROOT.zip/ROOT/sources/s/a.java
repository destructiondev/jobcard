package s;

public interface a {
}
