package x3;

import a3.m;
import a3.n;
import c3.d;
import java.util.concurrent.CancellationException;
import kotlin.coroutines.jvm.internal.h;
import p0.e;
import p0.j;
import s3.m;

public final class b {

    static final class a<TResult> implements e {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ m<T> f4936a;

        a(m<? super T> mVar) {
            this.f4936a = mVar;
        }

        public final void a(j<T> jVar) {
            Exception i4 = jVar.i();
            if (i4 != null) {
                m<T> mVar = this.f4936a;
                m.a aVar = a3.m.f265d;
                mVar.resumeWith(a3.m.a(n.a(i4)));
            } else if (jVar.k()) {
                m.a.a(this.f4936a, (Throwable) null, 1, (Object) null);
            } else {
                s3.m<T> mVar2 = this.f4936a;
                m.a aVar2 = a3.m.f265d;
                mVar2.resumeWith(a3.m.a(jVar.j()));
            }
        }
    }

    public static final <T> Object a(j<T> jVar, d<? super T> dVar) {
        return b(jVar, (p0.a) null, dVar);
    }

    private static final <T> Object b(j<T> jVar, p0.a aVar, d<? super T> dVar) {
        if (jVar.l()) {
            Exception i4 = jVar.i();
            if (i4 != null) {
                throw i4;
            } else if (!jVar.k()) {
                return jVar.j();
            } else {
                throw new CancellationException("Task " + jVar + " was cancelled normally.");
            }
        } else {
            s3.n nVar = new s3.n(c.b(dVar), 1);
            nVar.z();
            jVar.b(a.f4935d, new a(nVar));
            Object s4 = nVar.s();
            if (s4 == d.c()) {
                h.c(dVar);
            }
            return s4;
        }
    }
}
