package x3;

import java.util.concurrent.Executor;

final class a implements Executor {

    /* renamed from: d  reason: collision with root package name */
    public static final a f4935d = new a();

    private a() {
    }

    public void execute(Runnable runnable) {
        runnable.run();
    }
}
