package b;

import android.content.ClipData;
import android.content.Intent;
import android.net.Uri;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import kotlin.jvm.internal.e;
import kotlin.jvm.internal.i;

public class b extends a<String, List<Uri>> {

    /* renamed from: a  reason: collision with root package name */
    public static final a f1124a = new a((e) null);

    public static final class a {
        private a() {
        }

        public /* synthetic */ a(e eVar) {
            this();
        }

        public final List<Uri> a(Intent intent) {
            i.e(intent, "<this>");
            LinkedHashSet linkedHashSet = new LinkedHashSet();
            Uri data = intent.getData();
            if (data != null) {
                linkedHashSet.add(data);
            }
            ClipData clipData = intent.getClipData();
            if (clipData == null && linkedHashSet.isEmpty()) {
                return m.b();
            }
            if (clipData != null) {
                int itemCount = clipData.getItemCount();
                for (int i4 = 0; i4 < itemCount; i4++) {
                    Uri uri = clipData.getItemAt(i4).getUri();
                    if (uri != null) {
                        linkedHashSet.add(uri);
                    }
                }
            }
            return new ArrayList(linkedHashSet);
        }
    }
}
