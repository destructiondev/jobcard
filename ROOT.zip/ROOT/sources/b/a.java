package b;

import android.content.Intent;

public abstract class a<I, O> {
    public abstract O a(int i4, Intent intent);
}
