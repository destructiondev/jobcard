package b;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.provider.MediaStore;
import androidx.activity.result.d;
import b.d;
import java.util.List;
import kotlin.jvm.internal.e;
import kotlin.jvm.internal.i;

public class c extends a<d, List<Uri>> {

    /* renamed from: b  reason: collision with root package name */
    public static final a f1125b = new a((e) null);

    /* renamed from: a  reason: collision with root package name */
    private final int f1126a;

    public static final class a {
        private a() {
        }

        public /* synthetic */ a(e eVar) {
            this();
        }

        public final int a() {
            if (d.f1127a.f()) {
                return MediaStore.getPickImagesMaxLimit();
            }
            return Integer.MAX_VALUE;
        }
    }

    public c() {
        this(0, 1, (e) null);
    }

    public c(int i4) {
        this.f1126a = i4;
        if (!(i4 <= 1 ? false : true)) {
            throw new IllegalArgumentException("Max items must be higher than 1".toString());
        }
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public /* synthetic */ c(int i4, int i5, e eVar) {
        this((i5 & 1) != 0 ? f1125b.a() : i4);
    }

    public Intent b(Context context, d dVar) {
        i.e(context, "context");
        i.e(dVar, "input");
        d.a aVar = d.f1127a;
        boolean z3 = true;
        if (aVar.f()) {
            Intent intent = new Intent("android.provider.action.PICK_IMAGES");
            intent.setType(aVar.c(dVar.a()));
            if (this.f1126a > MediaStore.getPickImagesMaxLimit()) {
                z3 = false;
            }
            if (z3) {
                intent.putExtra("android.provider.extra.PICK_IMAGES_MAX", this.f1126a);
                return intent;
            }
            throw new IllegalArgumentException("Max items must be less or equals MediaStore.getPickImagesMaxLimit()".toString());
        } else if (aVar.e(context)) {
            ResolveInfo b4 = aVar.b(context);
            if (b4 != null) {
                ActivityInfo activityInfo = b4.activityInfo;
                Intent intent2 = new Intent("androidx.activity.result.contract.action.PICK_IMAGES");
                intent2.setClassName(activityInfo.applicationInfo.packageName, activityInfo.name);
                intent2.setType(aVar.c(dVar.a()));
                intent2.putExtra("com.google.android.gms.provider.extra.PICK_IMAGES_MAX", this.f1126a);
                return intent2;
            }
            throw new IllegalStateException("Required value was null.".toString());
        } else if (aVar.d(context)) {
            ResolveInfo a4 = aVar.a(context);
            if (a4 != null) {
                ActivityInfo activityInfo2 = a4.activityInfo;
                Intent intent3 = new Intent("com.google.android.gms.provider.action.PICK_IMAGES");
                intent3.setClassName(activityInfo2.applicationInfo.packageName, activityInfo2.name);
                intent3.putExtra("com.google.android.gms.provider.extra.PICK_IMAGES_MAX", this.f1126a);
                return intent3;
            }
            throw new IllegalStateException("Required value was null.".toString());
        } else {
            Intent intent4 = new Intent("android.intent.action.OPEN_DOCUMENT");
            intent4.setType(aVar.c(dVar.a()));
            intent4.putExtra("android.intent.extra.ALLOW_MULTIPLE", true);
            if (intent4.getType() != null) {
                return intent4;
            }
            intent4.setType("*/*");
            intent4.putExtra("android.intent.extra.MIME_TYPES", new String[]{"image/*", "video/*"});
            return intent4;
        }
    }

    /* renamed from: c */
    public final List<Uri> a(int i4, Intent intent) {
        List<Uri> a4;
        if (!(i4 == -1)) {
            intent = null;
        }
        return (intent == null || (a4 = b.f1124a.a(intent)) == null) ? m.b() : a4;
    }
}
