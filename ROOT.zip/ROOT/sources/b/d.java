package b;

import a3.k;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.os.Build;
import android.os.ext.SdkExtensions;
import kotlin.jvm.internal.i;

public class d extends a<androidx.activity.result.d, Uri> {

    /* renamed from: a  reason: collision with root package name */
    public static final a f1127a = new a((kotlin.jvm.internal.e) null);

    public static final class a {
        private a() {
        }

        public /* synthetic */ a(kotlin.jvm.internal.e eVar) {
            this();
        }

        public final ResolveInfo a(Context context) {
            i.e(context, "context");
            return context.getPackageManager().resolveActivity(new Intent("com.google.android.gms.provider.action.PICK_IMAGES"), 1114112);
        }

        public final ResolveInfo b(Context context) {
            i.e(context, "context");
            return context.getPackageManager().resolveActivity(new Intent("androidx.activity.result.contract.action.PICK_IMAGES"), 1114112);
        }

        public final String c(f fVar) {
            i.e(fVar, "input");
            if (fVar instanceof c) {
                return "image/*";
            }
            if (fVar instanceof e) {
                return "video/*";
            }
            if (fVar instanceof C0030d) {
                return ((C0030d) fVar).a();
            }
            if (fVar instanceof b) {
                return null;
            }
            throw new k();
        }

        public final boolean d(Context context) {
            i.e(context, "context");
            return a(context) != null;
        }

        public final boolean e(Context context) {
            i.e(context, "context");
            return b(context) != null;
        }

        public final boolean f() {
            int i4 = Build.VERSION.SDK_INT;
            return i4 >= 33 || (i4 >= 30 && SdkExtensions.getExtensionVersion(30) >= 2);
        }
    }

    public static final class b implements f {

        /* renamed from: a  reason: collision with root package name */
        public static final b f1128a = new b();

        private b() {
        }
    }

    public static final class c implements f {

        /* renamed from: a  reason: collision with root package name */
        public static final c f1129a = new c();

        private c() {
        }
    }

    /* renamed from: b.d$d  reason: collision with other inner class name */
    public static final class C0030d implements f {

        /* renamed from: a  reason: collision with root package name */
        private final String f1130a;

        public final String a() {
            return this.f1130a;
        }
    }

    public static final class e implements f {

        /* renamed from: a  reason: collision with root package name */
        public static final e f1131a = new e();

        private e() {
        }
    }

    public interface f {
    }

    public Intent b(Context context, androidx.activity.result.d dVar) {
        ActivityInfo activityInfo;
        Intent intent;
        i.e(context, "context");
        i.e(dVar, "input");
        a aVar = f1127a;
        if (aVar.f()) {
            Intent intent2 = new Intent("android.provider.action.PICK_IMAGES");
            intent2.setType(aVar.c(dVar.a()));
            return intent2;
        }
        if (aVar.e(context)) {
            ResolveInfo b4 = aVar.b(context);
            if (b4 != null) {
                activityInfo = b4.activityInfo;
                intent = new Intent("androidx.activity.result.contract.action.PICK_IMAGES");
            } else {
                throw new IllegalStateException("Required value was null.".toString());
            }
        } else if (aVar.d(context)) {
            ResolveInfo a4 = aVar.a(context);
            if (a4 != null) {
                activityInfo = a4.activityInfo;
                intent = new Intent("com.google.android.gms.provider.action.PICK_IMAGES");
            } else {
                throw new IllegalStateException("Required value was null.".toString());
            }
        } else {
            Intent intent3 = new Intent("android.intent.action.OPEN_DOCUMENT");
            intent3.setType(aVar.c(dVar.a()));
            if (intent3.getType() != null) {
                return intent3;
            }
            intent3.setType("*/*");
            intent3.putExtra("android.intent.extra.MIME_TYPES", new String[]{"image/*", "video/*"});
            return intent3;
        }
        intent.setClassName(activityInfo.applicationInfo.packageName, activityInfo.name);
        intent.setType(aVar.c(dVar.a()));
        return intent;
    }

    /* renamed from: c */
    public final Uri a(int i4, Intent intent) {
        if (!(i4 == -1)) {
            intent = null;
        }
        if (intent == null) {
            return null;
        }
        Uri data = intent.getData();
        if (data == null) {
            data = (Uri) u.i(b.f1124a.a(intent));
        }
        return data;
    }
}
