package s0;

import android.os.Bundle;

public interface a {

    /* renamed from: s0.a$a  reason: collision with other inner class name */
    public interface C0103a {
    }

    public interface b {
    }

    C0103a a(String str, b bVar);

    void b(String str, String str2, Bundle bundle);
}
