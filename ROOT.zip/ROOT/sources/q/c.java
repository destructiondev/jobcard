package q;

public final class c extends RuntimeException {
    public c(String str) {
        super(str);
    }

    public c(Throwable th) {
        super(th);
    }
}
