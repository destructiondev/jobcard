package q;

public final class b {

    /* renamed from: a */
    public static final int androidx_startup = 2131427328;
}
