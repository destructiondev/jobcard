package q;

import android.content.Context;
import java.util.List;

public interface a<T> {
    List<Class<? extends a<?>>> a();

    T b(Context context);
}
