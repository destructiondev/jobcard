package kotlinx.coroutines.scheduling;

import a3.s;
import java.io.Closeable;
import java.util.ArrayList;
import java.util.concurrent.Executor;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
import java.util.concurrent.atomic.AtomicLongFieldUpdater;
import java.util.concurrent.locks.LockSupport;
import kotlin.jvm.internal.e;
import kotlin.jvm.internal.i;
import kotlinx.coroutines.internal.b0;
import kotlinx.coroutines.internal.y;
import s3.p0;

public final class a implements Executor, Closeable {

    /* renamed from: k  reason: collision with root package name */
    public static final C0085a f3565k = new C0085a((e) null);

    /* renamed from: l  reason: collision with root package name */
    private static final /* synthetic */ AtomicLongFieldUpdater f3566l = AtomicLongFieldUpdater.newUpdater(a.class, "parkedWorkersStack");

    /* renamed from: m  reason: collision with root package name */
    static final /* synthetic */ AtomicLongFieldUpdater f3567m = AtomicLongFieldUpdater.newUpdater(a.class, "controlState");

    /* renamed from: n  reason: collision with root package name */
    private static final /* synthetic */ AtomicIntegerFieldUpdater f3568n = AtomicIntegerFieldUpdater.newUpdater(a.class, "_isTerminated");

    /* renamed from: o  reason: collision with root package name */
    public static final b0 f3569o = new b0("NOT_IN_STACK");
    private volatile /* synthetic */ int _isTerminated;
    volatile /* synthetic */ long controlState;

    /* renamed from: d  reason: collision with root package name */
    public final int f3570d;

    /* renamed from: e  reason: collision with root package name */
    public final int f3571e;

    /* renamed from: f  reason: collision with root package name */
    public final long f3572f;

    /* renamed from: g  reason: collision with root package name */
    public final String f3573g;

    /* renamed from: h  reason: collision with root package name */
    public final d f3574h;

    /* renamed from: i  reason: collision with root package name */
    public final d f3575i;

    /* renamed from: j  reason: collision with root package name */
    public final y<c> f3576j;
    private volatile /* synthetic */ long parkedWorkersStack;

    /* renamed from: kotlinx.coroutines.scheduling.a$a  reason: collision with other inner class name */
    public static final class C0085a {
        private C0085a() {
        }

        public /* synthetic */ C0085a(e eVar) {
            this();
        }
    }

    public /* synthetic */ class b {

        /* renamed from: a  reason: collision with root package name */
        public static final /* synthetic */ int[] f3577a;

        static {
            int[] iArr = new int[d.values().length];
            iArr[d.PARKING.ordinal()] = 1;
            iArr[d.BLOCKING.ordinal()] = 2;
            iArr[d.CPU_ACQUIRED.ordinal()] = 3;
            iArr[d.DORMANT.ordinal()] = 4;
            iArr[d.TERMINATED.ordinal()] = 5;
            f3577a = iArr;
        }
    }

    public final class c extends Thread {

        /* renamed from: k  reason: collision with root package name */
        static final /* synthetic */ AtomicIntegerFieldUpdater f3578k = AtomicIntegerFieldUpdater.newUpdater(c.class, "workerCtl");

        /* renamed from: d  reason: collision with root package name */
        public final n f3579d;

        /* renamed from: e  reason: collision with root package name */
        public d f3580e;

        /* renamed from: f  reason: collision with root package name */
        private long f3581f;

        /* renamed from: g  reason: collision with root package name */
        private long f3582g;

        /* renamed from: h  reason: collision with root package name */
        private int f3583h;

        /* renamed from: i  reason: collision with root package name */
        public boolean f3584i;
        private volatile int indexInArray;
        private volatile Object nextParkedWorker;
        volatile /* synthetic */ int workerCtl;

        private c() {
            setDaemon(true);
            this.f3579d = new n();
            this.f3580e = d.DORMANT;
            this.workerCtl = 0;
            this.nextParkedWorker = a.f3569o;
            this.f3583h = l3.c.f3666d.b();
        }

        public c(a aVar, int i4) {
            this();
            o(i4);
        }

        private final void b(int i4) {
            if (i4 != 0) {
                a.f3567m.addAndGet(a.this, -2097152);
                if (this.f3580e != d.TERMINATED) {
                    this.f3580e = d.DORMANT;
                }
            }
        }

        private final void c(int i4) {
            if (i4 != 0 && s(d.BLOCKING)) {
                a.this.s();
            }
        }

        private final void d(h hVar) {
            int a4 = hVar.f3602e.a();
            i(a4);
            c(a4);
            a.this.p(hVar);
            b(a4);
        }

        private final h e(boolean z3) {
            h m4;
            h m5;
            if (z3) {
                boolean z4 = k(a.this.f3570d * 2) == 0;
                if (z4 && (m5 = m()) != null) {
                    return m5;
                }
                h h4 = this.f3579d.h();
                if (h4 != null) {
                    return h4;
                }
                if (!z4 && (m4 = m()) != null) {
                    return m4;
                }
            } else {
                h m6 = m();
                if (m6 != null) {
                    return m6;
                }
            }
            return t(false);
        }

        private final void i(int i4) {
            this.f3581f = 0;
            if (this.f3580e == d.PARKING) {
                this.f3580e = d.BLOCKING;
            }
        }

        private final boolean j() {
            return this.nextParkedWorker != a.f3569o;
        }

        private final void l() {
            if (this.f3581f == 0) {
                this.f3581f = System.nanoTime() + a.this.f3572f;
            }
            LockSupport.parkNanos(a.this.f3572f);
            if (System.nanoTime() - this.f3581f >= 0) {
                this.f3581f = 0;
                u();
            }
        }

        private final h m() {
            d dVar;
            if (k(2) == 0) {
                h hVar = (h) a.this.f3574h.d();
                if (hVar != null) {
                    return hVar;
                }
                dVar = a.this.f3575i;
            } else {
                h hVar2 = (h) a.this.f3575i.d();
                if (hVar2 != null) {
                    return hVar2;
                }
                dVar = a.this.f3574h;
            }
            return (h) dVar.d();
        }

        private final void n() {
            loop0:
            while (true) {
                boolean z3 = false;
                while (!a.this.isTerminated() && this.f3580e != d.TERMINATED) {
                    h f4 = f(this.f3584i);
                    if (f4 != null) {
                        this.f3582g = 0;
                        d(f4);
                    } else {
                        this.f3584i = false;
                        if (this.f3582g == 0) {
                            r();
                        } else if (!z3) {
                            z3 = true;
                        } else {
                            s(d.PARKING);
                            Thread.interrupted();
                            LockSupport.parkNanos(this.f3582g);
                            this.f3582g = 0;
                        }
                    }
                }
            }
            s(d.TERMINATED);
        }

        private final boolean q() {
            boolean z3;
            if (this.f3580e != d.CPU_ACQUIRED) {
                a aVar = a.this;
                while (true) {
                    long j4 = aVar.controlState;
                    if (((int) ((9223367638808264704L & j4) >> 42)) != 0) {
                        if (a.f3567m.compareAndSet(aVar, j4, j4 - 4398046511104L)) {
                            z3 = true;
                            break;
                        }
                    } else {
                        z3 = false;
                        break;
                    }
                }
                if (!z3) {
                    return false;
                }
                this.f3580e = d.CPU_ACQUIRED;
            }
            return true;
        }

        private final void r() {
            if (!j()) {
                a.this.m(this);
                return;
            }
            this.workerCtl = -1;
            while (j() && this.workerCtl == -1 && !a.this.isTerminated() && this.f3580e != d.TERMINATED) {
                s(d.PARKING);
                Thread.interrupted();
                l();
            }
        }

        private final h t(boolean z3) {
            int i4 = (int) (a.this.controlState & 2097151);
            if (i4 < 2) {
                return null;
            }
            int k4 = k(i4);
            a aVar = a.this;
            long j4 = Long.MAX_VALUE;
            for (int i5 = 0; i5 < i4; i5++) {
                k4++;
                if (k4 > i4) {
                    k4 = 1;
                }
                c b4 = aVar.f3576j.b(k4);
                if (!(b4 == null || b4 == this)) {
                    n nVar = this.f3579d;
                    n nVar2 = b4.f3579d;
                    long k5 = z3 ? nVar.k(nVar2) : nVar.l(nVar2);
                    if (k5 == -1) {
                        return this.f3579d.h();
                    }
                    if (k5 > 0) {
                        j4 = Math.min(j4, k5);
                    }
                }
            }
            if (j4 == Long.MAX_VALUE) {
                j4 = 0;
            }
            this.f3582g = j4;
            return null;
        }

        private final void u() {
            a aVar = a.this;
            synchronized (aVar.f3576j) {
                if (!aVar.isTerminated()) {
                    if (((int) (aVar.controlState & 2097151)) > aVar.f3570d) {
                        if (f3578k.compareAndSet(this, -1, 1)) {
                            int i4 = this.indexInArray;
                            o(0);
                            aVar.o(this, i4, 0);
                            int andDecrement = (int) (a.f3567m.getAndDecrement(aVar) & 2097151);
                            if (andDecrement != i4) {
                                c b4 = aVar.f3576j.b(andDecrement);
                                i.b(b4);
                                c cVar = b4;
                                aVar.f3576j.c(i4, cVar);
                                cVar.o(i4);
                                aVar.o(cVar, andDecrement, i4);
                            }
                            aVar.f3576j.c(andDecrement, null);
                            s sVar = s.f271a;
                            this.f3580e = d.TERMINATED;
                        }
                    }
                }
            }
        }

        public final h f(boolean z3) {
            h hVar;
            if (q()) {
                return e(z3);
            }
            if (!z3 || (hVar = this.f3579d.h()) == null) {
                hVar = (h) a.this.f3575i.d();
            }
            return hVar == null ? t(true) : hVar;
        }

        public final int g() {
            return this.indexInArray;
        }

        public final Object h() {
            return this.nextParkedWorker;
        }

        public final int k(int i4) {
            int i5 = this.f3583h;
            int i6 = i5 ^ (i5 << 13);
            int i7 = i6 ^ (i6 >> 17);
            int i8 = i7 ^ (i7 << 5);
            this.f3583h = i8;
            int i9 = i4 - 1;
            return (i9 & i4) == 0 ? i8 & i9 : (i8 & Integer.MAX_VALUE) % i4;
        }

        public final void o(int i4) {
            StringBuilder sb = new StringBuilder();
            sb.append(a.this.f3573g);
            sb.append("-worker-");
            sb.append(i4 == 0 ? "TERMINATED" : String.valueOf(i4));
            setName(sb.toString());
            this.indexInArray = i4;
        }

        public final void p(Object obj) {
            this.nextParkedWorker = obj;
        }

        public void run() {
            n();
        }

        public final boolean s(d dVar) {
            d dVar2 = this.f3580e;
            boolean z3 = dVar2 == d.CPU_ACQUIRED;
            if (z3) {
                a.f3567m.addAndGet(a.this, 4398046511104L);
            }
            if (dVar2 != dVar) {
                this.f3580e = dVar;
            }
            return z3;
        }
    }

    public enum d {
        CPU_ACQUIRED,
        BLOCKING,
        PARKING,
        DORMANT,
        TERMINATED
    }

    public a(int i4, int i5, long j4, String str) {
        this.f3570d = i4;
        this.f3571e = i5;
        this.f3572f = j4;
        this.f3573g = str;
        boolean z3 = true;
        if (i4 >= 1) {
            if (i5 >= i4) {
                if (i5 <= 2097150) {
                    if (j4 <= 0 ? false : z3) {
                        this.f3574h = new d();
                        this.f3575i = new d();
                        this.parkedWorkersStack = 0;
                        this.f3576j = new y<>(i4 + 1);
                        this.controlState = ((long) i4) << 42;
                        this._isTerminated = 0;
                        return;
                    }
                    throw new IllegalArgumentException(("Idle worker keep alive time " + j4 + " must be positive").toString());
                }
                throw new IllegalArgumentException(("Max pool size " + i5 + " should not exceed maximal supported number of threads 2097150").toString());
            }
            throw new IllegalArgumentException(("Max pool size " + i5 + " should be greater than or equals to core pool size " + i4).toString());
        }
        throw new IllegalArgumentException(("Core pool size " + i4 + " should be at least 1").toString());
    }

    private final boolean A() {
        c l4;
        do {
            l4 = l();
            if (l4 == null) {
                return false;
            }
        } while (!c.f3578k.compareAndSet(l4, -1, 0));
        LockSupport.unpark(l4);
        return true;
    }

    private final boolean a(h hVar) {
        boolean z3 = true;
        if (hVar.f3602e.a() != 1) {
            z3 = false;
        }
        return (z3 ? this.f3575i : this.f3574h).a(hVar);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:7:0x000b, code lost:
        return r1;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private final int c() {
        /*
            r10 = this;
            kotlinx.coroutines.internal.y<kotlinx.coroutines.scheduling.a$c> r0 = r10.f3576j
            monitor-enter(r0)
            boolean r1 = r10.isTerminated()     // Catch:{ all -> 0x007a }
            if (r1 == 0) goto L_0x000c
            r1 = -1
        L_0x000a:
            monitor-exit(r0)
            return r1
        L_0x000c:
            long r1 = r10.controlState     // Catch:{ all -> 0x007a }
            r3 = 2097151(0x1fffff, double:1.0361303E-317)
            long r5 = r1 & r3
            int r6 = (int) r5     // Catch:{ all -> 0x007a }
            r7 = 4398044413952(0x3ffffe00000, double:2.1729226538177E-311)
            long r1 = r1 & r7
            r5 = 21
            long r1 = r1 >> r5
            int r2 = (int) r1     // Catch:{ all -> 0x007a }
            int r1 = r6 - r2
            r2 = 0
            int r1 = n3.i.a(r1, r2)     // Catch:{ all -> 0x007a }
            int r5 = r10.f3570d     // Catch:{ all -> 0x007a }
            if (r1 < r5) goto L_0x002b
            monitor-exit(r0)
            return r2
        L_0x002b:
            int r5 = r10.f3571e     // Catch:{ all -> 0x007a }
            if (r6 < r5) goto L_0x0031
            monitor-exit(r0)
            return r2
        L_0x0031:
            long r5 = r10.controlState     // Catch:{ all -> 0x007a }
            long r5 = r5 & r3
            int r6 = (int) r5     // Catch:{ all -> 0x007a }
            r5 = 1
            int r6 = r6 + r5
            if (r6 <= 0) goto L_0x0043
            kotlinx.coroutines.internal.y<kotlinx.coroutines.scheduling.a$c> r7 = r10.f3576j     // Catch:{ all -> 0x007a }
            java.lang.Object r7 = r7.b(r6)     // Catch:{ all -> 0x007a }
            if (r7 != 0) goto L_0x0043
            r7 = 1
            goto L_0x0044
        L_0x0043:
            r7 = 0
        L_0x0044:
            if (r7 == 0) goto L_0x006e
            kotlinx.coroutines.scheduling.a$c r7 = new kotlinx.coroutines.scheduling.a$c     // Catch:{ all -> 0x007a }
            r7.<init>(r10, r6)     // Catch:{ all -> 0x007a }
            kotlinx.coroutines.internal.y<kotlinx.coroutines.scheduling.a$c> r8 = r10.f3576j     // Catch:{ all -> 0x007a }
            r8.c(r6, r7)     // Catch:{ all -> 0x007a }
            java.util.concurrent.atomic.AtomicLongFieldUpdater r8 = f3567m     // Catch:{ all -> 0x007a }
            long r8 = r8.incrementAndGet(r10)     // Catch:{ all -> 0x007a }
            long r3 = r3 & r8
            int r4 = (int) r3     // Catch:{ all -> 0x007a }
            if (r6 != r4) goto L_0x005b
            r2 = 1
        L_0x005b:
            if (r2 == 0) goto L_0x0062
            r7.start()     // Catch:{ all -> 0x007a }
            int r1 = r1 + r5
            goto L_0x000a
        L_0x0062:
            java.lang.String r1 = "Failed requirement."
            java.lang.IllegalArgumentException r2 = new java.lang.IllegalArgumentException     // Catch:{ all -> 0x007a }
            java.lang.String r1 = r1.toString()     // Catch:{ all -> 0x007a }
            r2.<init>(r1)     // Catch:{ all -> 0x007a }
            throw r2     // Catch:{ all -> 0x007a }
        L_0x006e:
            java.lang.String r1 = "Failed requirement."
            java.lang.IllegalArgumentException r2 = new java.lang.IllegalArgumentException     // Catch:{ all -> 0x007a }
            java.lang.String r1 = r1.toString()     // Catch:{ all -> 0x007a }
            r2.<init>(r1)     // Catch:{ all -> 0x007a }
            throw r2     // Catch:{ all -> 0x007a }
        L_0x007a:
            r1 = move-exception
            monitor-exit(r0)
            throw r1
        */
        throw new UnsupportedOperationException("Method not decompiled: kotlinx.coroutines.scheduling.a.c():int");
    }

    private final c e() {
        Thread currentThread = Thread.currentThread();
        c cVar = currentThread instanceof c ? (c) currentThread : null;
        if (cVar == null || !i.a(a.this, this)) {
            return null;
        }
        return cVar;
    }

    public static /* synthetic */ void j(a aVar, Runnable runnable, i iVar, boolean z3, int i4, Object obj) {
        if ((i4 & 2) != 0) {
            iVar = l.f3610f;
        }
        if ((i4 & 4) != 0) {
            z3 = false;
        }
        aVar.h(runnable, iVar, z3);
    }

    private final int k(c cVar) {
        int g4;
        do {
            Object h4 = cVar.h();
            if (h4 == f3569o) {
                return -1;
            }
            if (h4 == null) {
                return 0;
            }
            cVar = (c) h4;
            g4 = cVar.g();
        } while (g4 == 0);
        return g4;
    }

    private final c l() {
        while (true) {
            long j4 = this.parkedWorkersStack;
            c b4 = this.f3576j.b((int) (2097151 & j4));
            if (b4 == null) {
                return null;
            }
            long j5 = (2097152 + j4) & -2097152;
            int k4 = k(b4);
            if (k4 >= 0) {
                if (f3566l.compareAndSet(this, j4, ((long) k4) | j5)) {
                    b4.p(f3569o);
                    return b4;
                }
            }
        }
    }

    private final void r(boolean z3) {
        long addAndGet = f3567m.addAndGet(this, 2097152);
        if (!z3 && !A() && !y(addAndGet)) {
            A();
        }
    }

    private final h t(c cVar, h hVar, boolean z3) {
        if (cVar == null || cVar.f3580e == d.TERMINATED) {
            return hVar;
        }
        if (hVar.f3602e.a() == 0 && cVar.f3580e == d.BLOCKING) {
            return hVar;
        }
        cVar.f3584i = true;
        return cVar.f3579d.a(hVar, z3);
    }

    private final boolean y(long j4) {
        if (i.a(((int) (2097151 & j4)) - ((int) ((j4 & 4398044413952L) >> 21)), 0) < this.f3570d) {
            int c4 = c();
            if (c4 == 1 && this.f3570d > 1) {
                c();
            }
            if (c4 > 0) {
                return true;
            }
        }
        return false;
    }

    static /* synthetic */ boolean z(a aVar, long j4, int i4, Object obj) {
        if ((i4 & 1) != 0) {
            j4 = aVar.controlState;
        }
        return aVar.y(j4);
    }

    public void close() {
        q(10000);
    }

    public final h d(Runnable runnable, i iVar) {
        long a4 = l.f3609e.a();
        if (!(runnable instanceof h)) {
            return new k(runnable, a4, iVar);
        }
        h hVar = (h) runnable;
        hVar.f3601d = a4;
        hVar.f3602e = iVar;
        return hVar;
    }

    public void execute(Runnable runnable) {
        j(this, runnable, (i) null, false, 6, (Object) null);
    }

    public final void h(Runnable runnable, i iVar, boolean z3) {
        s3.c.a();
        h d4 = d(runnable, iVar);
        c e4 = e();
        h t4 = t(e4, d4, z3);
        if (t4 == null || a(t4)) {
            boolean z4 = z3 && e4 != null;
            if (d4.f3602e.a() != 0) {
                r(z4);
            } else if (!z4) {
                s();
            }
        } else {
            throw new RejectedExecutionException(this.f3573g + " was terminated");
        }
    }

    /* JADX WARNING: type inference failed for: r0v0, types: [boolean, int] */
    public final boolean isTerminated() {
        return this._isTerminated;
    }

    public final boolean m(c cVar) {
        long j4;
        int g4;
        if (cVar.h() != f3569o) {
            return false;
        }
        do {
            j4 = this.parkedWorkersStack;
            g4 = cVar.g();
            cVar.p(this.f3576j.b((int) (2097151 & j4)));
        } while (!f3566l.compareAndSet(this, j4, ((2097152 + j4) & -2097152) | ((long) g4)));
        return true;
    }

    public final void o(c cVar, int i4, int i5) {
        while (true) {
            long j4 = this.parkedWorkersStack;
            int i6 = (int) (2097151 & j4);
            long j5 = (2097152 + j4) & -2097152;
            if (i6 == i4) {
                i6 = i5 == 0 ? k(cVar) : i5;
            }
            if (i6 >= 0) {
                if (f3566l.compareAndSet(this, j4, j5 | ((long) i6))) {
                    return;
                }
            }
        }
    }

    public final void p(h hVar) {
        try {
            hVar.run();
        } catch (Throwable th) {
            s3.c.a();
            throw th;
        }
        s3.c.a();
    }

    public final void q(long j4) {
        int i4;
        h hVar;
        if (f3568n.compareAndSet(this, 0, 1)) {
            c e4 = e();
            synchronized (this.f3576j) {
                i4 = (int) (this.controlState & 2097151);
            }
            if (1 <= i4) {
                int i5 = 1;
                while (true) {
                    c b4 = this.f3576j.b(i5);
                    i.b(b4);
                    c cVar = b4;
                    if (cVar != e4) {
                        while (cVar.isAlive()) {
                            LockSupport.unpark(cVar);
                            cVar.join(j4);
                        }
                        cVar.f3579d.g(this.f3575i);
                    }
                    if (i5 == i4) {
                        break;
                    }
                    i5++;
                }
            }
            this.f3575i.b();
            this.f3574h.b();
            while (true) {
                if (e4 != null) {
                    hVar = e4.f(true);
                    if (hVar != null) {
                        continue;
                        p(hVar);
                    }
                }
                hVar = (h) this.f3574h.d();
                if (hVar == null && (hVar = (h) this.f3575i.d()) == null) {
                    break;
                }
                p(hVar);
            }
            if (e4 != null) {
                e4.s(d.TERMINATED);
            }
            this.parkedWorkersStack = 0;
            this.controlState = 0;
        }
    }

    public final void s() {
        if (!A() && !z(this, 0, 1, (Object) null)) {
            A();
        }
    }

    public String toString() {
        char c4;
        StringBuilder sb;
        ArrayList arrayList = new ArrayList();
        int a4 = this.f3576j.a();
        int i4 = 0;
        int i5 = 0;
        int i6 = 0;
        int i7 = 0;
        int i8 = 0;
        for (int i9 = 1; i9 < a4; i9++) {
            c b4 = this.f3576j.b(i9);
            if (b4 != null) {
                int f4 = b4.f3579d.f();
                int i10 = b.f3577a[b4.f3580e.ordinal()];
                if (i10 != 1) {
                    if (i10 == 2) {
                        i5++;
                        sb = new StringBuilder();
                        sb.append(f4);
                        c4 = 'b';
                    } else if (i10 == 3) {
                        i4++;
                        sb = new StringBuilder();
                        sb.append(f4);
                        c4 = 'c';
                    } else if (i10 == 4) {
                        i7++;
                        if (f4 > 0) {
                            sb = new StringBuilder();
                            sb.append(f4);
                            c4 = 'd';
                        }
                    } else if (i10 == 5) {
                        i8++;
                    }
                    sb.append(c4);
                    arrayList.add(sb.toString());
                } else {
                    i6++;
                }
            }
        }
        long j4 = this.controlState;
        return this.f3573g + '@' + p0.b(this) + "[Pool Size {core = " + this.f3570d + ", max = " + this.f3571e + "}, Worker States {CPU = " + i4 + ", blocking = " + i5 + ", parked = " + i6 + ", dormant = " + i7 + ", terminated = " + i8 + "}, running workers queues = " + arrayList + ", global CPU queue size = " + this.f3574h.c() + ", global blocking queue size = " + this.f3575i.c() + ", Control State {created workers= " + ((int) (2097151 & j4)) + ", blocking tasks = " + ((int) ((4398044413952L & j4) >> 21)) + ", CPUs acquired = " + (this.f3570d - ((int) ((9223367638808264704L & j4) >> 42))) + "}]";
    }
}
