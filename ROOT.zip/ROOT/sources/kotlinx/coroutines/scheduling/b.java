package kotlinx.coroutines.scheduling;

import c3.g;
import c3.h;
import java.util.concurrent.Executor;
import kotlinx.coroutines.internal.c0;
import s3.h0;
import s3.j1;

public final class b extends j1 implements Executor {

    /* renamed from: g  reason: collision with root package name */
    public static final b f3592g = new b();

    /* renamed from: h  reason: collision with root package name */
    private static final h0 f3593h = m.f3612f.K(e0.d("kotlinx.coroutines.io.parallelism", i.a(64, c0.a()), 0, 0, 12, (Object) null));

    private b() {
    }

    public void I(g gVar, Runnable runnable) {
        f3593h.I(gVar, runnable);
    }

    public void close() {
        throw new IllegalStateException("Cannot be invoked on Dispatchers.IO".toString());
    }

    public void execute(Runnable runnable) {
        I(h.f1634d, runnable);
    }

    public String toString() {
        return "Dispatchers.IO";
    }
}
