package kotlinx.coroutines.scheduling;

import c3.g;
import s3.j1;

public class f extends j1 {

    /* renamed from: g  reason: collision with root package name */
    private final int f3596g;

    /* renamed from: h  reason: collision with root package name */
    private final int f3597h;

    /* renamed from: i  reason: collision with root package name */
    private final long f3598i;

    /* renamed from: j  reason: collision with root package name */
    private final String f3599j;

    /* renamed from: k  reason: collision with root package name */
    private a f3600k = L();

    public f(int i4, int i5, long j4, String str) {
        this.f3596g = i4;
        this.f3597h = i5;
        this.f3598i = j4;
        this.f3599j = str;
    }

    private final a L() {
        return new a(this.f3596g, this.f3597h, this.f3598i, this.f3599j);
    }

    public void I(g gVar, Runnable runnable) {
        a.j(this.f3600k, runnable, (i) null, false, 6, (Object) null);
    }

    public final void M(Runnable runnable, i iVar, boolean z3) {
        this.f3600k.h(runnable, iVar, z3);
    }
}
