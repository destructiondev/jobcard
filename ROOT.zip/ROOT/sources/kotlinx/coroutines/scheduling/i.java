package kotlinx.coroutines.scheduling;

public interface i {
    int a();

    void b();
}
