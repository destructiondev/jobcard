package kotlinx.coroutines.scheduling;

public abstract class h implements Runnable {

    /* renamed from: d  reason: collision with root package name */
    public long f3601d;

    /* renamed from: e  reason: collision with root package name */
    public i f3602e;

    public h() {
        this(0, l.f3610f);
    }

    public h(long j4, i iVar) {
        this.f3601d = j4;
        this.f3602e = iVar;
    }
}
