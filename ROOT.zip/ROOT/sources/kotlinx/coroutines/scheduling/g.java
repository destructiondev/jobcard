package kotlinx.coroutines.scheduling;

public abstract class g {
    public abstract long a();
}
