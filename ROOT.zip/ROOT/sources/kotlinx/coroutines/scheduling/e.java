package kotlinx.coroutines.scheduling;

public final class e extends g {

    /* renamed from: a  reason: collision with root package name */
    public static final e f3595a = new e();

    private e() {
    }

    public long a() {
        return System.nanoTime();
    }
}
