package kotlinx.coroutines.scheduling;

import androidx.concurrent.futures.b;
import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
import java.util.concurrent.atomic.AtomicReferenceArray;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;

public final class n {

    /* renamed from: b  reason: collision with root package name */
    private static final /* synthetic */ AtomicReferenceFieldUpdater f3613b;

    /* renamed from: c  reason: collision with root package name */
    private static final /* synthetic */ AtomicIntegerFieldUpdater f3614c;

    /* renamed from: d  reason: collision with root package name */
    private static final /* synthetic */ AtomicIntegerFieldUpdater f3615d;

    /* renamed from: e  reason: collision with root package name */
    private static final /* synthetic */ AtomicIntegerFieldUpdater f3616e;

    /* renamed from: a  reason: collision with root package name */
    private final AtomicReferenceArray<h> f3617a = new AtomicReferenceArray<>(128);
    private volatile /* synthetic */ int blockingTasksInBuffer = 0;
    private volatile /* synthetic */ int consumerIndex = 0;
    private volatile /* synthetic */ Object lastScheduledTask = null;
    private volatile /* synthetic */ int producerIndex = 0;

    static {
        Class<n> cls = n.class;
        f3613b = AtomicReferenceFieldUpdater.newUpdater(cls, Object.class, "lastScheduledTask");
        f3614c = AtomicIntegerFieldUpdater.newUpdater(cls, "producerIndex");
        f3615d = AtomicIntegerFieldUpdater.newUpdater(cls, "consumerIndex");
        f3616e = AtomicIntegerFieldUpdater.newUpdater(cls, "blockingTasksInBuffer");
    }

    public static /* synthetic */ h b(n nVar, h hVar, boolean z3, int i4, Object obj) {
        if ((i4 & 2) != 0) {
            z3 = false;
        }
        return nVar.a(hVar, z3);
    }

    private final h c(h hVar) {
        boolean z3 = true;
        if (hVar.f3602e.a() != 1) {
            z3 = false;
        }
        if (z3) {
            f3616e.incrementAndGet(this);
        }
        if (e() == 127) {
            return hVar;
        }
        int i4 = this.producerIndex & 127;
        while (this.f3617a.get(i4) != null) {
            Thread.yield();
        }
        this.f3617a.lazySet(i4, hVar);
        f3614c.incrementAndGet(this);
        return null;
    }

    private final void d(h hVar) {
        if (hVar != null) {
            boolean z3 = true;
            if (hVar.f3602e.a() != 1) {
                z3 = false;
            }
            if (z3) {
                f3616e.decrementAndGet(this);
            }
        }
    }

    private final h i() {
        h andSet;
        while (true) {
            int i4 = this.consumerIndex;
            if (i4 - this.producerIndex == 0) {
                return null;
            }
            int i5 = i4 & 127;
            if (f3615d.compareAndSet(this, i4, i4 + 1) && (andSet = this.f3617a.getAndSet(i5, (Object) null)) != null) {
                d(andSet);
                return andSet;
            }
        }
    }

    private final boolean j(d dVar) {
        h i4 = i();
        if (i4 == null) {
            return false;
        }
        dVar.a(i4);
        return true;
    }

    private final long m(n nVar, boolean z3) {
        h hVar;
        do {
            hVar = (h) nVar.lastScheduledTask;
            if (hVar == null) {
                return -2;
            }
            if (z3) {
                boolean z4 = true;
                if (hVar.f3602e.a() != 1) {
                    z4 = false;
                }
                if (!z4) {
                    return -2;
                }
            }
            long a4 = l.f3609e.a() - hVar.f3601d;
            long j4 = l.f3605a;
            if (a4 < j4) {
                return j4 - a4;
            }
        } while (!b.a(f3613b, nVar, hVar, (Object) null));
        b(this, hVar, false, 2, (Object) null);
        return -1;
    }

    public final h a(h hVar, boolean z3) {
        if (z3) {
            return c(hVar);
        }
        h hVar2 = (h) f3613b.getAndSet(this, hVar);
        if (hVar2 == null) {
            return null;
        }
        return c(hVar2);
    }

    public final int e() {
        return this.producerIndex - this.consumerIndex;
    }

    public final int f() {
        return this.lastScheduledTask != null ? e() + 1 : e();
    }

    public final void g(d dVar) {
        h hVar = (h) f3613b.getAndSet(this, (Object) null);
        if (hVar != null) {
            dVar.a(hVar);
        }
        do {
        } while (j(dVar));
    }

    public final h h() {
        h hVar = (h) f3613b.getAndSet(this, (Object) null);
        return hVar == null ? i() : hVar;
    }

    public final long k(n nVar) {
        int i4 = nVar.consumerIndex;
        int i5 = nVar.producerIndex;
        AtomicReferenceArray<h> atomicReferenceArray = nVar.f3617a;
        while (true) {
            boolean z3 = true;
            if (i4 == i5) {
                break;
            }
            int i6 = i4 & 127;
            if (nVar.blockingTasksInBuffer == 0) {
                break;
            }
            h hVar = atomicReferenceArray.get(i6);
            if (hVar != null) {
                if (hVar.f3602e.a() != 1) {
                    z3 = false;
                }
                if (z3 && atomicReferenceArray.compareAndSet(i6, hVar, (Object) null)) {
                    f3616e.decrementAndGet(nVar);
                    b(this, hVar, false, 2, (Object) null);
                    return -1;
                }
            }
            i4++;
        }
        return m(nVar, true);
    }

    public final long l(n nVar) {
        h i4 = nVar.i();
        if (i4 == null) {
            return m(nVar, false);
        }
        b(this, i4, false, 2, (Object) null);
        return -1;
    }
}
