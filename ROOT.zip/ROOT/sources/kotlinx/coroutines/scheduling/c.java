package kotlinx.coroutines.scheduling;

public final class c extends f {

    /* renamed from: l  reason: collision with root package name */
    public static final c f3594l = new c();

    private c() {
        super(l.f3606b, l.f3607c, l.f3608d, "DefaultDispatcher");
    }

    public void close() {
        throw new UnsupportedOperationException("Dispatchers.Default cannot be closed");
    }

    public String toString() {
        return "Dispatchers.Default";
    }
}
