package kotlinx.coroutines.scheduling;

final class j implements i {

    /* renamed from: a  reason: collision with root package name */
    private final int f3603a;

    public j(int i4) {
        this.f3603a = i4;
    }

    public int a() {
        return this.f3603a;
    }

    public void b() {
    }
}
