package kotlinx.coroutines.scheduling;

import s3.p0;

public final class k extends h {

    /* renamed from: f  reason: collision with root package name */
    public final Runnable f3604f;

    public k(Runnable runnable, long j4, i iVar) {
        super(j4, iVar);
        this.f3604f = runnable;
    }

    public void run() {
        try {
            this.f3604f.run();
        } finally {
            this.f3602e.b();
        }
    }

    public String toString() {
        return "Task[" + p0.a(this.f3604f) + '@' + p0.b(this.f3604f) + ", " + this.f3601d + ", " + this.f3602e + ']';
    }
}
