package kotlinx.coroutines.scheduling;

import c3.g;
import s3.h0;

final class m extends h0 {

    /* renamed from: f  reason: collision with root package name */
    public static final m f3612f = new m();

    private m() {
    }

    public void I(g gVar, Runnable runnable) {
        c.f3594l.M(runnable, l.f3611g, false);
    }
}
