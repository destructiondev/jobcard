package kotlinx.coroutines.scheduling;

import kotlinx.coroutines.internal.p;

public final class d extends p<h> {
    public d() {
        super(false);
    }
}
