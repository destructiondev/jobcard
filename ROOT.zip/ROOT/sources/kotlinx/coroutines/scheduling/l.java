package kotlinx.coroutines.scheduling;

import java.util.concurrent.TimeUnit;
import kotlinx.coroutines.internal.c0;

public final class l {

    /* renamed from: a  reason: collision with root package name */
    public static final long f3605a = e0.e("kotlinx.coroutines.scheduler.resolution.ns", 100000, 0, 0, 12, (Object) null);

    /* renamed from: b  reason: collision with root package name */
    public static final int f3606b = e0.d("kotlinx.coroutines.scheduler.core.pool.size", i.a(c0.a(), 2), 1, 0, 8, (Object) null);

    /* renamed from: c  reason: collision with root package name */
    public static final int f3607c = e0.d("kotlinx.coroutines.scheduler.max.pool.size", 2097150, 0, 2097150, 4, (Object) null);

    /* renamed from: d  reason: collision with root package name */
    public static final long f3608d = TimeUnit.SECONDS.toNanos(e0.e("kotlinx.coroutines.scheduler.keep.alive.sec", 60, 0, 0, 12, (Object) null));

    /* renamed from: e  reason: collision with root package name */
    public static g f3609e = e.f3595a;

    /* renamed from: f  reason: collision with root package name */
    public static final i f3610f = new j(0);

    /* renamed from: g  reason: collision with root package name */
    public static final i f3611g = new j(1);
}
