package kotlinx.coroutines.internal;

public final class n {

    /* renamed from: a  reason: collision with root package name */
    private static final Object f3537a = new b0("CONDITION_FALSE");

    /* renamed from: b  reason: collision with root package name */
    private static final Object f3538b = new b0("LIST_EMPTY");

    public static final Object a() {
        return f3537a;
    }

    public static final o b(Object obj) {
        o oVar;
        x xVar = obj instanceof x ? (x) obj : null;
        return (xVar == null || (oVar = xVar.f3563a) == null) ? (o) obj : oVar;
    }
}
