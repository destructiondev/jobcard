package kotlinx.coroutines.internal;

import androidx.concurrent.futures.b;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;

public class p<E> {

    /* renamed from: a  reason: collision with root package name */
    private static final /* synthetic */ AtomicReferenceFieldUpdater f3544a = AtomicReferenceFieldUpdater.newUpdater(p.class, Object.class, "_cur");
    private volatile /* synthetic */ Object _cur;

    public p(boolean z3) {
        this._cur = new q(8, z3);
    }

    public final boolean a(E e4) {
        while (true) {
            q qVar = (q) this._cur;
            int a4 = qVar.a(e4);
            if (a4 == 0) {
                return true;
            }
            if (a4 == 1) {
                b.a(f3544a, this, qVar, qVar.i());
            } else if (a4 == 2) {
                return false;
            }
        }
    }

    public final void b() {
        while (true) {
            q qVar = (q) this._cur;
            if (!qVar.d()) {
                b.a(f3544a, this, qVar, qVar.i());
            } else {
                return;
            }
        }
    }

    public final int c() {
        return ((q) this._cur).f();
    }

    public final E d() {
        while (true) {
            q qVar = (q) this._cur;
            E j4 = qVar.j();
            if (j4 != q.f3548h) {
                return j4;
            }
            b.a(f3544a, this, qVar, qVar.i());
        }
    }
}
