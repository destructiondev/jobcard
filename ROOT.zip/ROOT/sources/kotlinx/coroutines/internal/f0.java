package kotlinx.coroutines.internal;

import c3.g;
import j3.p;
import java.util.Objects;
import kotlin.jvm.internal.i;
import kotlin.jvm.internal.j;
import s3.n2;

public final class f0 {

    /* renamed from: a  reason: collision with root package name */
    public static final b0 f3516a = new b0("NO_THREAD_ELEMENTS");

    /* renamed from: b  reason: collision with root package name */
    private static final p<Object, g.b, Object> f3517b = a.f3520d;

    /* renamed from: c  reason: collision with root package name */
    private static final p<n2<?>, g.b, n2<?>> f3518c = b.f3521d;

    /* renamed from: d  reason: collision with root package name */
    private static final p<i0, g.b, i0> f3519d = c.f3522d;

    static final class a extends j implements p<Object, g.b, Object> {

        /* renamed from: d  reason: collision with root package name */
        public static final a f3520d = new a();

        a() {
            super(2);
        }

        /* renamed from: b */
        public final Object invoke(Object obj, g.b bVar) {
            if (!(bVar instanceof n2)) {
                return obj;
            }
            Integer num = obj instanceof Integer ? (Integer) obj : null;
            int intValue = num != null ? num.intValue() : 1;
            return intValue == 0 ? bVar : Integer.valueOf(intValue + 1);
        }
    }

    static final class b extends j implements p<n2<?>, g.b, n2<?>> {

        /* renamed from: d  reason: collision with root package name */
        public static final b f3521d = new b();

        b() {
            super(2);
        }

        /* renamed from: b */
        public final n2<?> invoke(n2<?> n2Var, g.b bVar) {
            if (n2Var != null) {
                return n2Var;
            }
            if (bVar instanceof n2) {
                return (n2) bVar;
            }
            return null;
        }
    }

    static final class c extends j implements p<i0, g.b, i0> {

        /* renamed from: d  reason: collision with root package name */
        public static final c f3522d = new c();

        c() {
            super(2);
        }

        /* renamed from: b */
        public final i0 invoke(i0 i0Var, g.b bVar) {
            if (bVar instanceof n2) {
                n2 n2Var = (n2) bVar;
                i0Var.a(n2Var, n2Var.l(i0Var.f3528a));
            }
            return i0Var;
        }
    }

    public static final void a(g gVar, Object obj) {
        if (obj != f3516a) {
            if (obj instanceof i0) {
                ((i0) obj).b(gVar);
                return;
            }
            Object A = gVar.A(null, f3518c);
            Objects.requireNonNull(A, "null cannot be cast to non-null type kotlinx.coroutines.ThreadContextElement<kotlin.Any?>");
            ((n2) A).B(gVar, obj);
        }
    }

    public static final Object b(g gVar) {
        Object A = gVar.A(0, f3517b);
        i.b(A);
        return A;
    }

    public static final Object c(g gVar, Object obj) {
        if (obj == null) {
            obj = b(gVar);
        }
        return obj == 0 ? f3516a : obj instanceof Integer ? gVar.A(new i0(gVar, ((Number) obj).intValue()), f3519d) : ((n2) obj).l(gVar);
    }
}
