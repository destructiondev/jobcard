package kotlinx.coroutines.internal;

import a3.m;
import a3.n;

public final class i {

    /* renamed from: a  reason: collision with root package name */
    private static final boolean f3527a;

    static {
        Object obj;
        try {
            m.a aVar = m.f265d;
            obj = m.a(Class.forName("android.os.Build"));
        } catch (Throwable th) {
            m.a aVar2 = m.f265d;
            obj = m.a(n.a(th));
        }
        f3527a = m.d(obj);
    }

    public static final boolean a() {
        return f3527a;
    }
}
