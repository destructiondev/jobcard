package kotlinx.coroutines.internal;

import c3.g;
import s3.h0;
import s3.r0;
import s3.t0;

public final class k extends h0 implements Runnable, t0 {

    /* renamed from: f  reason: collision with root package name */
    private final h0 f3532f;

    /* renamed from: g  reason: collision with root package name */
    private final int f3533g;

    /* renamed from: h  reason: collision with root package name */
    private final /* synthetic */ t0 f3534h;

    /* renamed from: i  reason: collision with root package name */
    private final p<Runnable> f3535i;

    /* renamed from: j  reason: collision with root package name */
    private final Object f3536j;
    private volatile int runningWorkers;

    public k(h0 h0Var, int i4) {
        this.f3532f = h0Var;
        this.f3533g = i4;
        t0 t0Var = h0Var instanceof t0 ? (t0) h0Var : null;
        this.f3534h = t0Var == null ? r0.a() : t0Var;
        this.f3535i = new p<>(false);
        this.f3536j = new Object();
    }

    private final boolean L(Runnable runnable) {
        this.f3535i.a(runnable);
        return this.runningWorkers >= this.f3533g;
    }

    private final boolean M() {
        synchronized (this.f3536j) {
            if (this.runningWorkers >= this.f3533g) {
                return false;
            }
            this.runningWorkers++;
            return true;
        }
    }

    public void I(g gVar, Runnable runnable) {
        if (!L(runnable) && M()) {
            this.f3532f.I(this, this);
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:14:0x002a, code lost:
        r1 = r4.f3536j;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:15:0x002c, code lost:
        monitor-enter(r1);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:17:?, code lost:
        r4.runningWorkers--;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:18:0x0039, code lost:
        if (r4.f3535i.c() != 0) goto L_0x003d;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:19:0x003b, code lost:
        monitor-exit(r1);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:20:0x003c, code lost:
        return;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:22:?, code lost:
        r4.runningWorkers++;
        r2 = a3.s.f271a;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void run() {
        /*
            r4 = this;
            r0 = 0
        L_0x0001:
            r1 = 0
        L_0x0002:
            kotlinx.coroutines.internal.p<java.lang.Runnable> r2 = r4.f3535i
            java.lang.Object r2 = r2.d()
            java.lang.Runnable r2 = (java.lang.Runnable) r2
            if (r2 == 0) goto L_0x002a
            r2.run()     // Catch:{ all -> 0x0010 }
            goto L_0x0016
        L_0x0010:
            r2 = move-exception
            c3.h r3 = c3.h.f1634d
            s3.k0.a(r3, r2)
        L_0x0016:
            int r1 = r1 + 1
            r2 = 16
            if (r1 < r2) goto L_0x0002
            s3.h0 r2 = r4.f3532f
            boolean r2 = r2.J(r4)
            if (r2 == 0) goto L_0x0002
            s3.h0 r0 = r4.f3532f
            r0.I(r4, r4)
            return
        L_0x002a:
            java.lang.Object r1 = r4.f3536j
            monitor-enter(r1)
            int r2 = r4.runningWorkers     // Catch:{ all -> 0x0047 }
            int r2 = r2 + -1
            r4.runningWorkers = r2     // Catch:{ all -> 0x0047 }
            kotlinx.coroutines.internal.p<java.lang.Runnable> r2 = r4.f3535i     // Catch:{ all -> 0x0047 }
            int r2 = r2.c()     // Catch:{ all -> 0x0047 }
            if (r2 != 0) goto L_0x003d
            monitor-exit(r1)
            return
        L_0x003d:
            int r2 = r4.runningWorkers     // Catch:{ all -> 0x0047 }
            int r2 = r2 + 1
            r4.runningWorkers = r2     // Catch:{ all -> 0x0047 }
            a3.s r2 = a3.s.f271a     // Catch:{ all -> 0x0047 }
            monitor-exit(r1)
            goto L_0x0001
        L_0x0047:
            r0 = move-exception
            monitor-exit(r1)
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: kotlinx.coroutines.internal.k.run():void");
    }
}
