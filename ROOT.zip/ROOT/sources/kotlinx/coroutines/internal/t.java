package kotlinx.coroutines.internal;

import a3.d;
import java.util.List;
import s3.d2;

public final class t {

    /* renamed from: a  reason: collision with root package name */
    private static final boolean f3557a = true;

    private static final u a(Throwable th, String str) {
        if (f3557a) {
            return new u(th, str);
        }
        if (th != null) {
            throw th;
        }
        d();
        throw new d();
    }

    static /* synthetic */ u b(Throwable th, String str, int i4, Object obj) {
        if ((i4 & 1) != 0) {
            th = null;
        }
        if ((i4 & 2) != 0) {
            str = null;
        }
        return a(th, str);
    }

    public static final boolean c(d2 d2Var) {
        return d2Var.L() instanceof u;
    }

    public static final Void d() {
        throw new IllegalStateException("Module with the Main dispatcher is missing. Add dependency providing the Main dispatcher, e.g. 'kotlinx-coroutines-android' and ensure it has the same version as 'kotlinx-coroutines-core'");
    }

    public static final d2 e(r rVar, List<? extends r> list) {
        try {
            return rVar.c(list);
        } catch (Throwable th) {
            return a(th, rVar.b());
        }
    }
}
