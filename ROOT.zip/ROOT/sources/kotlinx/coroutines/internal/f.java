package kotlinx.coroutines.internal;

import a3.s;
import androidx.concurrent.futures.b;
import c3.d;
import c3.g;
import j3.l;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
import kotlin.coroutines.jvm.internal.e;
import kotlin.jvm.internal.i;
import s3.b0;
import s3.d1;
import s3.e0;
import s3.h0;
import s3.m;
import s3.n;
import s3.o2;
import s3.p0;
import s3.w0;

public final class f<T> extends w0<T> implements e, d<T> {

    /* renamed from: k  reason: collision with root package name */
    private static final /* synthetic */ AtomicReferenceFieldUpdater f3511k = AtomicReferenceFieldUpdater.newUpdater(f.class, Object.class, "_reusableCancellableContinuation");
    private volatile /* synthetic */ Object _reusableCancellableContinuation = null;

    /* renamed from: g  reason: collision with root package name */
    public final h0 f3512g;

    /* renamed from: h  reason: collision with root package name */
    public final d<T> f3513h;

    /* renamed from: i  reason: collision with root package name */
    public Object f3514i = g.f3523a;

    /* renamed from: j  reason: collision with root package name */
    public final Object f3515j = f0.b(getContext());

    public f(h0 h0Var, d<? super T> dVar) {
        super(-1);
        this.f3512g = h0Var;
        this.f3513h = dVar;
    }

    private final n<?> k() {
        Object obj = this._reusableCancellableContinuation;
        if (obj instanceof n) {
            return (n) obj;
        }
        return null;
    }

    public void a(Object obj, Throwable th) {
        if (obj instanceof b0) {
            ((b0) obj).f4238b.invoke(th);
        }
    }

    public d<T> c() {
        return this;
    }

    public e getCallerFrame() {
        d<T> dVar = this.f3513h;
        if (dVar instanceof e) {
            return (e) dVar;
        }
        return null;
    }

    public g getContext() {
        return this.f3513h.getContext();
    }

    public Object h() {
        Object obj = this.f3514i;
        this.f3514i = g.f3523a;
        return obj;
    }

    public final void i() {
        do {
        } while (this._reusableCancellableContinuation == g.f3524b);
    }

    public final n<T> j() {
        while (true) {
            Object obj = this._reusableCancellableContinuation;
            if (obj == null) {
                this._reusableCancellableContinuation = g.f3524b;
                return null;
            } else if (obj instanceof n) {
                if (b.a(f3511k, this, obj, g.f3524b)) {
                    return (n) obj;
                }
            } else if (obj != g.f3524b && !(obj instanceof Throwable)) {
                throw new IllegalStateException(("Inconsistent state " + obj).toString());
            }
        }
    }

    public final boolean l() {
        return this._reusableCancellableContinuation != null;
    }

    public final boolean m(Throwable th) {
        while (true) {
            Object obj = this._reusableCancellableContinuation;
            b0 b0Var = g.f3524b;
            if (i.a(obj, b0Var)) {
                if (b.a(f3511k, this, b0Var, th)) {
                    return true;
                }
            } else if (obj instanceof Throwable) {
                return true;
            } else {
                if (b.a(f3511k, this, obj, (Object) null)) {
                    return false;
                }
            }
        }
    }

    public final void o() {
        i();
        n<?> k4 = k();
        if (k4 != null) {
            k4.o();
        }
    }

    public final Throwable p(m<?> mVar) {
        b0 b0Var;
        do {
            Object obj = this._reusableCancellableContinuation;
            b0Var = g.f3524b;
            if (obj != b0Var) {
                if (!(obj instanceof Throwable)) {
                    throw new IllegalStateException(("Inconsistent state " + obj).toString());
                } else if (b.a(f3511k, this, obj, (Object) null)) {
                    return (Throwable) obj;
                } else {
                    throw new IllegalArgumentException("Failed requirement.".toString());
                }
            }
        } while (!b.a(f3511k, this, b0Var, mVar));
        return null;
    }

    public void resumeWith(Object obj) {
        g context;
        Object c4;
        g context2 = this.f3513h.getContext();
        Object d4 = e0.d(obj, (l) null, 1, (Object) null);
        if (this.f3512g.J(context2)) {
            this.f3514i = d4;
            this.f4316f = 0;
            this.f3512g.I(context2, this);
            return;
        }
        d1 b4 = o2.f4292a.b();
        if (b4.S()) {
            this.f3514i = d4;
            this.f4316f = 0;
            b4.O(this);
            return;
        }
        b4.Q(true);
        try {
            context = getContext();
            c4 = f0.c(context, this.f3515j);
            this.f3513h.resumeWith(obj);
            s sVar = s.f271a;
            f0.a(context, c4);
            do {
            } while (b4.V());
        } catch (Throwable th) {
            try {
                f(th, (Throwable) null);
            } catch (Throwable th2) {
                b4.L(true);
                throw th2;
            }
        }
        b4.L(true);
    }

    public String toString() {
        return "DispatchedContinuation[" + this.f3512g + ", " + p0.c(this.f3513h) + ']';
    }
}
