package kotlinx.coroutines.internal;

import java.util.concurrent.atomic.AtomicLongFieldUpdater;
import java.util.concurrent.atomic.AtomicReferenceArray;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
import kotlin.jvm.internal.e;

public final class q<E> {

    /* renamed from: e  reason: collision with root package name */
    public static final a f3545e = new a((e) null);

    /* renamed from: f  reason: collision with root package name */
    private static final /* synthetic */ AtomicReferenceFieldUpdater f3546f;

    /* renamed from: g  reason: collision with root package name */
    private static final /* synthetic */ AtomicLongFieldUpdater f3547g;

    /* renamed from: h  reason: collision with root package name */
    public static final b0 f3548h = new b0("REMOVE_FROZEN");
    private volatile /* synthetic */ Object _next = null;
    private volatile /* synthetic */ long _state = 0;

    /* renamed from: a  reason: collision with root package name */
    private final int f3549a;

    /* renamed from: b  reason: collision with root package name */
    private final boolean f3550b;

    /* renamed from: c  reason: collision with root package name */
    private final int f3551c;

    /* renamed from: d  reason: collision with root package name */
    private /* synthetic */ AtomicReferenceArray f3552d;

    public static final class a {
        private a() {
        }

        public /* synthetic */ a(e eVar) {
            this();
        }

        public final int a(long j4) {
            return (j4 & 2305843009213693952L) != 0 ? 2 : 1;
        }

        public final long b(long j4, int i4) {
            return d(j4, 1073741823) | (((long) i4) << 0);
        }

        public final long c(long j4, int i4) {
            return d(j4, 1152921503533105152L) | (((long) i4) << 30);
        }

        public final long d(long j4, long j5) {
            return j4 & (~j5);
        }
    }

    public static final class b {

        /* renamed from: a  reason: collision with root package name */
        public final int f3553a;

        public b(int i4) {
            this.f3553a = i4;
        }
    }

    static {
        Class<q> cls = q.class;
        f3546f = AtomicReferenceFieldUpdater.newUpdater(cls, Object.class, "_next");
        f3547g = AtomicLongFieldUpdater.newUpdater(cls, "_state");
    }

    public q(int i4, boolean z3) {
        this.f3549a = i4;
        this.f3550b = z3;
        int i5 = i4 - 1;
        this.f3551c = i5;
        this.f3552d = new AtomicReferenceArray(i4);
        boolean z4 = false;
        if (i5 <= 1073741823) {
            if (!((i4 & i5) == 0 ? true : z4)) {
                throw new IllegalStateException("Check failed.".toString());
            }
            return;
        }
        throw new IllegalStateException("Check failed.".toString());
    }

    private final q<E> b(long j4) {
        q<E> qVar = new q<>(this.f3549a * 2, this.f3550b);
        int i4 = (int) ((1073741823 & j4) >> 0);
        int i5 = (int) ((1152921503533105152L & j4) >> 30);
        while (true) {
            int i6 = this.f3551c;
            if ((i4 & i6) != (i5 & i6)) {
                Object obj = this.f3552d.get(i6 & i4);
                if (obj == null) {
                    obj = new b(i4);
                }
                qVar.f3552d.set(qVar.f3551c & i4, obj);
                i4++;
            } else {
                qVar._state = f3545e.d(j4, 1152921504606846976L);
                return qVar;
            }
        }
    }

    private final q<E> c(long j4) {
        while (true) {
            q<E> qVar = (q) this._next;
            if (qVar != null) {
                return qVar;
            }
            androidx.concurrent.futures.b.a(f3546f, this, (Object) null, b(j4));
        }
    }

    private final q<E> e(int i4, E e4) {
        Object obj = this.f3552d.get(this.f3551c & i4);
        if (!(obj instanceof b) || ((b) obj).f3553a != i4) {
            return null;
        }
        this.f3552d.set(i4 & this.f3551c, e4);
        return this;
    }

    private final long h() {
        long j4;
        long j5;
        do {
            j4 = this._state;
            if ((j4 & 1152921504606846976L) != 0) {
                return j4;
            }
            j5 = j4 | 1152921504606846976L;
        } while (!f3547g.compareAndSet(this, j4, j5));
        return j5;
    }

    private final q<E> k(int i4, int i5) {
        long j4;
        a aVar;
        int i6;
        do {
            j4 = this._state;
            aVar = f3545e;
            i6 = (int) ((1073741823 & j4) >> 0);
            if ((1152921504606846976L & j4) != 0) {
                return i();
            }
        } while (!f3547g.compareAndSet(this, j4, aVar.b(j4, i5)));
        this.f3552d.set(this.f3551c & i6, (Object) null);
        return null;
    }

    /* JADX WARNING: Removed duplicated region for block: B:19:0x0069 A[LOOP:1: B:19:0x0069->B:22:0x007a, LOOP_START, PHI: r0 
      PHI: (r0v7 kotlinx.coroutines.internal.q) = (r0v6 kotlinx.coroutines.internal.q), (r0v9 kotlinx.coroutines.internal.q) binds: [B:18:0x0061, B:22:0x007a] A[DONT_GENERATE, DONT_INLINE]] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final int a(E r14) {
        /*
            r13 = this;
        L_0x0000:
            long r2 = r13._state
            r0 = 3458764513820540928(0x3000000000000000, double:1.727233711018889E-77)
            long r0 = r0 & r2
            r6 = 0
            int r4 = (r0 > r6 ? 1 : (r0 == r6 ? 0 : -1))
            if (r4 == 0) goto L_0x0012
            kotlinx.coroutines.internal.q$a r14 = f3545e
            int r14 = r14.a(r2)
            return r14
        L_0x0012:
            kotlinx.coroutines.internal.q$a r0 = f3545e
            r4 = 1073741823(0x3fffffff, double:5.304989472E-315)
            long r4 = r4 & r2
            r8 = 0
            long r4 = r4 >> r8
            int r1 = (int) r4
            r4 = 1152921503533105152(0xfffffffc0000000, double:1.2882296003504729E-231)
            long r4 = r4 & r2
            r9 = 30
            long r4 = r4 >> r9
            int r9 = (int) r4
            int r10 = r13.f3551c
            int r4 = r9 + 2
            r4 = r4 & r10
            r5 = r1 & r10
            r11 = 1
            if (r4 != r5) goto L_0x0030
            return r11
        L_0x0030:
            boolean r4 = r13.f3550b
            r5 = 1073741823(0x3fffffff, float:1.9999999)
            if (r4 != 0) goto L_0x004f
            java.util.concurrent.atomic.AtomicReferenceArray r4 = r13.f3552d
            r12 = r9 & r10
            java.lang.Object r4 = r4.get(r12)
            if (r4 == 0) goto L_0x004f
            int r0 = r13.f3549a
            r2 = 1024(0x400, float:1.435E-42)
            if (r0 < r2) goto L_0x004e
            int r9 = r9 - r1
            r1 = r9 & r5
            int r0 = r0 >> 1
            if (r1 <= r0) goto L_0x0000
        L_0x004e:
            return r11
        L_0x004f:
            int r1 = r9 + 1
            r1 = r1 & r5
            java.util.concurrent.atomic.AtomicLongFieldUpdater r4 = f3547g
            long r11 = r0.c(r2, r1)
            r0 = r4
            r1 = r13
            r4 = r11
            boolean r0 = r0.compareAndSet(r1, r2, r4)
            if (r0 == 0) goto L_0x0000
            java.util.concurrent.atomic.AtomicReferenceArray r0 = r13.f3552d
            r1 = r9 & r10
            r0.set(r1, r14)
            r0 = r13
        L_0x0069:
            long r1 = r0._state
            r3 = 1152921504606846976(0x1000000000000000, double:1.2882297539194267E-231)
            long r1 = r1 & r3
            int r3 = (r1 > r6 ? 1 : (r1 == r6 ? 0 : -1))
            if (r3 == 0) goto L_0x007c
            kotlinx.coroutines.internal.q r0 = r0.i()
            kotlinx.coroutines.internal.q r0 = r0.e(r9, r14)
            if (r0 != 0) goto L_0x0069
        L_0x007c:
            return r8
        */
        throw new UnsupportedOperationException("Method not decompiled: kotlinx.coroutines.internal.q.a(java.lang.Object):int");
    }

    public final boolean d() {
        long j4;
        do {
            j4 = this._state;
            if ((j4 & 2305843009213693952L) != 0) {
                return true;
            }
            if ((1152921504606846976L & j4) != 0) {
                return false;
            }
        } while (!f3547g.compareAndSet(this, j4, j4 | 2305843009213693952L));
        return true;
    }

    public final int f() {
        long j4 = this._state;
        return 1073741823 & (((int) ((j4 & 1152921503533105152L) >> 30)) - ((int) ((1073741823 & j4) >> 0)));
    }

    public final boolean g() {
        long j4 = this._state;
        return ((int) ((1073741823 & j4) >> 0)) == ((int) ((j4 & 1152921503533105152L) >> 30));
    }

    public final q<E> i() {
        return c(h());
    }

    public final Object j() {
        while (true) {
            long j4 = this._state;
            if ((1152921504606846976L & j4) != 0) {
                return f3548h;
            }
            a aVar = f3545e;
            int i4 = (int) ((1073741823 & j4) >> 0);
            int i5 = (int) ((1152921503533105152L & j4) >> 30);
            int i6 = this.f3551c;
            if ((i5 & i6) == (i4 & i6)) {
                return null;
            }
            Object obj = this.f3552d.get(i6 & i4);
            if (obj == null) {
                if (this.f3550b) {
                    return null;
                }
            } else if (obj instanceof b) {
                return null;
            } else {
                int i7 = (i4 + 1) & 1073741823;
                if (f3547g.compareAndSet(this, j4, aVar.b(j4, i7))) {
                    this.f3552d.set(this.f3551c & i4, (Object) null);
                    return obj;
                } else if (this.f3550b) {
                    q qVar = this;
                    do {
                        qVar = qVar.k(i4, i7);
                    } while (qVar != null);
                    return obj;
                }
            }
        }
    }
}
