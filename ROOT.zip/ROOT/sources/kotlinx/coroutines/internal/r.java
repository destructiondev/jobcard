package kotlinx.coroutines.internal;

import java.util.List;
import s3.d2;

public interface r {
    int a();

    String b();

    d2 c(List<? extends r> list);
}
