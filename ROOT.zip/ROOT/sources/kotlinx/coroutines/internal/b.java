package kotlinx.coroutines.internal;

public final class b {

    /* renamed from: a  reason: collision with root package name */
    public static final Object f3504a = new b0("NO_DECISION");

    /* renamed from: b  reason: collision with root package name */
    public static final Object f3505b = new b0("RETRY_ATOMIC");
}
