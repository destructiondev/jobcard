package kotlinx.coroutines.internal;

final class x {

    /* renamed from: a  reason: collision with root package name */
    public final o f3563a;

    public x(o oVar) {
        this.f3563a = oVar;
    }

    public String toString() {
        return "Removed[" + this.f3563a + ']';
    }
}
