package kotlinx.coroutines.internal;

public final class b0 {

    /* renamed from: a  reason: collision with root package name */
    public final String f3506a;

    public b0(String str) {
        this.f3506a = str;
    }

    public String toString() {
        return '<' + this.f3506a + '>';
    }
}
