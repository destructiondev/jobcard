package kotlinx.coroutines.internal;

import c3.d;
import c3.g;
import j3.l;
import kotlin.coroutines.jvm.internal.e;
import s3.a;
import s3.e0;
import s3.s;
import s3.t1;

public class z<T> extends a<T> implements e {

    /* renamed from: f  reason: collision with root package name */
    public final d<T> f3564f;

    public z(g gVar, d<? super T> dVar) {
        super(gVar, true, true);
        this.f3564f = dVar;
    }

    /* access modifiers changed from: protected */
    public void J(Object obj) {
        g.c(c.b(this.f3564f), e0.a(obj, this.f3564f), (l) null, 2, (Object) null);
    }

    /* access modifiers changed from: protected */
    public void J0(Object obj) {
        d<T> dVar = this.f3564f;
        dVar.resumeWith(e0.a(obj, dVar));
    }

    public final t1 N0() {
        s d02 = d0();
        if (d02 != null) {
            return d02.getParent();
        }
        return null;
    }

    public final e getCallerFrame() {
        d<T> dVar = this.f3564f;
        if (dVar instanceof e) {
            return (e) dVar;
        }
        return null;
    }

    /* access modifiers changed from: protected */
    public final boolean j0() {
        return true;
    }
}
