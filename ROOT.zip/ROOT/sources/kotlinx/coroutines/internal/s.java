package kotlinx.coroutines.internal;

import java.util.Iterator;
import java.util.List;
import java.util.ServiceLoader;
import s3.d2;

public final class s {

    /* renamed from: a  reason: collision with root package name */
    public static final s f3554a;

    /* renamed from: b  reason: collision with root package name */
    private static final boolean f3555b = c0.e("kotlinx.coroutines.fast.service.loader", true);

    /* renamed from: c  reason: collision with root package name */
    public static final d2 f3556c;

    static {
        s sVar = new s();
        f3554a = sVar;
        f3556c = sVar.a();
    }

    private s() {
    }

    private final d2 a() {
        T t4;
        d2 e4;
        Class<r> cls = r.class;
        try {
            List<r> c4 = f3555b ? h.f3526a.c() : h.e(f.a(ServiceLoader.load(cls, cls.getClassLoader()).iterator()));
            Iterator<T> it = c4.iterator();
            if (!it.hasNext()) {
                t4 = null;
            } else {
                t4 = it.next();
                if (it.hasNext()) {
                    int a4 = ((r) t4).a();
                    do {
                        T next = it.next();
                        int a5 = ((r) next).a();
                        if (a4 < a5) {
                            t4 = next;
                            a4 = a5;
                        }
                    } while (it.hasNext());
                }
            }
            r rVar = (r) t4;
            return (rVar == null || (e4 = t.e(rVar, c4)) == null) ? t.b((Throwable) null, (String) null, 3, (Object) null) : e4;
        } catch (Throwable th) {
            return t.b(th, (String) null, 2, (Object) null);
        }
    }
}
