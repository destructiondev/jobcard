package kotlinx.coroutines.internal;

import java.util.Objects;

public class a<T> {

    /* renamed from: a  reason: collision with root package name */
    private Object[] f3499a = new Object[16];

    /* renamed from: b  reason: collision with root package name */
    private int f3500b;

    /* renamed from: c  reason: collision with root package name */
    private int f3501c;

    private final void b() {
        Object[] objArr = this.f3499a;
        int length = objArr.length;
        Object[] objArr2 = new Object[(length << 1)];
        Object[] objArr3 = objArr2;
        Object[] unused = h.d(objArr, objArr3, 0, this.f3500b, 0, 10, (Object) null);
        Object[] objArr4 = this.f3499a;
        int length2 = objArr4.length;
        int i4 = this.f3500b;
        Object[] unused2 = h.d(objArr4, objArr2, length2 - i4, 0, i4, 4, (Object) null);
        this.f3499a = objArr3;
        this.f3500b = 0;
        this.f3501c = length;
    }

    public final void a(T t4) {
        Object[] objArr = this.f3499a;
        int i4 = this.f3501c;
        objArr[i4] = t4;
        int length = (objArr.length - 1) & (i4 + 1);
        this.f3501c = length;
        if (length == this.f3500b) {
            b();
        }
    }

    public final boolean c() {
        return this.f3500b == this.f3501c;
    }

    public final T d() {
        int i4 = this.f3500b;
        if (i4 == this.f3501c) {
            return null;
        }
        T[] tArr = this.f3499a;
        T t4 = tArr[i4];
        tArr[i4] = null;
        this.f3500b = (i4 + 1) & (tArr.length - 1);
        Objects.requireNonNull(t4, "null cannot be cast to non-null type T of kotlinx.coroutines.internal.ArrayQueue");
        return t4;
    }
}
