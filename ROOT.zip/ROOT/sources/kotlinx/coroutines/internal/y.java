package kotlinx.coroutines.internal;

import java.util.concurrent.atomic.AtomicReferenceArray;

public final class y<T> {
    private volatile AtomicReferenceArray<T> array;

    public y(int i4) {
        this.array = new AtomicReferenceArray<>(i4);
    }

    public final int a() {
        return this.array.length();
    }

    public final T b(int i4) {
        AtomicReferenceArray<T> atomicReferenceArray = this.array;
        if (i4 < atomicReferenceArray.length()) {
            return atomicReferenceArray.get(i4);
        }
        return null;
    }

    public final void c(int i4, T t4) {
        AtomicReferenceArray<T> atomicReferenceArray = this.array;
        int length = atomicReferenceArray.length();
        if (i4 < length) {
            atomicReferenceArray.set(i4, t4);
            return;
        }
        AtomicReferenceArray<T> atomicReferenceArray2 = new AtomicReferenceArray<>(i.a(i4 + 1, length * 2));
        for (int i5 = 0; i5 < length; i5++) {
            atomicReferenceArray2.set(i5, atomicReferenceArray.get(i5));
        }
        atomicReferenceArray2.set(i4, t4);
        this.array = atomicReferenceArray2;
    }
}
