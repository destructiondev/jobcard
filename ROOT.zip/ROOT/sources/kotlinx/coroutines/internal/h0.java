package kotlinx.coroutines.internal;

public interface h0 {
    void d(int i4);

    void e(g0<?> g0Var);

    g0<?> h();

    int l();
}
