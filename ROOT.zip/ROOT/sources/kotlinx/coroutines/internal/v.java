package kotlinx.coroutines.internal;

import a3.s;
import c3.g;
import j3.l;
import kotlin.jvm.internal.j;
import s3.k0;

public final class v {

    static final class a extends j implements l<Throwable, s> {

        /* renamed from: d  reason: collision with root package name */
        final /* synthetic */ l<E, s> f3560d;

        /* renamed from: e  reason: collision with root package name */
        final /* synthetic */ E f3561e;

        /* renamed from: f  reason: collision with root package name */
        final /* synthetic */ g f3562f;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        a(l<? super E, s> lVar, E e4, g gVar) {
            super(1);
            this.f3560d = lVar;
            this.f3561e = e4;
            this.f3562f = gVar;
        }

        public final void b(Throwable th) {
            v.b(this.f3560d, this.f3561e, this.f3562f);
        }

        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            b((Throwable) obj);
            return s.f271a;
        }
    }

    public static final <E> l<Throwable, s> a(l<? super E, s> lVar, E e4, g gVar) {
        return new a(lVar, e4, gVar);
    }

    public static final <E> void b(l<? super E, s> lVar, E e4, g gVar) {
        j0 c4 = c(lVar, e4, (j0) null);
        if (c4 != null) {
            k0.a(gVar, c4);
        }
    }

    public static final <E> j0 c(l<? super E, s> lVar, E e4, j0 j0Var) {
        try {
            lVar.invoke(e4);
        } catch (Throwable th) {
            if (j0Var == null || j0Var.getCause() == th) {
                return new j0("Exception in undelivered element handler for " + e4, th);
            }
            b.a(j0Var, th);
        }
        return j0Var;
    }

    public static /* synthetic */ j0 d(l lVar, Object obj, j0 j0Var, int i4, Object obj2) {
        if ((i4 & 2) != 0) {
            j0Var = null;
        }
        return c(lVar, obj, j0Var);
    }
}
