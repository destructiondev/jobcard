package kotlinx.coroutines.internal;

public final class c0 {
    public static final int a() {
        return d0.a();
    }

    public static final int b(String str, int i4, int i5, int i6) {
        return e0.a(str, i4, i5, i6);
    }

    public static final long c(String str, long j4, long j5, long j6) {
        return e0.b(str, j4, j5, j6);
    }

    public static final String d(String str) {
        return d0.b(str);
    }

    public static final boolean e(String str, boolean z3) {
        return e0.c(str, z3);
    }
}
