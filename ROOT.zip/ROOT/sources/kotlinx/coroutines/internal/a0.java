package kotlinx.coroutines.internal;

import a3.m;
import a3.n;

public final class a0 {

    /* renamed from: a  reason: collision with root package name */
    private static final String f3502a;

    /* renamed from: b  reason: collision with root package name */
    private static final String f3503b;

    static {
        Object obj;
        Object obj2;
        try {
            m.a aVar = m.f265d;
            obj = m.a(Class.forName("kotlin.coroutines.jvm.internal.a").getCanonicalName());
        } catch (Throwable th) {
            m.a aVar2 = m.f265d;
            obj = m.a(n.a(th));
        }
        if (m.b(obj) != null) {
            obj = "kotlin.coroutines.jvm.internal.BaseContinuationImpl";
        }
        f3502a = (String) obj;
        try {
            m.a aVar3 = m.f265d;
            obj2 = m.a(a0.class.getCanonicalName());
        } catch (Throwable th2) {
            m.a aVar4 = m.f265d;
            obj2 = m.a(n.a(th2));
        }
        if (m.b(obj2) != null) {
            obj2 = "kotlinx.coroutines.internal.StackTraceRecoveryKt";
        }
        f3503b = (String) obj2;
    }

    public static final <E extends Throwable> E a(E e4) {
        return e4;
    }
}
