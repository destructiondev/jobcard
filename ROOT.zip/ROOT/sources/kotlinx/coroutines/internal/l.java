package kotlinx.coroutines.internal;

public final class l {
    public static final void a(int i4) {
        boolean z3 = true;
        if (i4 < 1) {
            z3 = false;
        }
        if (!z3) {
            throw new IllegalArgumentException(("Expected positive parallelism level, but got " + i4).toString());
        }
    }
}
