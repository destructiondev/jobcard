package kotlinx.coroutines.internal;

import java.lang.Comparable;
import java.util.Arrays;
import kotlin.jvm.internal.i;
import kotlinx.coroutines.internal.h0;

public class g0<T extends h0 & Comparable<? super T>> {
    private volatile /* synthetic */ int _size = 0;

    /* renamed from: a  reason: collision with root package name */
    private T[] f3525a;

    private final T[] f() {
        T[] tArr = this.f3525a;
        if (tArr == null) {
            T[] tArr2 = new h0[4];
            this.f3525a = tArr2;
            return tArr2;
        } else if (c() < tArr.length) {
            return tArr;
        } else {
            T[] copyOf = Arrays.copyOf(tArr, c() * 2);
            i.d(copyOf, "copyOf(this, newSize)");
            T[] tArr3 = (h0[]) copyOf;
            this.f3525a = tArr3;
            return tArr3;
        }
    }

    private final void j(int i4) {
        this._size = i4;
    }

    private final void k(int i4) {
        while (true) {
            int i5 = (i4 * 2) + 1;
            if (i5 < c()) {
                T[] tArr = this.f3525a;
                i.b(tArr);
                int i6 = i5 + 1;
                if (i6 < c()) {
                    T t4 = tArr[i6];
                    i.b(t4);
                    T t5 = tArr[i5];
                    i.b(t5);
                    if (((Comparable) t4).compareTo(t5) < 0) {
                        i5 = i6;
                    }
                }
                T t6 = tArr[i4];
                i.b(t6);
                T t7 = tArr[i5];
                i.b(t7);
                if (((Comparable) t6).compareTo(t7) > 0) {
                    m(i4, i5);
                    i4 = i5;
                } else {
                    return;
                }
            } else {
                return;
            }
        }
    }

    private final void l(int i4) {
        while (i4 > 0) {
            T[] tArr = this.f3525a;
            i.b(tArr);
            int i5 = (i4 - 1) / 2;
            T t4 = tArr[i5];
            i.b(t4);
            T t5 = tArr[i4];
            i.b(t5);
            if (((Comparable) t4).compareTo(t5) > 0) {
                m(i4, i5);
                i4 = i5;
            } else {
                return;
            }
        }
    }

    private final void m(int i4, int i5) {
        T[] tArr = this.f3525a;
        i.b(tArr);
        T t4 = tArr[i5];
        i.b(t4);
        T t5 = tArr[i4];
        i.b(t5);
        tArr[i4] = t4;
        tArr[i5] = t5;
        t4.d(i4);
        t5.d(i5);
    }

    public final void a(T t4) {
        t4.e(this);
        h0[] f4 = f();
        int c4 = c();
        j(c4 + 1);
        f4[c4] = t4;
        t4.d(c4);
        l(c4);
    }

    public final T b() {
        T[] tArr = this.f3525a;
        if (tArr != null) {
            return tArr[0];
        }
        return null;
    }

    public final int c() {
        return this._size;
    }

    public final boolean d() {
        return c() == 0;
    }

    public final T e() {
        T b4;
        synchronized (this) {
            b4 = b();
        }
        return b4;
    }

    public final boolean g(T t4) {
        boolean z3;
        synchronized (this) {
            if (t4.h() == null) {
                z3 = false;
            } else {
                h(t4.l());
                z3 = true;
            }
        }
        return z3;
    }

    public final T h(int i4) {
        T[] tArr = this.f3525a;
        i.b(tArr);
        j(c() - 1);
        if (i4 < c()) {
            m(i4, c());
            int i5 = (i4 - 1) / 2;
            if (i4 > 0) {
                T t4 = tArr[i4];
                i.b(t4);
                T t5 = tArr[i5];
                i.b(t5);
                if (((Comparable) t4).compareTo(t5) < 0) {
                    m(i4, i5);
                    l(i5);
                }
            }
            k(i4);
        }
        T t6 = tArr[c()];
        i.b(t6);
        t6.e((g0<?>) null);
        t6.d(-1);
        tArr[c()] = null;
        return t6;
    }

    public final T i() {
        T h4;
        synchronized (this) {
            h4 = c() > 0 ? h(0) : null;
        }
        return h4;
    }
}
