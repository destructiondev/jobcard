package kotlinx.coroutines.internal;

public final class j0 extends RuntimeException {
    public j0(String str, Throwable th) {
        super(str, th);
    }
}
