package kotlinx.coroutines.internal;

public class m extends o {
    public final boolean C() {
        return r() == this;
    }

    public final Void D() {
        throw new IllegalStateException("head cannot be removed".toString());
    }

    public boolean w() {
        return false;
    }

    public /* bridge */ /* synthetic */ boolean x() {
        return ((Boolean) D()).booleanValue();
    }
}
