package kotlinx.coroutines.internal;

import c3.g;
import kotlin.jvm.internal.i;
import s3.n2;

final class i0 {

    /* renamed from: a  reason: collision with root package name */
    public final g f3528a;

    /* renamed from: b  reason: collision with root package name */
    private final Object[] f3529b;

    /* renamed from: c  reason: collision with root package name */
    private final n2<Object>[] f3530c;

    /* renamed from: d  reason: collision with root package name */
    private int f3531d;

    public i0(g gVar, int i4) {
        this.f3528a = gVar;
        this.f3529b = new Object[i4];
        this.f3530c = new n2[i4];
    }

    public final void a(n2<?> n2Var, Object obj) {
        Object[] objArr = this.f3529b;
        int i4 = this.f3531d;
        objArr[i4] = obj;
        n2<Object>[] n2VarArr = this.f3530c;
        this.f3531d = i4 + 1;
        n2VarArr[i4] = n2Var;
    }

    public final void b(g gVar) {
        int length = this.f3530c.length - 1;
        if (length >= 0) {
            while (true) {
                int i4 = length - 1;
                n2<Object> n2Var = this.f3530c[length];
                i.b(n2Var);
                n2Var.B(gVar, this.f3529b[length]);
                if (i4 >= 0) {
                    length = i4;
                } else {
                    return;
                }
            }
        }
    }
}
