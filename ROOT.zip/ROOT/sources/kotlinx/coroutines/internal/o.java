package kotlinx.coroutines.internal;

import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
import kotlin.jvm.internal.i;
import kotlin.jvm.internal.m;
import s3.p0;

public class o {

    /* renamed from: d  reason: collision with root package name */
    static final /* synthetic */ AtomicReferenceFieldUpdater f3539d;

    /* renamed from: e  reason: collision with root package name */
    static final /* synthetic */ AtomicReferenceFieldUpdater f3540e;

    /* renamed from: f  reason: collision with root package name */
    private static final /* synthetic */ AtomicReferenceFieldUpdater f3541f;
    volatile /* synthetic */ Object _next = this;
    volatile /* synthetic */ Object _prev = this;
    private volatile /* synthetic */ Object _removedRef = null;

    public static abstract class a extends c<o> {

        /* renamed from: b  reason: collision with root package name */
        public final o f3542b;

        /* renamed from: c  reason: collision with root package name */
        public o f3543c;

        public a(o oVar) {
            this.f3542b = oVar;
        }

        /* renamed from: h */
        public void d(o oVar, Object obj) {
            boolean z3 = obj == null;
            o oVar2 = z3 ? this.f3542b : this.f3543c;
            if (oVar2 != null && androidx.concurrent.futures.b.a(o.f3539d, oVar, this, oVar2) && z3) {
                o oVar3 = this.f3542b;
                o oVar4 = this.f3543c;
                i.b(oVar4);
                oVar3.q(oVar4);
            }
        }
    }

    public static final class b extends w {
    }

    /* synthetic */ class c extends m {
        c(Object obj) {
            super(obj, p0.class, "classSimpleName", "getClassSimpleName(Ljava/lang/Object;)Ljava/lang/String;", 1);
        }

        public Object get() {
            return p0.a(this.receiver);
        }
    }

    static {
        Class<Object> cls = Object.class;
        Class<o> cls2 = o.class;
        f3539d = AtomicReferenceFieldUpdater.newUpdater(cls2, cls, "_next");
        f3540e = AtomicReferenceFieldUpdater.newUpdater(cls2, cls, "_prev");
        f3541f = AtomicReferenceFieldUpdater.newUpdater(cls2, cls, "_removedRef");
    }

    private final x A() {
        x xVar = (x) this._removedRef;
        if (xVar != null) {
            return xVar;
        }
        x xVar2 = new x(this);
        f3541f.lazySet(this, xVar2);
        return xVar2;
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r4v0, resolved type: java.lang.Object} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v3, resolved type: kotlinx.coroutines.internal.w} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r3v3, resolved type: kotlinx.coroutines.internal.o} */
    /* JADX WARNING: Code restructure failed: missing block: B:25:0x0048, code lost:
        if (androidx.concurrent.futures.b.a(f3539d, r3, r2, ((kotlinx.coroutines.internal.x) r4).f3563a) != false) goto L_0x004b;
     */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private final kotlinx.coroutines.internal.o o(kotlinx.coroutines.internal.w r8) {
        /*
            r7 = this;
        L_0x0000:
            java.lang.Object r0 = r7._prev
            kotlinx.coroutines.internal.o r0 = (kotlinx.coroutines.internal.o) r0
            r1 = 0
            r2 = r0
        L_0x0006:
            r3 = r1
        L_0x0007:
            java.lang.Object r4 = r2._next
            if (r4 != r7) goto L_0x0018
            if (r0 != r2) goto L_0x000e
            return r2
        L_0x000e:
            java.util.concurrent.atomic.AtomicReferenceFieldUpdater r1 = f3540e
            boolean r0 = androidx.concurrent.futures.b.a(r1, r7, r0, r2)
            if (r0 != 0) goto L_0x0017
            goto L_0x0000
        L_0x0017:
            return r2
        L_0x0018:
            boolean r5 = r7.w()
            if (r5 == 0) goto L_0x001f
            return r1
        L_0x001f:
            if (r4 != r8) goto L_0x0022
            return r2
        L_0x0022:
            boolean r5 = r4 instanceof kotlinx.coroutines.internal.w
            if (r5 == 0) goto L_0x0038
            if (r8 == 0) goto L_0x0032
            r0 = r4
            kotlinx.coroutines.internal.w r0 = (kotlinx.coroutines.internal.w) r0
            boolean r0 = r8.b(r0)
            if (r0 == 0) goto L_0x0032
            return r1
        L_0x0032:
            kotlinx.coroutines.internal.w r4 = (kotlinx.coroutines.internal.w) r4
            r4.c(r2)
            goto L_0x0000
        L_0x0038:
            boolean r5 = r4 instanceof kotlinx.coroutines.internal.x
            if (r5 == 0) goto L_0x0052
            if (r3 == 0) goto L_0x004d
            java.util.concurrent.atomic.AtomicReferenceFieldUpdater r5 = f3539d
            kotlinx.coroutines.internal.x r4 = (kotlinx.coroutines.internal.x) r4
            kotlinx.coroutines.internal.o r4 = r4.f3563a
            boolean r2 = androidx.concurrent.futures.b.a(r5, r3, r2, r4)
            if (r2 != 0) goto L_0x004b
            goto L_0x0000
        L_0x004b:
            r2 = r3
            goto L_0x0006
        L_0x004d:
            java.lang.Object r2 = r2._prev
            kotlinx.coroutines.internal.o r2 = (kotlinx.coroutines.internal.o) r2
            goto L_0x0007
        L_0x0052:
            r3 = r4
            kotlinx.coroutines.internal.o r3 = (kotlinx.coroutines.internal.o) r3
            r6 = r3
            r3 = r2
            r2 = r6
            goto L_0x0007
        */
        throw new UnsupportedOperationException("Method not decompiled: kotlinx.coroutines.internal.o.o(kotlinx.coroutines.internal.w):kotlinx.coroutines.internal.o");
    }

    private final o p(o oVar) {
        while (oVar.w()) {
            oVar = (o) oVar._prev;
        }
        return oVar;
    }

    /* access modifiers changed from: private */
    public final void q(o oVar) {
        o oVar2;
        do {
            oVar2 = (o) oVar._prev;
            if (r() != oVar) {
                return;
            }
        } while (!androidx.concurrent.futures.b.a(f3540e, oVar, oVar2, this));
        if (w()) {
            oVar.o((w) null);
        }
    }

    public final int B(o oVar, o oVar2, a aVar) {
        f3540e.lazySet(oVar, this);
        AtomicReferenceFieldUpdater atomicReferenceFieldUpdater = f3539d;
        atomicReferenceFieldUpdater.lazySet(oVar, oVar2);
        aVar.f3543c = oVar2;
        if (!androidx.concurrent.futures.b.a(atomicReferenceFieldUpdater, this, oVar2, aVar)) {
            return 0;
        }
        return aVar.c(this) == null ? 1 : 2;
    }

    public final void l(o oVar) {
        do {
        } while (!t().m(oVar, this));
    }

    public final boolean m(o oVar, o oVar2) {
        f3540e.lazySet(oVar, this);
        AtomicReferenceFieldUpdater atomicReferenceFieldUpdater = f3539d;
        atomicReferenceFieldUpdater.lazySet(oVar, oVar2);
        if (!androidx.concurrent.futures.b.a(atomicReferenceFieldUpdater, this, oVar2, oVar)) {
            return false;
        }
        oVar.q(oVar2);
        return true;
    }

    public final boolean n(o oVar) {
        f3540e.lazySet(oVar, this);
        f3539d.lazySet(oVar, this);
        while (r() == this) {
            if (androidx.concurrent.futures.b.a(f3539d, this, this, oVar)) {
                oVar.q(this);
                return true;
            }
        }
        return false;
    }

    public final Object r() {
        while (true) {
            Object obj = this._next;
            if (!(obj instanceof w)) {
                return obj;
            }
            ((w) obj).c(this);
        }
    }

    public final o s() {
        return n.b(r());
    }

    public final o t() {
        o o4 = o((w) null);
        return o4 == null ? p((o) this._prev) : o4;
    }

    public String toString() {
        return new c(this) + '@' + p0.b(this);
    }

    public final void u() {
        ((x) r()).f3563a.v();
    }

    public final void v() {
        o oVar = this;
        while (true) {
            Object r4 = oVar.r();
            if (r4 instanceof x) {
                oVar = ((x) r4).f3563a;
            } else {
                oVar.o((w) null);
                return;
            }
        }
    }

    public boolean w() {
        return r() instanceof x;
    }

    public boolean x() {
        return z() == null;
    }

    public final o y() {
        while (true) {
            o oVar = (o) r();
            if (oVar == this) {
                return null;
            }
            if (oVar.x()) {
                return oVar;
            }
            oVar.u();
        }
    }

    public final o z() {
        Object r4;
        o oVar;
        do {
            r4 = r();
            if (r4 instanceof x) {
                return ((x) r4).f3563a;
            }
            if (r4 == this) {
                return (o) r4;
            }
            oVar = (o) r4;
        } while (!androidx.concurrent.futures.b.a(f3539d, this, r4, oVar.A()));
        oVar.o((w) null);
        return null;
    }
}
