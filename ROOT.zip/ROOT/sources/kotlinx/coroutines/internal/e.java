package kotlinx.coroutines.internal;

import c3.g;
import s3.l0;

public final class e implements l0 {

    /* renamed from: d  reason: collision with root package name */
    private final g f3510d;

    public e(g gVar) {
        this.f3510d = gVar;
    }

    public g f() {
        return this.f3510d;
    }

    public String toString() {
        return "CoroutineScope(coroutineContext=" + f() + ')';
    }
}
