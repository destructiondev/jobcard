package kotlinx.coroutines.internal;

import c3.d;
import j3.l;

public final class g {
    /* access modifiers changed from: private */

    /* renamed from: a  reason: collision with root package name */
    public static final b0 f3523a = new b0("UNDEFINED");

    /* renamed from: b  reason: collision with root package name */
    public static final b0 f3524b = new b0("REUSABLE_CLAIMED");

    /* JADX WARNING: Code restructure failed: missing block: B:26:0x008f, code lost:
        if (r8.O0() != false) goto L_0x0091;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static final <T> void b(c3.d<? super T> r6, java.lang.Object r7, j3.l<? super java.lang.Throwable, a3.s> r8) {
        /*
            boolean r0 = r6 instanceof kotlinx.coroutines.internal.f
            if (r0 == 0) goto L_0x00b6
            kotlinx.coroutines.internal.f r6 = (kotlinx.coroutines.internal.f) r6
            java.lang.Object r8 = s3.e0.b(r7, r8)
            s3.h0 r0 = r6.f3512g
            c3.g r1 = r6.getContext()
            boolean r0 = r0.J(r1)
            r1 = 1
            if (r0 == 0) goto L_0x0026
            r6.f3514i = r8
            r6.f4316f = r1
            s3.h0 r7 = r6.f3512g
            c3.g r8 = r6.getContext()
            r7.I(r8, r6)
            goto L_0x00b9
        L_0x0026:
            s3.o2 r0 = s3.o2.f4292a
            s3.d1 r0 = r0.b()
            boolean r2 = r0.S()
            if (r2 == 0) goto L_0x003b
            r6.f3514i = r8
            r6.f4316f = r1
            r0.O(r6)
            goto L_0x00b9
        L_0x003b:
            r0.Q(r1)
            r2 = 0
            c3.g r3 = r6.getContext()     // Catch:{ all -> 0x00a9 }
            s3.t1$b r4 = s3.t1.f4311c     // Catch:{ all -> 0x00a9 }
            c3.g$b r3 = r3.a(r4)     // Catch:{ all -> 0x00a9 }
            s3.t1 r3 = (s3.t1) r3     // Catch:{ all -> 0x00a9 }
            if (r3 == 0) goto L_0x0069
            boolean r4 = r3.c()     // Catch:{ all -> 0x00a9 }
            if (r4 != 0) goto L_0x0069
            java.util.concurrent.CancellationException r3 = r3.j()     // Catch:{ all -> 0x00a9 }
            r6.a(r8, r3)     // Catch:{ all -> 0x00a9 }
            a3.m$a r8 = a3.m.f265d     // Catch:{ all -> 0x00a9 }
            java.lang.Object r8 = a3.n.a(r3)     // Catch:{ all -> 0x00a9 }
            java.lang.Object r8 = a3.m.a(r8)     // Catch:{ all -> 0x00a9 }
            r6.resumeWith(r8)     // Catch:{ all -> 0x00a9 }
            r8 = 1
            goto L_0x006a
        L_0x0069:
            r8 = 0
        L_0x006a:
            if (r8 != 0) goto L_0x00a2
            c3.d<T> r8 = r6.f3513h     // Catch:{ all -> 0x00a9 }
            java.lang.Object r3 = r6.f3515j     // Catch:{ all -> 0x00a9 }
            c3.g r4 = r8.getContext()     // Catch:{ all -> 0x00a9 }
            java.lang.Object r3 = kotlinx.coroutines.internal.f0.c(r4, r3)     // Catch:{ all -> 0x00a9 }
            kotlinx.coroutines.internal.b0 r5 = kotlinx.coroutines.internal.f0.f3516a     // Catch:{ all -> 0x00a9 }
            if (r3 == r5) goto L_0x0081
            s3.q2 r8 = s3.g0.g(r8, r4, r3)     // Catch:{ all -> 0x00a9 }
            goto L_0x0082
        L_0x0081:
            r8 = r2
        L_0x0082:
            c3.d<T> r5 = r6.f3513h     // Catch:{ all -> 0x0095 }
            r5.resumeWith(r7)     // Catch:{ all -> 0x0095 }
            a3.s r7 = a3.s.f271a     // Catch:{ all -> 0x0095 }
            if (r8 == 0) goto L_0x0091
            boolean r7 = r8.O0()     // Catch:{ all -> 0x00a9 }
            if (r7 == 0) goto L_0x00a2
        L_0x0091:
            kotlinx.coroutines.internal.f0.a(r4, r3)     // Catch:{ all -> 0x00a9 }
            goto L_0x00a2
        L_0x0095:
            r7 = move-exception
            if (r8 == 0) goto L_0x009e
            boolean r8 = r8.O0()     // Catch:{ all -> 0x00a9 }
            if (r8 == 0) goto L_0x00a1
        L_0x009e:
            kotlinx.coroutines.internal.f0.a(r4, r3)     // Catch:{ all -> 0x00a9 }
        L_0x00a1:
            throw r7     // Catch:{ all -> 0x00a9 }
        L_0x00a2:
            boolean r7 = r0.V()     // Catch:{ all -> 0x00a9 }
            if (r7 != 0) goto L_0x00a2
            goto L_0x00ad
        L_0x00a9:
            r7 = move-exception
            r6.f(r7, r2)     // Catch:{ all -> 0x00b1 }
        L_0x00ad:
            r0.L(r1)
            goto L_0x00b9
        L_0x00b1:
            r6 = move-exception
            r0.L(r1)
            throw r6
        L_0x00b6:
            r6.resumeWith(r7)
        L_0x00b9:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: kotlinx.coroutines.internal.g.b(c3.d, java.lang.Object, j3.l):void");
    }

    public static /* synthetic */ void c(d dVar, Object obj, l lVar, int i4, Object obj2) {
        if ((i4 & 2) != 0) {
            lVar = null;
        }
        b(dVar, obj, lVar);
    }
}
