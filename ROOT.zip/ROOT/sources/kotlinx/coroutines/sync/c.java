package kotlinx.coroutines.sync;

import a3.s;
import j3.l;
import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
import kotlin.coroutines.jvm.internal.h;
import kotlin.jvm.internal.j;
import kotlinx.coroutines.internal.w;
import s3.a1;
import s3.m;
import s3.n;
import s3.o;
import s3.p;

public final class c implements b {

    /* renamed from: a  reason: collision with root package name */
    static final /* synthetic */ AtomicReferenceFieldUpdater f3619a = AtomicReferenceFieldUpdater.newUpdater(c.class, Object.class, "_state");
    volatile /* synthetic */ Object _state;

    private final class a extends b {

        /* renamed from: j  reason: collision with root package name */
        private final m<s> f3620j;

        /* renamed from: kotlinx.coroutines.sync.c$a$a  reason: collision with other inner class name */
        static final class C0086a extends j implements l<Throwable, s> {

            /* renamed from: d  reason: collision with root package name */
            final /* synthetic */ c f3622d;

            /* renamed from: e  reason: collision with root package name */
            final /* synthetic */ a f3623e;

            /* JADX INFO: super call moved to the top of the method (can break code semantics) */
            C0086a(c cVar, a aVar) {
                super(1);
                this.f3622d = cVar;
                this.f3623e = aVar;
            }

            public final void b(Throwable th) {
                this.f3622d.a(this.f3623e.f3625g);
            }

            public /* bridge */ /* synthetic */ Object invoke(Object obj) {
                b((Throwable) obj);
                return s.f271a;
            }
        }

        public a(Object obj, m<? super s> mVar) {
            super(obj);
            this.f3620j = mVar;
        }

        public void C() {
            this.f3620j.w(o.f4291a);
        }

        public boolean E() {
            return D() && this.f3620j.g(s.f271a, (Object) null, new C0086a(c.this, this)) != null;
        }

        public String toString() {
            return "LockCont[" + this.f3625g + ", " + this.f3620j + "] for " + c.this;
        }
    }

    private abstract class b extends kotlinx.coroutines.internal.o implements a1 {

        /* renamed from: i  reason: collision with root package name */
        private static final /* synthetic */ AtomicIntegerFieldUpdater f3624i = AtomicIntegerFieldUpdater.newUpdater(b.class, "isTaken");

        /* renamed from: g  reason: collision with root package name */
        public final Object f3625g;
        private volatile /* synthetic */ int isTaken = 0;

        public b(Object obj) {
            this.f3625g = obj;
        }

        public abstract void C();

        public final boolean D() {
            return f3624i.compareAndSet(this, 0, 1);
        }

        public abstract boolean E();

        public final void b() {
            x();
        }
    }

    /* renamed from: kotlinx.coroutines.sync.c$c  reason: collision with other inner class name */
    private static final class C0087c extends kotlinx.coroutines.internal.m {
        public volatile Object owner;

        public C0087c(Object obj) {
            this.owner = obj;
        }

        public String toString() {
            return "LockedQueue[" + this.owner + ']';
        }
    }

    private static final class d extends kotlinx.coroutines.internal.c<c> {

        /* renamed from: b  reason: collision with root package name */
        public final C0087c f3627b;

        public d(C0087c cVar) {
            this.f3627b = cVar;
        }

        /* renamed from: h */
        public void d(c cVar, Object obj) {
            androidx.concurrent.futures.b.a(c.f3619a, cVar, this, obj == null ? d.f3635f : this.f3627b);
        }

        /* renamed from: i */
        public Object g(c cVar) {
            if (this.f3627b.C()) {
                return null;
            }
            return d.f3631b;
        }
    }

    static final class e extends j implements l<Throwable, s> {

        /* renamed from: d  reason: collision with root package name */
        final /* synthetic */ c f3628d;

        /* renamed from: e  reason: collision with root package name */
        final /* synthetic */ Object f3629e;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        e(c cVar, Object obj) {
            super(1);
            this.f3628d = cVar;
            this.f3629e = obj;
        }

        public final void b(Throwable th) {
            this.f3628d.a(this.f3629e);
        }

        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            b((Throwable) obj);
            return s.f271a;
        }
    }

    public c(boolean z3) {
        this._state = z3 ? d.f3634e : d.f3635f;
    }

    private final Object d(Object obj, c3.d<? super s> dVar) {
        n b4 = p.b(c.b(dVar));
        a aVar = new a(obj, b4);
        while (true) {
            Object obj2 = this._state;
            if (obj2 instanceof a) {
                a aVar2 = (a) obj2;
                if (aVar2.f3618a != d.f3633d) {
                    androidx.concurrent.futures.b.a(f3619a, this, obj2, new C0087c(aVar2.f3618a));
                } else {
                    if (androidx.concurrent.futures.b.a(f3619a, this, obj2, obj == null ? d.f3634e : new a(obj))) {
                        b4.n(s.f271a, new e(this, obj));
                        break;
                    }
                }
            } else if (obj2 instanceof C0087c) {
                C0087c cVar = (C0087c) obj2;
                if (cVar.owner != obj) {
                    cVar.l(aVar);
                    if (this._state == obj2 || !aVar.D()) {
                        p.c(b4, aVar);
                    } else {
                        aVar = new a(obj, b4);
                    }
                } else {
                    throw new IllegalStateException(("Already locked by " + obj).toString());
                }
            } else if (obj2 instanceof w) {
                ((w) obj2).c(this);
            } else {
                throw new IllegalStateException(("Illegal state " + obj2).toString());
            }
        }
        Object s4 = b4.s();
        if (s4 == d.c()) {
            h.c(dVar);
        }
        return s4 == d.c() ? s4 : s.f271a;
    }

    public void a(Object obj) {
        while (true) {
            Object obj2 = this._state;
            boolean z3 = true;
            if (obj2 instanceof a) {
                a aVar = (a) obj2;
                if (obj == null) {
                    if (aVar.f3618a == d.f3633d) {
                        z3 = false;
                    }
                    if (!z3) {
                        throw new IllegalStateException("Mutex is not locked".toString());
                    }
                } else {
                    if (aVar.f3618a != obj) {
                        z3 = false;
                    }
                    if (!z3) {
                        throw new IllegalStateException(("Mutex is locked by " + aVar.f3618a + " but expected " + obj).toString());
                    }
                }
                if (androidx.concurrent.futures.b.a(f3619a, this, obj2, d.f3635f)) {
                    return;
                }
            } else if (obj2 instanceof w) {
                ((w) obj2).c(this);
            } else if (obj2 instanceof C0087c) {
                if (obj != null) {
                    C0087c cVar = (C0087c) obj2;
                    if (cVar.owner != obj) {
                        z3 = false;
                    }
                    if (!z3) {
                        throw new IllegalStateException(("Mutex is locked by " + cVar.owner + " but expected " + obj).toString());
                    }
                }
                C0087c cVar2 = (C0087c) obj2;
                kotlinx.coroutines.internal.o y4 = cVar2.y();
                if (y4 == null) {
                    d dVar = new d(cVar2);
                    if (androidx.concurrent.futures.b.a(f3619a, this, obj2, dVar) && dVar.c(this) == null) {
                        return;
                    }
                } else {
                    b bVar = (b) y4;
                    if (bVar.E()) {
                        Object obj3 = bVar.f3625g;
                        if (obj3 == null) {
                            obj3 = d.f3632c;
                        }
                        cVar2.owner = obj3;
                        bVar.C();
                        return;
                    }
                }
            } else {
                throw new IllegalStateException(("Illegal state " + obj2).toString());
            }
        }
    }

    public Object b(Object obj, c3.d<? super s> dVar) {
        if (e(obj)) {
            return s.f271a;
        }
        Object d4 = d(obj, dVar);
        return d4 == d.c() ? d4 : s.f271a;
    }

    public boolean c() {
        while (true) {
            Object obj = this._state;
            if (obj instanceof a) {
                return ((a) obj).f3618a != d.f3633d;
            }
            if (obj instanceof C0087c) {
                return true;
            }
            if (obj instanceof w) {
                ((w) obj).c(this);
            } else {
                throw new IllegalStateException(("Illegal state " + obj).toString());
            }
        }
    }

    public boolean e(Object obj) {
        while (true) {
            Object obj2 = this._state;
            boolean z3 = true;
            if (obj2 instanceof a) {
                if (((a) obj2).f3618a != d.f3633d) {
                    return false;
                }
                if (androidx.concurrent.futures.b.a(f3619a, this, obj2, obj == null ? d.f3634e : new a(obj))) {
                    return true;
                }
            } else if (obj2 instanceof C0087c) {
                if (((C0087c) obj2).owner == obj) {
                    z3 = false;
                }
                if (z3) {
                    return false;
                }
                throw new IllegalStateException(("Already locked by " + obj).toString());
            } else if (obj2 instanceof w) {
                ((w) obj2).c(this);
            } else {
                throw new IllegalStateException(("Illegal state " + obj2).toString());
            }
        }
    }

    public String toString() {
        StringBuilder sb;
        Object obj;
        while (true) {
            Object obj2 = this._state;
            if (obj2 instanceof a) {
                sb = new StringBuilder();
                sb.append("Mutex[");
                obj = ((a) obj2).f3618a;
                break;
            } else if (obj2 instanceof w) {
                ((w) obj2).c(this);
            } else if (obj2 instanceof C0087c) {
                sb = new StringBuilder();
                sb.append("Mutex[");
                obj = ((C0087c) obj2).owner;
            } else {
                throw new IllegalStateException(("Illegal state " + obj2).toString());
            }
        }
        sb.append(obj);
        sb.append(']');
        return sb.toString();
    }
}
