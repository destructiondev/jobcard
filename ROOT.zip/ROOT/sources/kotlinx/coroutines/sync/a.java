package kotlinx.coroutines.sync;

final class a {

    /* renamed from: a  reason: collision with root package name */
    public final Object f3618a;

    public a(Object obj) {
        this.f3618a = obj;
    }

    public String toString() {
        return "Empty[" + this.f3618a + ']';
    }
}
