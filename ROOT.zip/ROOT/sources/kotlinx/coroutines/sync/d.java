package kotlinx.coroutines.sync;

import kotlinx.coroutines.internal.b0;

public final class d {

    /* renamed from: a  reason: collision with root package name */
    private static final b0 f3630a = new b0("LOCK_FAIL");
    /* access modifiers changed from: private */

    /* renamed from: b  reason: collision with root package name */
    public static final b0 f3631b = new b0("UNLOCK_FAIL");
    /* access modifiers changed from: private */

    /* renamed from: c  reason: collision with root package name */
    public static final b0 f3632c;
    /* access modifiers changed from: private */

    /* renamed from: d  reason: collision with root package name */
    public static final b0 f3633d;
    /* access modifiers changed from: private */

    /* renamed from: e  reason: collision with root package name */
    public static final a f3634e;
    /* access modifiers changed from: private */

    /* renamed from: f  reason: collision with root package name */
    public static final a f3635f;

    static {
        b0 b0Var = new b0("LOCKED");
        f3632c = b0Var;
        b0 b0Var2 = new b0("UNLOCKED");
        f3633d = b0Var2;
        f3634e = new a(b0Var);
        f3635f = new a(b0Var2);
    }

    public static final b a(boolean z3) {
        return new c(z3);
    }

    public static /* synthetic */ b b(boolean z3, int i4, Object obj) {
        if ((i4 & 1) != 0) {
            z3 = false;
        }
        return a(z3);
    }
}
