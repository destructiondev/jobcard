package kotlinx.coroutines.sync;

import a3.s;
import c3.d;

public interface b {

    public static final class a {
        public static /* synthetic */ void a(b bVar, Object obj, int i4, Object obj2) {
            if (obj2 == null) {
                if ((i4 & 1) != 0) {
                    obj = null;
                }
                bVar.a(obj);
                return;
            }
            throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: unlock");
        }
    }

    void a(Object obj);

    Object b(Object obj, d<? super s> dVar);

    boolean c();
}
