package kotlinx.coroutines.flow;

import a3.s;
import c3.d;
import kotlin.coroutines.jvm.internal.f;
import kotlin.jvm.internal.r;

final /* synthetic */ class i {

    public static final class a implements c<T> {

        /* renamed from: d  reason: collision with root package name */
        final /* synthetic */ r f3473d;

        public a(r rVar) {
            this.f3473d = rVar;
        }

        public Object emit(T t4, d<? super s> dVar) {
            this.f3473d.f3455d = t4;
            throw new v3.a(this);
        }
    }

    @f(c = "kotlinx.coroutines.flow.FlowKt__ReduceKt", f = "Reduce.kt", l = {183}, m = "first")
    static final class b<T> extends kotlin.coroutines.jvm.internal.d {

        /* renamed from: d  reason: collision with root package name */
        Object f3474d;

        /* renamed from: e  reason: collision with root package name */
        Object f3475e;

        /* renamed from: f  reason: collision with root package name */
        /* synthetic */ Object f3476f;

        /* renamed from: g  reason: collision with root package name */
        int f3477g;

        b(d<? super b> dVar) {
            super(dVar);
        }

        public final Object invokeSuspend(Object obj) {
            this.f3476f = obj;
            this.f3477g |= Integer.MIN_VALUE;
            return d.d((b) null, this);
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:15:0x003b  */
    /* JADX WARNING: Removed duplicated region for block: B:26:0x0068 A[RETURN] */
    /* JADX WARNING: Removed duplicated region for block: B:27:0x0069  */
    /* JADX WARNING: Removed duplicated region for block: B:8:0x0023  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static final <T> java.lang.Object a(kotlinx.coroutines.flow.b<? extends T> r4, c3.d<? super T> r5) {
        /*
            boolean r0 = r5 instanceof kotlinx.coroutines.flow.i.b
            if (r0 == 0) goto L_0x0013
            r0 = r5
            kotlinx.coroutines.flow.i$b r0 = (kotlinx.coroutines.flow.i.b) r0
            int r1 = r0.f3477g
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L_0x0013
            int r1 = r1 - r2
            r0.f3477g = r1
            goto L_0x0018
        L_0x0013:
            kotlinx.coroutines.flow.i$b r0 = new kotlinx.coroutines.flow.i$b
            r0.<init>(r5)
        L_0x0018:
            java.lang.Object r5 = r0.f3476f
            java.lang.Object r1 = d3.d.c()
            int r2 = r0.f3477g
            r3 = 1
            if (r2 == 0) goto L_0x003b
            if (r2 != r3) goto L_0x0033
            java.lang.Object r4 = r0.f3475e
            kotlinx.coroutines.flow.i$a r4 = (kotlinx.coroutines.flow.i.a) r4
            java.lang.Object r0 = r0.f3474d
            kotlin.jvm.internal.r r0 = (kotlin.jvm.internal.r) r0
            a3.n.b(r5)     // Catch:{ a -> 0x0031 }
            goto L_0x0062
        L_0x0031:
            r5 = move-exception
            goto L_0x005f
        L_0x0033:
            java.lang.IllegalStateException r4 = new java.lang.IllegalStateException
            java.lang.String r5 = "call to 'resume' before 'invoke' with coroutine"
            r4.<init>(r5)
            throw r4
        L_0x003b:
            a3.n.b(r5)
            kotlin.jvm.internal.r r5 = new kotlin.jvm.internal.r
            r5.<init>()
            kotlinx.coroutines.internal.b0 r2 = v3.h.f4627a
            r5.f3455d = r2
            kotlinx.coroutines.flow.i$a r2 = new kotlinx.coroutines.flow.i$a
            r2.<init>(r5)
            r0.f3474d = r5     // Catch:{ a -> 0x005b }
            r0.f3475e = r2     // Catch:{ a -> 0x005b }
            r0.f3477g = r3     // Catch:{ a -> 0x005b }
            java.lang.Object r4 = r4.a(r2, r0)     // Catch:{ a -> 0x005b }
            if (r4 != r1) goto L_0x0059
            return r1
        L_0x0059:
            r0 = r5
            goto L_0x0062
        L_0x005b:
            r4 = move-exception
            r0 = r5
            r5 = r4
            r4 = r2
        L_0x005f:
            v3.f.a(r5, r4)
        L_0x0062:
            T r4 = r0.f3455d
            kotlinx.coroutines.internal.b0 r5 = v3.h.f4627a
            if (r4 == r5) goto L_0x0069
            return r4
        L_0x0069:
            java.util.NoSuchElementException r4 = new java.util.NoSuchElementException
            java.lang.String r5 = "Expected at least one element"
            r4.<init>(r5)
            throw r4
        */
        throw new UnsupportedOperationException("Method not decompiled: kotlinx.coroutines.flow.i.a(kotlinx.coroutines.flow.b, c3.d):java.lang.Object");
    }
}
