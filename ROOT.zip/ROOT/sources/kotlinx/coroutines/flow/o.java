package kotlinx.coroutines.flow;

import a3.s;
import c3.d;
import j3.p;
import kotlin.coroutines.jvm.internal.f;

public final class o<T> implements c<T> {

    /* renamed from: d  reason: collision with root package name */
    private final c<T> f3491d;

    /* renamed from: e  reason: collision with root package name */
    private final p<c<? super T>, d<? super s>, Object> f3492e;

    @f(c = "kotlinx.coroutines.flow.SubscribedFlowCollector", f = "Share.kt", l = {419, 423}, m = "onSubscription")
    static final class a extends kotlin.coroutines.jvm.internal.d {

        /* renamed from: d  reason: collision with root package name */
        Object f3493d;

        /* renamed from: e  reason: collision with root package name */
        Object f3494e;

        /* renamed from: f  reason: collision with root package name */
        /* synthetic */ Object f3495f;

        /* renamed from: g  reason: collision with root package name */
        final /* synthetic */ o<T> f3496g;

        /* renamed from: h  reason: collision with root package name */
        int f3497h;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        a(o<T> oVar, d<? super a> dVar) {
            super(dVar);
            this.f3496g = oVar;
        }

        public final Object invokeSuspend(Object obj) {
            this.f3495f = obj;
            this.f3497h |= Integer.MIN_VALUE;
            return this.f3496g.a(this);
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:16:0x0040  */
    /* JADX WARNING: Removed duplicated region for block: B:24:0x0067  */
    /* JADX WARNING: Removed duplicated region for block: B:29:0x007a  */
    /* JADX WARNING: Removed duplicated region for block: B:8:0x0024  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final java.lang.Object a(c3.d<? super a3.s> r7) {
        /*
            r6 = this;
            boolean r0 = r7 instanceof kotlinx.coroutines.flow.o.a
            if (r0 == 0) goto L_0x0013
            r0 = r7
            kotlinx.coroutines.flow.o$a r0 = (kotlinx.coroutines.flow.o.a) r0
            int r1 = r0.f3497h
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L_0x0013
            int r1 = r1 - r2
            r0.f3497h = r1
            goto L_0x0018
        L_0x0013:
            kotlinx.coroutines.flow.o$a r0 = new kotlinx.coroutines.flow.o$a
            r0.<init>(r6, r7)
        L_0x0018:
            java.lang.Object r7 = r0.f3495f
            java.lang.Object r1 = d3.d.c()
            int r2 = r0.f3497h
            r3 = 2
            r4 = 1
            if (r2 == 0) goto L_0x0040
            if (r2 == r4) goto L_0x0034
            if (r2 != r3) goto L_0x002c
            a3.n.b(r7)
            goto L_0x0077
        L_0x002c:
            java.lang.IllegalStateException r7 = new java.lang.IllegalStateException
            java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
            r7.<init>(r0)
            throw r7
        L_0x0034:
            java.lang.Object r2 = r0.f3494e
            v3.i r2 = (v3.i) r2
            java.lang.Object r4 = r0.f3493d
            kotlinx.coroutines.flow.o r4 = (kotlinx.coroutines.flow.o) r4
            a3.n.b(r7)     // Catch:{ all -> 0x007d }
            goto L_0x005e
        L_0x0040:
            a3.n.b(r7)
            v3.i r2 = new v3.i
            kotlinx.coroutines.flow.c<T> r7 = r6.f3491d
            c3.g r5 = r0.getContext()
            r2.<init>(r7, r5)
            j3.p<kotlinx.coroutines.flow.c<? super T>, c3.d<? super a3.s>, java.lang.Object> r7 = r6.f3492e     // Catch:{ all -> 0x007d }
            r0.f3493d = r6     // Catch:{ all -> 0x007d }
            r0.f3494e = r2     // Catch:{ all -> 0x007d }
            r0.f3497h = r4     // Catch:{ all -> 0x007d }
            java.lang.Object r7 = r7.invoke(r2, r0)     // Catch:{ all -> 0x007d }
            if (r7 != r1) goto L_0x005d
            return r1
        L_0x005d:
            r4 = r6
        L_0x005e:
            r2.releaseIntercepted()
            kotlinx.coroutines.flow.c<T> r7 = r4.f3491d
            boolean r2 = r7 instanceof kotlinx.coroutines.flow.o
            if (r2 == 0) goto L_0x007a
            kotlinx.coroutines.flow.o r7 = (kotlinx.coroutines.flow.o) r7
            r2 = 0
            r0.f3493d = r2
            r0.f3494e = r2
            r0.f3497h = r3
            java.lang.Object r7 = r7.a(r0)
            if (r7 != r1) goto L_0x0077
            return r1
        L_0x0077:
            a3.s r7 = a3.s.f271a
            return r7
        L_0x007a:
            a3.s r7 = a3.s.f271a
            return r7
        L_0x007d:
            r7 = move-exception
            r2.releaseIntercepted()
            throw r7
        */
        throw new UnsupportedOperationException("Method not decompiled: kotlinx.coroutines.flow.o.a(c3.d):java.lang.Object");
    }

    public Object emit(T t4, d<? super s> dVar) {
        return this.f3491d.emit(t4, dVar);
    }
}
