package kotlinx.coroutines.flow;

import a3.s;
import c3.d;
import j3.p;

final /* synthetic */ class e {
    public static final <T> b<T> a(p<? super c<? super T>, ? super d<? super s>, ? extends Object> pVar) {
        return new k(pVar);
    }
}
