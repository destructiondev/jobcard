package kotlinx.coroutines.flow;

import a3.m;
import a3.s;
import androidx.concurrent.futures.b;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
import kotlin.coroutines.jvm.internal.h;
import kotlin.jvm.internal.i;
import v3.c;
import v3.d;

final class n extends d<l<?>> {

    /* renamed from: a  reason: collision with root package name */
    static final /* synthetic */ AtomicReferenceFieldUpdater f3490a = AtomicReferenceFieldUpdater.newUpdater(n.class, Object.class, "_state");
    volatile /* synthetic */ Object _state = null;

    /* renamed from: c */
    public boolean a(l<?> lVar) {
        if (this._state != null) {
            return false;
        }
        this._state = m.f3488a;
        return true;
    }

    public final Object d(c3.d<? super s> dVar) {
        s3.n nVar = new s3.n(c.b(dVar), 1);
        nVar.z();
        if (!b.a(f3490a, this, m.f3488a, nVar)) {
            m.a aVar = m.f265d;
            nVar.resumeWith(m.a(s.f271a));
        }
        Object s4 = nVar.s();
        if (s4 == d.c()) {
            h.c(dVar);
        }
        return s4 == d.c() ? s4 : s.f271a;
    }

    /* renamed from: e */
    public c3.d<s>[] b(l<?> lVar) {
        this._state = null;
        return c.f4622a;
    }

    public final void f() {
        while (true) {
            Object obj = this._state;
            if (obj != null && obj != m.f3489b) {
                if (obj == m.f3488a) {
                    if (b.a(f3490a, this, obj, m.f3489b)) {
                        return;
                    }
                } else if (b.a(f3490a, this, obj, m.f3488a)) {
                    m.a aVar = m.f265d;
                    ((s3.n) obj).resumeWith(m.a(s.f271a));
                    return;
                }
            } else {
                return;
            }
        }
    }

    public final boolean g() {
        Object andSet = f3490a.getAndSet(this, m.f3488a);
        i.b(andSet);
        return andSet == m.f3489b;
    }
}
