package kotlinx.coroutines.flow;

import a3.s;
import j3.p;

public final class d {
    public static final <T> b<T> a(b<? extends T> bVar, p<? super T, ? super c3.d<? super Boolean>, ? extends Object> pVar) {
        return h.a(bVar, pVar);
    }

    public static final <T> Object b(c<? super T> cVar, b<? extends T> bVar, c3.d<? super s> dVar) {
        return f.a(cVar, bVar, dVar);
    }

    public static final void c(c<?> cVar) {
        g.a(cVar);
    }

    public static final <T> Object d(b<? extends T> bVar, c3.d<? super T> dVar) {
        return i.a(bVar, dVar);
    }

    public static final <T> b<T> e(p<? super c<? super T>, ? super c3.d<? super s>, ? extends Object> pVar) {
        return e.a(pVar);
    }
}
