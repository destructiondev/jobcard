package kotlinx.coroutines.flow;

public interface j<T> extends b, c {
    T getValue();

    void setValue(T t4);
}
