package kotlinx.coroutines.flow;

final /* synthetic */ class g {
    public static final void a(c<?> cVar) {
        if (cVar instanceof p) {
            throw ((p) cVar).f3498d;
        }
    }
}
