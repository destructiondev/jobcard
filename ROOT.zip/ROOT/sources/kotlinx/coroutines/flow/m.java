package kotlinx.coroutines.flow;

import kotlinx.coroutines.internal.b0;
import v3.h;

public final class m {
    /* access modifiers changed from: private */

    /* renamed from: a  reason: collision with root package name */
    public static final b0 f3488a = new b0("NONE");
    /* access modifiers changed from: private */

    /* renamed from: b  reason: collision with root package name */
    public static final b0 f3489b = new b0("PENDING");

    public static final <T> j<T> a(T t4) {
        if (t4 == null) {
            t4 = h.f4627a;
        }
        return new l(t4);
    }
}
