package kotlinx.coroutines.flow;

import a3.s;
import c3.d;
import j3.p;
import kotlin.coroutines.jvm.internal.f;
import kotlin.jvm.internal.q;

final /* synthetic */ class h {

    public static final class a implements b<T> {

        /* renamed from: d  reason: collision with root package name */
        final /* synthetic */ b f3463d;

        /* renamed from: e  reason: collision with root package name */
        final /* synthetic */ p f3464e;

        public a(b bVar, p pVar) {
            this.f3463d = bVar;
            this.f3464e = pVar;
        }

        public Object a(c<? super T> cVar, d<? super s> dVar) {
            Object a4 = this.f3463d.a(new b(new q(), cVar, this.f3464e), dVar);
            return a4 == d.c() ? a4 : s.f271a;
        }
    }

    static final class b<T> implements c {

        /* renamed from: d  reason: collision with root package name */
        final /* synthetic */ q f3465d;

        /* renamed from: e  reason: collision with root package name */
        final /* synthetic */ c<T> f3466e;

        /* renamed from: f  reason: collision with root package name */
        final /* synthetic */ p<T, d<? super Boolean>, Object> f3467f;

        @f(c = "kotlinx.coroutines.flow.FlowKt__LimitKt$dropWhile$1$1", f = "Limit.kt", l = {37, 38, 40}, m = "emit")
        static final class a extends kotlin.coroutines.jvm.internal.d {

            /* renamed from: d  reason: collision with root package name */
            Object f3468d;

            /* renamed from: e  reason: collision with root package name */
            Object f3469e;

            /* renamed from: f  reason: collision with root package name */
            /* synthetic */ Object f3470f;

            /* renamed from: g  reason: collision with root package name */
            final /* synthetic */ b<T> f3471g;

            /* renamed from: h  reason: collision with root package name */
            int f3472h;

            /* JADX INFO: super call moved to the top of the method (can break code semantics) */
            a(b<? super T> bVar, d<? super a> dVar) {
                super(dVar);
                this.f3471g = bVar;
            }

            public final Object invokeSuspend(Object obj) {
                this.f3470f = obj;
                this.f3472h |= Integer.MIN_VALUE;
                return this.f3471g.emit(null, this);
            }
        }

        b(q qVar, c<? super T> cVar, p<? super T, ? super d<? super Boolean>, ? extends Object> pVar) {
            this.f3465d = qVar;
            this.f3466e = cVar;
            this.f3467f = pVar;
        }

        /* JADX WARNING: Removed duplicated region for block: B:16:0x0045  */
        /* JADX WARNING: Removed duplicated region for block: B:29:0x0074  */
        /* JADX WARNING: Removed duplicated region for block: B:34:0x008b  */
        /* JADX WARNING: Removed duplicated region for block: B:8:0x0025  */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public final java.lang.Object emit(T r7, c3.d<? super a3.s> r8) {
            /*
                r6 = this;
                boolean r0 = r8 instanceof kotlinx.coroutines.flow.h.b.a
                if (r0 == 0) goto L_0x0013
                r0 = r8
                kotlinx.coroutines.flow.h$b$a r0 = (kotlinx.coroutines.flow.h.b.a) r0
                int r1 = r0.f3472h
                r2 = -2147483648(0xffffffff80000000, float:-0.0)
                r3 = r1 & r2
                if (r3 == 0) goto L_0x0013
                int r1 = r1 - r2
                r0.f3472h = r1
                goto L_0x0018
            L_0x0013:
                kotlinx.coroutines.flow.h$b$a r0 = new kotlinx.coroutines.flow.h$b$a
                r0.<init>(r6, r8)
            L_0x0018:
                java.lang.Object r8 = r0.f3470f
                java.lang.Object r1 = d3.d.c()
                int r2 = r0.f3472h
                r3 = 3
                r4 = 2
                r5 = 1
                if (r2 == 0) goto L_0x0045
                if (r2 == r5) goto L_0x0041
                if (r2 == r4) goto L_0x0037
                if (r2 != r3) goto L_0x002f
                a3.n.b(r8)
                goto L_0x0088
            L_0x002f:
                java.lang.IllegalStateException r7 = new java.lang.IllegalStateException
                java.lang.String r8 = "call to 'resume' before 'invoke' with coroutine"
                r7.<init>(r8)
                throw r7
            L_0x0037:
                java.lang.Object r7 = r0.f3469e
                java.lang.Object r2 = r0.f3468d
                kotlinx.coroutines.flow.h$b r2 = (kotlinx.coroutines.flow.h.b) r2
                a3.n.b(r8)
                goto L_0x006c
            L_0x0041:
                a3.n.b(r8)
                goto L_0x0059
            L_0x0045:
                a3.n.b(r8)
                kotlin.jvm.internal.q r8 = r6.f3465d
                boolean r8 = r8.f3454d
                if (r8 == 0) goto L_0x005c
                kotlinx.coroutines.flow.c<T> r8 = r6.f3466e
                r0.f3472h = r5
                java.lang.Object r7 = r8.emit(r7, r0)
                if (r7 != r1) goto L_0x0059
                return r1
            L_0x0059:
                a3.s r7 = a3.s.f271a
                return r7
            L_0x005c:
                j3.p<T, c3.d<? super java.lang.Boolean>, java.lang.Object> r8 = r6.f3467f
                r0.f3468d = r6
                r0.f3469e = r7
                r0.f3472h = r4
                java.lang.Object r8 = r8.invoke(r7, r0)
                if (r8 != r1) goto L_0x006b
                return r1
            L_0x006b:
                r2 = r6
            L_0x006c:
                java.lang.Boolean r8 = (java.lang.Boolean) r8
                boolean r8 = r8.booleanValue()
                if (r8 != 0) goto L_0x008b
                kotlin.jvm.internal.q r8 = r2.f3465d
                r8.f3454d = r5
                kotlinx.coroutines.flow.c<T> r8 = r2.f3466e
                r2 = 0
                r0.f3468d = r2
                r0.f3469e = r2
                r0.f3472h = r3
                java.lang.Object r7 = r8.emit(r7, r0)
                if (r7 != r1) goto L_0x0088
                return r1
            L_0x0088:
                a3.s r7 = a3.s.f271a
                return r7
            L_0x008b:
                a3.s r7 = a3.s.f271a
                return r7
            */
            throw new UnsupportedOperationException("Method not decompiled: kotlinx.coroutines.flow.h.b.emit(java.lang.Object, c3.d):java.lang.Object");
        }
    }

    public static final <T> b<T> a(b<? extends T> bVar, p<? super T, ? super d<? super Boolean>, ? extends Object> pVar) {
        return new a(bVar, pVar);
    }
}
