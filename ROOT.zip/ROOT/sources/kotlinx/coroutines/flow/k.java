package kotlinx.coroutines.flow;

import a3.s;
import c3.d;
import j3.p;

final class k<T> extends a<T> {

    /* renamed from: d  reason: collision with root package name */
    private final p<c<? super T>, d<? super s>, Object> f3478d;

    public k(p<? super c<? super T>, ? super d<? super s>, ? extends Object> pVar) {
        this.f3478d = pVar;
    }

    public Object b(c<? super T> cVar, d<? super s> dVar) {
        Object invoke = this.f3478d.invoke(cVar, dVar);
        return invoke == d.c() ? invoke : s.f271a;
    }
}
