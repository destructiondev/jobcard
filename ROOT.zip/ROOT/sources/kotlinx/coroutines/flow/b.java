package kotlinx.coroutines.flow;

import a3.s;
import c3.d;

public interface b<T> {
    Object a(c<? super T> cVar, d<? super s> dVar);
}
