package kotlinx.coroutines.flow;

import a3.s;
import c3.d;

final /* synthetic */ class f {
    public static final <T> Object a(c<? super T> cVar, b<? extends T> bVar, d<? super s> dVar) {
        d.c(cVar);
        Object a4 = bVar.a(cVar, dVar);
        return a4 == d.c() ? a4 : s.f271a;
    }
}
