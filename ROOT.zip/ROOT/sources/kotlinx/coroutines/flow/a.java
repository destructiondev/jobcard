package kotlinx.coroutines.flow;

import a3.s;
import kotlin.coroutines.jvm.internal.d;
import kotlin.coroutines.jvm.internal.f;

public abstract class a<T> implements b<T> {

    @f(c = "kotlinx.coroutines.flow.AbstractFlow", f = "Flow.kt", l = {230}, m = "collect")
    /* renamed from: kotlinx.coroutines.flow.a$a  reason: collision with other inner class name */
    static final class C0084a extends d {

        /* renamed from: d  reason: collision with root package name */
        Object f3459d;

        /* renamed from: e  reason: collision with root package name */
        /* synthetic */ Object f3460e;

        /* renamed from: f  reason: collision with root package name */
        final /* synthetic */ a<T> f3461f;

        /* renamed from: g  reason: collision with root package name */
        int f3462g;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        C0084a(a<T> aVar, c3.d<? super C0084a> dVar) {
            super(dVar);
            this.f3461f = aVar;
        }

        public final Object invokeSuspend(Object obj) {
            this.f3460e = obj;
            this.f3462g |= Integer.MIN_VALUE;
            return this.f3461f.a((c) null, this);
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:15:0x0037  */
    /* JADX WARNING: Removed duplicated region for block: B:8:0x0023  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final java.lang.Object a(kotlinx.coroutines.flow.c<? super T> r6, c3.d<? super a3.s> r7) {
        /*
            r5 = this;
            boolean r0 = r7 instanceof kotlinx.coroutines.flow.a.C0084a
            if (r0 == 0) goto L_0x0013
            r0 = r7
            kotlinx.coroutines.flow.a$a r0 = (kotlinx.coroutines.flow.a.C0084a) r0
            int r1 = r0.f3462g
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L_0x0013
            int r1 = r1 - r2
            r0.f3462g = r1
            goto L_0x0018
        L_0x0013:
            kotlinx.coroutines.flow.a$a r0 = new kotlinx.coroutines.flow.a$a
            r0.<init>(r5, r7)
        L_0x0018:
            java.lang.Object r7 = r0.f3460e
            java.lang.Object r1 = d3.d.c()
            int r2 = r0.f3462g
            r3 = 1
            if (r2 == 0) goto L_0x0037
            if (r2 != r3) goto L_0x002f
            java.lang.Object r6 = r0.f3459d
            v3.i r6 = (v3.i) r6
            a3.n.b(r7)     // Catch:{ all -> 0x002d }
            goto L_0x004f
        L_0x002d:
            r7 = move-exception
            goto L_0x0059
        L_0x002f:
            java.lang.IllegalStateException r6 = new java.lang.IllegalStateException
            java.lang.String r7 = "call to 'resume' before 'invoke' with coroutine"
            r6.<init>(r7)
            throw r6
        L_0x0037:
            a3.n.b(r7)
            v3.i r7 = new v3.i
            c3.g r2 = r0.getContext()
            r7.<init>(r6, r2)
            r0.f3459d = r7     // Catch:{ all -> 0x0055 }
            r0.f3462g = r3     // Catch:{ all -> 0x0055 }
            java.lang.Object r6 = r5.b(r7, r0)     // Catch:{ all -> 0x0055 }
            if (r6 != r1) goto L_0x004e
            return r1
        L_0x004e:
            r6 = r7
        L_0x004f:
            r6.releaseIntercepted()
            a3.s r6 = a3.s.f271a
            return r6
        L_0x0055:
            r6 = move-exception
            r4 = r7
            r7 = r6
            r6 = r4
        L_0x0059:
            r6.releaseIntercepted()
            throw r7
        */
        throw new UnsupportedOperationException("Method not decompiled: kotlinx.coroutines.flow.a.a(kotlinx.coroutines.flow.c, c3.d):java.lang.Object");
    }

    public abstract Object b(c<? super T> cVar, c3.d<? super s> dVar);
}
