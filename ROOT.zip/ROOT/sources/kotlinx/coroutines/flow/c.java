package kotlinx.coroutines.flow;

import a3.s;
import c3.d;

public interface c<T> {
    Object emit(T t4, d<? super s> dVar);
}
