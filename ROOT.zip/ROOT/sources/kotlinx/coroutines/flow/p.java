package kotlinx.coroutines.flow;

import a3.s;
import c3.d;

public final class p implements c<Object> {

    /* renamed from: d  reason: collision with root package name */
    public final Throwable f3498d;

    public Object emit(Object obj, d<? super s> dVar) {
        throw this.f3498d;
    }
}
