package l2;

public interface a {
    void a();

    void b(b bVar);
}
