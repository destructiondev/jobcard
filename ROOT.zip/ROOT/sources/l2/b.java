package l2;

public interface b {
}
