package z;

import z2.a;

public interface b<T> extends a<T> {
}
