package z;

public final class a<T> implements z2.a<T> {

    /* renamed from: c  reason: collision with root package name */
    private static final Object f4987c = new Object();

    /* renamed from: a  reason: collision with root package name */
    private volatile z2.a<T> f4988a;

    /* renamed from: b  reason: collision with root package name */
    private volatile Object f4989b = f4987c;

    private a(z2.a<T> aVar) {
        this.f4988a = aVar;
    }

    public static <P extends z2.a<T>, T> z2.a<T> a(P p4) {
        d.b(p4);
        return p4 instanceof a ? p4 : new a(p4);
    }

    public static Object b(Object obj, Object obj2) {
        if (!(obj != f4987c) || obj == obj2) {
            return obj2;
        }
        throw new IllegalStateException("Scoped provider was invoked recursively returning different results: " + obj + " & " + obj2 + ". This is likely due to a circular dependency.");
    }

    public T get() {
        T t4 = this.f4989b;
        T t5 = f4987c;
        if (t4 == t5) {
            synchronized (this) {
                t4 = this.f4989b;
                if (t4 == t5) {
                    t4 = this.f4988a.get();
                    this.f4989b = b(this.f4989b, t4);
                    this.f4988a = null;
                }
            }
        }
        return t4;
    }
}
