package z;

public final class c<T> implements b<T> {

    /* renamed from: b  reason: collision with root package name */
    private static final c<Object> f4990b = new c<>((Object) null);

    /* renamed from: a  reason: collision with root package name */
    private final T f4991a;

    private c(T t4) {
        this.f4991a = t4;
    }

    public static <T> b<T> a(T t4) {
        return new c(d.c(t4, "instance cannot be null"));
    }

    public T get() {
        return this.f4991a;
    }
}
