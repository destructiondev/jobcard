package z;

import java.util.Objects;

public final class d {
    public static <T> void a(T t4, Class<T> cls) {
        if (t4 == null) {
            throw new IllegalStateException(cls.getCanonicalName() + " must be set");
        }
    }

    public static <T> T b(T t4) {
        Objects.requireNonNull(t4);
        return t4;
    }

    public static <T> T c(T t4, String str) {
        Objects.requireNonNull(t4, str);
        return t4;
    }
}
