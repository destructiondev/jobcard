package x1;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import p1.c;
import r0.b;

public class a {

    /* renamed from: a  reason: collision with root package name */
    private final Context f4929a;

    /* renamed from: b  reason: collision with root package name */
    private final SharedPreferences f4930b;

    /* renamed from: c  reason: collision with root package name */
    private final c f4931c;

    /* renamed from: d  reason: collision with root package name */
    private boolean f4932d = c();

    public a(Context context, String str, c cVar) {
        Context a4 = a(context);
        this.f4929a = a4;
        this.f4930b = a4.getSharedPreferences("com.google.firebase.common.prefs:" + str, 0);
        this.f4931c = cVar;
    }

    private static Context a(Context context) {
        return Build.VERSION.SDK_INT < 24 ? context : androidx.core.content.a.b(context);
    }

    private boolean c() {
        return this.f4930b.contains("firebase_data_collection_default_enabled") ? this.f4930b.getBoolean("firebase_data_collection_default_enabled", true) : d();
    }

    private boolean d() {
        ApplicationInfo applicationInfo;
        Bundle bundle;
        try {
            PackageManager packageManager = this.f4929a.getPackageManager();
            if (packageManager == null || (applicationInfo = packageManager.getApplicationInfo(this.f4929a.getPackageName(), 128)) == null || (bundle = applicationInfo.metaData) == null || !bundle.containsKey("firebase_data_collection_default_enabled")) {
                return true;
            }
            return applicationInfo.metaData.getBoolean("firebase_data_collection_default_enabled");
        } catch (PackageManager.NameNotFoundException unused) {
            return true;
        }
    }

    private synchronized void f(boolean z3) {
        if (this.f4932d != z3) {
            this.f4932d = z3;
            this.f4931c.a(new p1.a(b.class, new b(z3)));
        }
    }

    public synchronized boolean b() {
        return this.f4932d;
    }

    public synchronized void e(Boolean bool) {
        boolean equals;
        if (bool == null) {
            this.f4930b.edit().remove("firebase_data_collection_default_enabled").apply();
            equals = d();
        } else {
            equals = Boolean.TRUE.equals(bool);
            this.f4930b.edit().putBoolean("firebase_data_collection_default_enabled", equals).apply();
        }
        f(equals);
    }
}
