package m;

import j3.l;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;
import kotlin.jvm.internal.e;
import kotlin.jvm.internal.i;
import kotlin.jvm.internal.j;
import m.d;

public final class a extends d {

    /* renamed from: a  reason: collision with root package name */
    private final Map<d.a<?>, Object> f3668a;

    /* renamed from: b  reason: collision with root package name */
    private final AtomicBoolean f3669b;

    /* renamed from: m.a$a  reason: collision with other inner class name */
    static final class C0090a extends j implements l<Map.Entry<d.a<?>, Object>, CharSequence> {

        /* renamed from: d  reason: collision with root package name */
        public static final C0090a f3670d = new C0090a();

        C0090a() {
            super(1);
        }

        /* renamed from: b */
        public final CharSequence invoke(Map.Entry<d.a<?>, Object> entry) {
            i.e(entry, "entry");
            return "  " + entry.getKey().a() + " = " + entry.getValue();
        }
    }

    public a() {
        this((Map) null, false, 3, (e) null);
    }

    public a(Map<d.a<?>, Object> map, boolean z3) {
        i.e(map, "preferencesMap");
        this.f3668a = map;
        this.f3669b = new AtomicBoolean(z3);
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public /* synthetic */ a(Map map, boolean z3, int i4, e eVar) {
        this((i4 & 1) != 0 ? new LinkedHashMap() : map, (i4 & 2) != 0 ? true : z3);
    }

    public Map<d.a<?>, Object> a() {
        Map<d.a<?>, Object> unmodifiableMap = Collections.unmodifiableMap(this.f3668a);
        i.d(unmodifiableMap, "unmodifiableMap(preferencesMap)");
        return unmodifiableMap;
    }

    public <T> T b(d.a<T> aVar) {
        i.e(aVar, "key");
        return this.f3668a.get(aVar);
    }

    public final void e() {
        if (!(!this.f3669b.get())) {
            throw new IllegalStateException("Do mutate preferences once returned to DataStore.".toString());
        }
    }

    public boolean equals(Object obj) {
        if (obj instanceof a) {
            return i.a(this.f3668a, ((a) obj).f3668a);
        }
        return false;
    }

    public final void f() {
        this.f3669b.set(true);
    }

    public final void g(d.b<?>... bVarArr) {
        i.e(bVarArr, "pairs");
        e();
        for (d.b<?> bVar : bVarArr) {
            j(bVar.a(), bVar.b());
        }
    }

    public final <T> T h(d.a<T> aVar) {
        i.e(aVar, "key");
        e();
        return this.f3668a.remove(aVar);
    }

    public int hashCode() {
        return this.f3668a.hashCode();
    }

    public final <T> void i(d.a<T> aVar, T t4) {
        i.e(aVar, "key");
        j(aVar, t4);
    }

    public final void j(d.a<?> aVar, Object obj) {
        Map<d.a<?>, Object> map;
        i.e(aVar, "key");
        e();
        if (obj == null) {
            h(aVar);
            return;
        }
        if (obj instanceof Set) {
            map = this.f3668a;
            obj = Collections.unmodifiableSet(u.u((Iterable) obj));
            i.d(obj, "unmodifiableSet(value.toSet())");
        } else {
            map = this.f3668a;
        }
        map.put(aVar, obj);
    }

    public String toString() {
        return u.m(this.f3668a.entrySet(), ",\n", "{\n", "\n}", 0, (CharSequence) null, C0090a.f3670d, 24, (Object) null);
    }
}
