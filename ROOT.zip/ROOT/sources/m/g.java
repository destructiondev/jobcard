package m;

import a3.n;
import a3.s;
import c3.d;
import j3.p;
import kotlin.coroutines.jvm.internal.f;
import kotlin.coroutines.jvm.internal.k;

public final class g {

    @f(c = "androidx.datastore.preferences.core.PreferencesKt$edit$2", f = "Preferences.kt", l = {329}, m = "invokeSuspend")
    static final class a extends k implements p<d, d<? super d>, Object> {

        /* renamed from: d  reason: collision with root package name */
        int f3680d;

        /* renamed from: e  reason: collision with root package name */
        /* synthetic */ Object f3681e;

        /* renamed from: f  reason: collision with root package name */
        final /* synthetic */ p<a, d<? super s>, Object> f3682f;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        a(p<? super a, ? super d<? super s>, ? extends Object> pVar, d<? super a> dVar) {
            super(2, dVar);
            this.f3682f = pVar;
        }

        /* renamed from: c */
        public final Object invoke(d dVar, d<? super d> dVar2) {
            return ((a) create(dVar, dVar2)).invokeSuspend(s.f271a);
        }

        public final d<s> create(Object obj, d<?> dVar) {
            a aVar = new a(this.f3682f, dVar);
            aVar.f3681e = obj;
            return aVar;
        }

        public final Object invokeSuspend(Object obj) {
            Object c4 = d.c();
            int i4 = this.f3680d;
            if (i4 == 0) {
                n.b(obj);
                a c5 = ((d) this.f3681e).c();
                p<a, d<? super s>, Object> pVar = this.f3682f;
                this.f3681e = c5;
                this.f3680d = 1;
                return pVar.invoke(c5, this) == c4 ? c4 : c5;
            } else if (i4 == 1) {
                a aVar = (a) this.f3681e;
                n.b(obj);
                return aVar;
            } else {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
        }
    }

    public static final Object a(j.f<d> fVar, p<? super a, ? super d<? super s>, ? extends Object> pVar, d<? super d> dVar) {
        return fVar.a(new a(pVar, (d<? super a>) null), dVar);
    }
}
