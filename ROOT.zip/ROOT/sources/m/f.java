package m;

import java.util.Set;
import kotlin.jvm.internal.i;
import m.d;

public final class f {
    public static final d.a<Boolean> a(String str) {
        i.e(str, "name");
        return new d.a<>(str);
    }

    public static final d.a<Double> b(String str) {
        i.e(str, "name");
        return new d.a<>(str);
    }

    public static final d.a<Float> c(String str) {
        i.e(str, "name");
        return new d.a<>(str);
    }

    public static final d.a<Integer> d(String str) {
        i.e(str, "name");
        return new d.a<>(str);
    }

    public static final d.a<Long> e(String str) {
        i.e(str, "name");
        return new d.a<>(str);
    }

    public static final d.a<String> f(String str) {
        i.e(str, "name");
        return new d.a<>(str);
    }

    public static final d.a<Set<String>> g(String str) {
        i.e(str, "name");
        return new d.a<>(str);
    }
}
