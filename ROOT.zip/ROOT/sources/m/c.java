package m;

import j.d;
import j.f;
import j.g;
import java.io.File;
import java.util.List;
import k.b;
import kotlin.jvm.internal.i;
import kotlin.jvm.internal.j;
import s3.l0;

public final class c {

    /* renamed from: a  reason: collision with root package name */
    public static final c f3675a = new c();

    static final class a extends j implements j3.a<File> {

        /* renamed from: d  reason: collision with root package name */
        final /* synthetic */ j3.a<File> f3676d;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        a(j3.a<? extends File> aVar) {
            super(0);
            this.f3676d = aVar;
        }

        /* renamed from: b */
        public final File invoke() {
            File invoke = this.f3676d.invoke();
            String a4 = f.a(invoke);
            h hVar = h.f3683a;
            if (i.a(a4, hVar.f())) {
                return invoke;
            }
            throw new IllegalStateException(("File extension for file: " + invoke + " does not match required extension for Preferences file: " + hVar.f()).toString());
        }
    }

    private c() {
    }

    public final f<d> a(b<d> bVar, List<? extends d<d>> list, l0 l0Var, j3.a<? extends File> aVar) {
        i.e(list, "migrations");
        i.e(l0Var, "scope");
        i.e(aVar, "produceFile");
        return new b(g.f3316a.a(h.f3683a, bVar, list, l0Var, new a(aVar)));
    }
}
