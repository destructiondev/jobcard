package m;

import a3.s;
import androidx.datastore.preferences.protobuf.y;
import j.k;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;
import java.util.Set;
import kotlin.jvm.internal.e;
import kotlin.jvm.internal.i;
import l.f;
import l.g;
import l.h;
import m.d;

public final class h implements k<d> {

    /* renamed from: a  reason: collision with root package name */
    public static final h f3683a = new h();

    /* renamed from: b  reason: collision with root package name */
    private static final String f3684b = "preferences_pb";

    public /* synthetic */ class a {

        /* renamed from: a  reason: collision with root package name */
        public static final /* synthetic */ int[] f3685a;

        static {
            int[] iArr = new int[h.b.values().length];
            iArr[h.b.BOOLEAN.ordinal()] = 1;
            iArr[h.b.FLOAT.ordinal()] = 2;
            iArr[h.b.DOUBLE.ordinal()] = 3;
            iArr[h.b.INTEGER.ordinal()] = 4;
            iArr[h.b.LONG.ordinal()] = 5;
            iArr[h.b.STRING.ordinal()] = 6;
            iArr[h.b.STRING_SET.ordinal()] = 7;
            iArr[h.b.VALUE_NOT_SET.ordinal()] = 8;
            f3685a = iArr;
        }
    }

    private h() {
    }

    private final void d(String str, l.h hVar, a aVar) {
        Object obj;
        d.a aVar2;
        h.b b02 = hVar.b0();
        switch (b02 == null ? -1 : a.f3685a[b02.ordinal()]) {
            case -1:
                throw new j.a("Value case is null.", (Throwable) null, 2, (e) null);
            case 1:
                aVar2 = f.a(str);
                obj = Boolean.valueOf(hVar.T());
                break;
            case 2:
                aVar2 = f.c(str);
                obj = Float.valueOf(hVar.W());
                break;
            case 3:
                aVar2 = f.b(str);
                obj = Double.valueOf(hVar.V());
                break;
            case 4:
                aVar2 = f.d(str);
                obj = Integer.valueOf(hVar.X());
                break;
            case 5:
                aVar2 = f.e(str);
                obj = Long.valueOf(hVar.Y());
                break;
            case 6:
                aVar2 = f.f(str);
                obj = hVar.Z();
                i.d(obj, "value.string");
                break;
            case l.h.DOUBLE_FIELD_NUMBER:
                aVar2 = f.g(str);
                List<String> Q = hVar.a0().Q();
                i.d(Q, "value.stringSet.stringsList");
                obj = u.u(Q);
                break;
            case 8:
                throw new j.a("Value not set.", (Throwable) null, 2, (e) null);
            default:
                throw new a3.k();
        }
        aVar.i(aVar2, obj);
    }

    private final l.h g(Object obj) {
        y q4;
        String str;
        if (obj instanceof Boolean) {
            q4 = l.h.c0().y(((Boolean) obj).booleanValue()).a();
            str = "newBuilder().setBoolean(value).build()";
        } else if (obj instanceof Float) {
            q4 = l.h.c0().A(((Number) obj).floatValue()).a();
            str = "newBuilder().setFloat(value).build()";
        } else if (obj instanceof Double) {
            q4 = l.h.c0().z(((Number) obj).doubleValue()).a();
            str = "newBuilder().setDouble(value).build()";
        } else if (obj instanceof Integer) {
            q4 = l.h.c0().B(((Number) obj).intValue()).a();
            str = "newBuilder().setInteger(value).build()";
        } else if (obj instanceof Long) {
            q4 = l.h.c0().C(((Number) obj).longValue()).a();
            str = "newBuilder().setLong(value).build()";
        } else if (obj instanceof String) {
            q4 = l.h.c0().D((String) obj).a();
            str = "newBuilder().setString(value).build()";
        } else if (obj instanceof Set) {
            q4 = l.h.c0().E(g.R().y((Set) obj)).a();
            str = "newBuilder().setStringSet(\n                    StringSet.newBuilder().addAllStrings(value as Set<String>)\n                ).build()";
        } else {
            throw new IllegalStateException(i.k("PreferencesSerializer does not support type: ", obj.getClass().getName()));
        }
        i.d(q4, str);
        return (l.h) q4;
    }

    public Object c(InputStream inputStream, c3.d<? super d> dVar) {
        f a4 = l.d.f3644a.a(inputStream);
        a b4 = e.b(new d.b[0]);
        Map<String, l.h> O = a4.O();
        i.d(O, "preferencesProto.preferencesMap");
        for (Map.Entry next : O.entrySet()) {
            String str = (String) next.getKey();
            l.h hVar = (l.h) next.getValue();
            h hVar2 = f3683a;
            i.d(str, "name");
            i.d(hVar, "value");
            hVar2.d(str, hVar, b4);
        }
        return b4.d();
    }

    /* renamed from: e */
    public d b() {
        return e.a();
    }

    public final String f() {
        return f3684b;
    }

    /* renamed from: h */
    public Object a(d dVar, OutputStream outputStream, c3.d<? super s> dVar2) {
        Map<d.a<?>, Object> a4 = dVar.a();
        f.a R = f.R();
        for (Map.Entry next : a4.entrySet()) {
            R.y(((d.a) next.getKey()).a(), g(next.getValue()));
        }
        ((f) R.a()).r(outputStream);
        return s.f271a;
    }
}
