package m;

import a3.n;
import a3.s;
import c3.d;
import j.f;
import j3.p;
import kotlin.coroutines.jvm.internal.k;
import kotlin.jvm.internal.i;

public final class b implements f<d> {

    /* renamed from: a  reason: collision with root package name */
    private final f<d> f3671a;

    @kotlin.coroutines.jvm.internal.f(c = "androidx.datastore.preferences.core.PreferenceDataStore$updateData$2", f = "PreferenceDataStoreFactory.kt", l = {85}, m = "invokeSuspend")
    static final class a extends k implements p<d, d<? super d>, Object> {

        /* renamed from: d  reason: collision with root package name */
        int f3672d;

        /* renamed from: e  reason: collision with root package name */
        /* synthetic */ Object f3673e;

        /* renamed from: f  reason: collision with root package name */
        final /* synthetic */ p<d, d<? super d>, Object> f3674f;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        a(p<? super d, ? super d<? super d>, ? extends Object> pVar, d<? super a> dVar) {
            super(2, dVar);
            this.f3674f = pVar;
        }

        /* renamed from: c */
        public final Object invoke(d dVar, d<? super d> dVar2) {
            return ((a) create(dVar, dVar2)).invokeSuspend(s.f271a);
        }

        public final d<s> create(Object obj, d<?> dVar) {
            a aVar = new a(this.f3674f, dVar);
            aVar.f3673e = obj;
            return aVar;
        }

        public final Object invokeSuspend(Object obj) {
            Object c4 = d.c();
            int i4 = this.f3672d;
            if (i4 == 0) {
                n.b(obj);
                p<d, d<? super d>, Object> pVar = this.f3674f;
                this.f3672d = 1;
                obj = pVar.invoke((d) this.f3673e, this);
                if (obj == c4) {
                    return c4;
                }
            } else if (i4 == 1) {
                n.b(obj);
            } else {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            d dVar = (d) obj;
            ((a) dVar).f();
            return dVar;
        }
    }

    public b(f<d> fVar) {
        i.e(fVar, "delegate");
        this.f3671a = fVar;
    }

    public Object a(p<? super d, ? super d<? super d>, ? extends Object> pVar, d<? super d> dVar) {
        return this.f3671a.a(new a(pVar, (d<? super a>) null), dVar);
    }

    public kotlinx.coroutines.flow.b<d> getData() {
        return this.f3671a.getData();
    }
}
