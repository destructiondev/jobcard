package m;

import java.util.Map;
import kotlin.jvm.internal.i;

public abstract class d {

    public static final class a<T> {

        /* renamed from: a  reason: collision with root package name */
        private final String f3677a;

        public a(String str) {
            i.e(str, "name");
            this.f3677a = str;
        }

        public final String a() {
            return this.f3677a;
        }

        public boolean equals(Object obj) {
            if (obj instanceof a) {
                return i.a(this.f3677a, ((a) obj).f3677a);
            }
            return false;
        }

        public int hashCode() {
            return this.f3677a.hashCode();
        }

        public String toString() {
            return this.f3677a;
        }
    }

    public static final class b<T> {

        /* renamed from: a  reason: collision with root package name */
        private final a<T> f3678a;

        /* renamed from: b  reason: collision with root package name */
        private final T f3679b;

        public final a<T> a() {
            return this.f3678a;
        }

        public final T b() {
            return this.f3679b;
        }
    }

    public abstract Map<a<?>, Object> a();

    public abstract <T> T b(a<T> aVar);

    public final a c() {
        return new a(e0.m(a()), false);
    }

    public final d d() {
        return new a(e0.m(a()), true);
    }
}
