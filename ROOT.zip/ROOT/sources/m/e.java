package m;

import java.util.Arrays;
import java.util.Map;
import kotlin.jvm.internal.i;
import m.d;

public final class e {
    public static final d a() {
        return new a((Map) null, true, 1, (kotlin.jvm.internal.e) null);
    }

    public static final a b(d.b<?>... bVarArr) {
        i.e(bVarArr, "pairs");
        a aVar = new a((Map) null, false, 1, (kotlin.jvm.internal.e) null);
        aVar.g((d.b[]) Arrays.copyOf(bVarArr, bVarArr.length));
        return aVar;
    }
}
