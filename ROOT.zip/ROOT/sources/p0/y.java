package p0;

import java.util.concurrent.Executor;
import javax.annotation.Nullable;

final class y implements f0 {

    /* renamed from: a  reason: collision with root package name */
    private final Executor f3835a;
    /* access modifiers changed from: private */

    /* renamed from: b  reason: collision with root package name */
    public final Object f3836b = new Object();
    /* access modifiers changed from: private */
    @Nullable

    /* renamed from: c  reason: collision with root package name */
    public e f3837c;

    public y(Executor executor, e eVar) {
        this.f3835a = executor;
        this.f3837c = eVar;
    }

    public final void a(j jVar) {
        synchronized (this.f3836b) {
            if (this.f3837c != null) {
                this.f3835a.execute(new x(this, jVar));
            }
        }
    }
}
