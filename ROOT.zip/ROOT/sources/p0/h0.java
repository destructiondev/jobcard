package p0;

import java.util.concurrent.Executor;

final class h0 implements Executor {
    h0() {
    }

    public final void execute(Runnable runnable) {
        runnable.run();
    }
}
