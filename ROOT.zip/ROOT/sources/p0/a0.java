package p0;

import java.util.concurrent.Executor;
import javax.annotation.Nullable;

final class a0 implements f0 {

    /* renamed from: a  reason: collision with root package name */
    private final Executor f3782a;
    /* access modifiers changed from: private */

    /* renamed from: b  reason: collision with root package name */
    public final Object f3783b = new Object();
    /* access modifiers changed from: private */
    @Nullable

    /* renamed from: c  reason: collision with root package name */
    public f f3784c;

    public a0(Executor executor, f fVar) {
        this.f3782a = executor;
        this.f3784c = fVar;
    }

    public final void a(j jVar) {
        if (!jVar.m() && !jVar.k()) {
            synchronized (this.f3783b) {
                if (this.f3784c != null) {
                    this.f3782a.execute(new z(this, jVar));
                }
            }
        }
    }
}
