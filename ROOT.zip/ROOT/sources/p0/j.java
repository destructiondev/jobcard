package p0;

import java.util.concurrent.Executor;

public abstract class j<TResult> {
    public j<TResult> a(Executor executor, d dVar) {
        throw new UnsupportedOperationException("addOnCanceledListener is not implemented");
    }

    public j<TResult> b(Executor executor, e<TResult> eVar) {
        throw new UnsupportedOperationException("addOnCompleteListener is not implemented");
    }

    public j<TResult> c(e<TResult> eVar) {
        throw new UnsupportedOperationException("addOnCompleteListener is not implemented");
    }

    public abstract j<TResult> d(Executor executor, f fVar);

    public abstract j<TResult> e(Executor executor, g<? super TResult> gVar);

    public <TContinuationResult> j<TContinuationResult> f(Executor executor, b<TResult, TContinuationResult> bVar) {
        throw new UnsupportedOperationException("continueWith is not implemented");
    }

    public <TContinuationResult> j<TContinuationResult> g(b<TResult, TContinuationResult> bVar) {
        throw new UnsupportedOperationException("continueWith is not implemented");
    }

    public <TContinuationResult> j<TContinuationResult> h(Executor executor, b<TResult, j<TContinuationResult>> bVar) {
        throw new UnsupportedOperationException("continueWithTask is not implemented");
    }

    public abstract Exception i();

    public abstract TResult j();

    public abstract boolean k();

    public abstract boolean l();

    public abstract boolean m();

    public <TContinuationResult> j<TContinuationResult> n(Executor executor, i<TResult, TContinuationResult> iVar) {
        throw new UnsupportedOperationException("onSuccessTask is not implemented");
    }

    public <TContinuationResult> j<TContinuationResult> o(i<TResult, TContinuationResult> iVar) {
        throw new UnsupportedOperationException("onSuccessTask is not implemented");
    }
}
