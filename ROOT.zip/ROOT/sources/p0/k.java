package p0;

public class k<TResult> {

    /* renamed from: a  reason: collision with root package name */
    private final j0 f3805a = new j0();

    public j<TResult> a() {
        return this.f3805a;
    }

    public void b(Exception exc) {
        this.f3805a.p(exc);
    }

    public void c(TResult tresult) {
        this.f3805a.q(tresult);
    }

    public boolean d(Exception exc) {
        return this.f3805a.s(exc);
    }

    public boolean e(TResult tresult) {
        return this.f3805a.t(tresult);
    }
}
