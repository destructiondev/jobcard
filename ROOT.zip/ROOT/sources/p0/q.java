package p0;

import java.util.concurrent.ExecutionException;

final class q<T> implements p<T> {

    /* renamed from: a  reason: collision with root package name */
    private final Object f3811a = new Object();

    /* renamed from: b  reason: collision with root package name */
    private final int f3812b;

    /* renamed from: c  reason: collision with root package name */
    private final j0 f3813c;

    /* renamed from: d  reason: collision with root package name */
    private int f3814d;

    /* renamed from: e  reason: collision with root package name */
    private int f3815e;

    /* renamed from: f  reason: collision with root package name */
    private int f3816f;

    /* renamed from: g  reason: collision with root package name */
    private Exception f3817g;

    /* renamed from: h  reason: collision with root package name */
    private boolean f3818h;

    public q(int i4, j0 j0Var) {
        this.f3812b = i4;
        this.f3813c = j0Var;
    }

    private final void a() {
        if (this.f3814d + this.f3815e + this.f3816f != this.f3812b) {
            return;
        }
        if (this.f3817g != null) {
            j0 j0Var = this.f3813c;
            int i4 = this.f3815e;
            int i5 = this.f3812b;
            j0Var.p(new ExecutionException(i4 + " out of " + i5 + " underlying tasks failed", this.f3817g));
        } else if (this.f3818h) {
            this.f3813c.r();
        } else {
            this.f3813c.q((Object) null);
        }
    }

    public final void b() {
        synchronized (this.f3811a) {
            this.f3816f++;
            this.f3818h = true;
            a();
        }
    }

    public final void c(Exception exc) {
        synchronized (this.f3811a) {
            this.f3815e++;
            this.f3817g = exc;
            a();
        }
    }

    public final void d(T t4) {
        synchronized (this.f3811a) {
            this.f3814d++;
            a();
        }
    }
}
