package p0;

final class v implements Runnable {

    /* renamed from: d  reason: collision with root package name */
    final /* synthetic */ w f3829d;

    v(w wVar) {
        this.f3829d = wVar;
    }

    public final void run() {
        synchronized (this.f3829d.f3831b) {
            w wVar = this.f3829d;
            if (wVar.f3832c != null) {
                wVar.f3832c.b();
            }
        }
    }
}
