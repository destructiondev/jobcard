package p0;

import java.util.concurrent.Executor;

final class s implements f0 {

    /* renamed from: a  reason: collision with root package name */
    private final Executor f3821a;
    /* access modifiers changed from: private */

    /* renamed from: b  reason: collision with root package name */
    public final b f3822b;
    /* access modifiers changed from: private */

    /* renamed from: c  reason: collision with root package name */
    public final j0 f3823c;

    public s(Executor executor, b bVar, j0 j0Var) {
        this.f3821a = executor;
        this.f3822b = bVar;
        this.f3823c = j0Var;
    }

    public final void a(j jVar) {
        this.f3821a.execute(new r(this, jVar));
    }
}
