package p0;

final class x implements Runnable {

    /* renamed from: d  reason: collision with root package name */
    final /* synthetic */ j f3833d;

    /* renamed from: e  reason: collision with root package name */
    final /* synthetic */ y f3834e;

    x(y yVar, j jVar) {
        this.f3834e = yVar;
        this.f3833d = jVar;
    }

    public final void run() {
        synchronized (this.f3834e.f3836b) {
            y yVar = this.f3834e;
            if (yVar.f3837c != null) {
                yVar.f3837c.a(this.f3833d);
            }
        }
    }
}
