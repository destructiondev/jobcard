package p0;

import java.util.concurrent.Executor;
import javax.annotation.Nullable;

final class c0 implements f0 {

    /* renamed from: a  reason: collision with root package name */
    private final Executor f3787a;
    /* access modifiers changed from: private */

    /* renamed from: b  reason: collision with root package name */
    public final Object f3788b = new Object();
    /* access modifiers changed from: private */
    @Nullable

    /* renamed from: c  reason: collision with root package name */
    public g f3789c;

    public c0(Executor executor, g gVar) {
        this.f3787a = executor;
        this.f3789c = gVar;
    }

    public final void a(j jVar) {
        if (jVar.m()) {
            synchronized (this.f3788b) {
                if (this.f3789c != null) {
                    this.f3787a.execute(new b0(this, jVar));
                }
            }
        }
    }
}
