package p0;

import java.util.concurrent.Executor;

final class e0<TResult, TContinuationResult> implements g<TContinuationResult>, f, d, f0 {

    /* renamed from: a  reason: collision with root package name */
    private final Executor f3792a;
    /* access modifiers changed from: private */

    /* renamed from: b  reason: collision with root package name */
    public final i f3793b;

    /* renamed from: c  reason: collision with root package name */
    private final j0 f3794c;

    public e0(Executor executor, i iVar, j0 j0Var) {
        this.f3792a = executor;
        this.f3793b = iVar;
        this.f3794c = j0Var;
    }

    public final void a(j jVar) {
        this.f3792a.execute(new d0(this, jVar));
    }

    public final void b() {
        this.f3794c.r();
    }

    public final void c(Exception exc) {
        this.f3794c.p(exc);
    }

    public final void d(TContinuationResult tcontinuationresult) {
        this.f3794c.q(tcontinuationresult);
    }
}
