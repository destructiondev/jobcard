package p0;

public class h extends RuntimeException {
    public h(Throwable th) {
        super(th);
    }
}
