package p0;

final class b0 implements Runnable {

    /* renamed from: d  reason: collision with root package name */
    final /* synthetic */ j f3785d;

    /* renamed from: e  reason: collision with root package name */
    final /* synthetic */ c0 f3786e;

    b0(c0 c0Var, j jVar) {
        this.f3786e = c0Var;
        this.f3785d = jVar;
    }

    public final void run() {
        synchronized (this.f3786e.f3788b) {
            c0 c0Var = this.f3786e;
            if (c0Var.f3789c != null) {
                c0Var.f3789c.d(this.f3785d.j());
            }
        }
    }
}
