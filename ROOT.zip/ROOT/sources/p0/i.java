package p0;

public interface i<TResult, TContinuationResult> {
    j<TContinuationResult> a(TResult tresult);
}
