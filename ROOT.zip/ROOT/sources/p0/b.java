package p0;

public interface b<TResult, TContinuationResult> {
    TContinuationResult a(j<TResult> jVar);
}
