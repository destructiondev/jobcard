package p0;

import android.os.Handler;
import android.os.Looper;
import java.util.concurrent.Executor;
import o0.a;

final class i0 implements Executor {

    /* renamed from: d  reason: collision with root package name */
    private final Handler f3798d = new a(Looper.getMainLooper());

    public final void execute(Runnable runnable) {
        this.f3798d.post(runnable);
    }
}
