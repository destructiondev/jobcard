package p0;

public final class c extends IllegalStateException {
    private c(String str, Throwable th) {
        super(str, th);
    }

    public static IllegalStateException a(j<?> jVar) {
        if (!jVar.l()) {
            return new IllegalStateException("DuplicateTaskCompletionException can only be created from completed Task.");
        }
        Exception i4 = jVar.i();
        return new c("Complete with: ".concat(i4 != null ? "failure" : jVar.m() ? "result ".concat(String.valueOf(jVar.j())) : jVar.k() ? "cancellation" : "unknown issue"), i4);
    }
}
