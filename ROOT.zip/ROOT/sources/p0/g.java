package p0;

public interface g<TResult> {
    void d(TResult tresult);
}
