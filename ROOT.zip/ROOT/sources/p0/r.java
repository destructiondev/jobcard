package p0;

final class r implements Runnable {

    /* renamed from: d  reason: collision with root package name */
    final /* synthetic */ j f3819d;

    /* renamed from: e  reason: collision with root package name */
    final /* synthetic */ s f3820e;

    r(s sVar, j jVar) {
        this.f3820e = sVar;
        this.f3819d = jVar;
    }

    public final void run() {
        if (this.f3819d.k()) {
            this.f3820e.f3823c.r();
            return;
        }
        try {
            this.f3820e.f3823c.q(this.f3820e.f3822b.a(this.f3819d));
        } catch (h e4) {
            if (e4.getCause() instanceof Exception) {
                this.f3820e.f3823c.p((Exception) e4.getCause());
            } else {
                this.f3820e.f3823c.p(e4);
            }
        } catch (Exception e5) {
            this.f3820e.f3823c.p(e5);
        }
    }
}
