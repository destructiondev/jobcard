package p0;

import java.util.concurrent.CancellationException;
import java.util.concurrent.Executor;

final class d0 implements Runnable {

    /* renamed from: d  reason: collision with root package name */
    final /* synthetic */ j f3790d;

    /* renamed from: e  reason: collision with root package name */
    final /* synthetic */ e0 f3791e;

    d0(e0 e0Var, j jVar) {
        this.f3791e = e0Var;
        this.f3790d = jVar;
    }

    public final void run() {
        try {
            j a4 = this.f3791e.f3793b.a(this.f3790d.j());
            if (a4 == null) {
                this.f3791e.c(new NullPointerException("Continuation returned null"));
                return;
            }
            Executor executor = l.f3809b;
            a4.e(executor, this.f3791e);
            a4.d(executor, this.f3791e);
            a4.a(executor, this.f3791e);
        } catch (h e4) {
            if (e4.getCause() instanceof Exception) {
                this.f3791e.c((Exception) e4.getCause());
            } else {
                this.f3791e.c(e4);
            }
        } catch (CancellationException unused) {
            this.f3791e.b();
        } catch (Exception e5) {
            this.f3791e.c(e5);
        }
    }
}
