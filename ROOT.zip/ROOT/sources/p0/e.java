package p0;

public interface e<TResult> {
    void a(j<TResult> jVar);
}
