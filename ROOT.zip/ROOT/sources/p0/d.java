package p0;

public interface d {
    void b();
}
