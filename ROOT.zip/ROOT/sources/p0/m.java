package p0;

import java.util.Arrays;
import java.util.Collection;
import java.util.Objects;
import java.util.concurrent.Callable;
import java.util.concurrent.CancellationException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;
import l0.b;

public final class m {
    public static <TResult> TResult a(j<TResult> jVar) {
        b.d();
        b.g(jVar, "Task must not be null");
        if (jVar.l()) {
            return g(jVar);
        }
        o oVar = new o((n) null);
        h(jVar, oVar);
        oVar.a();
        return g(jVar);
    }

    @Deprecated
    public static <TResult> j<TResult> b(Executor executor, Callable<TResult> callable) {
        b.g(executor, "Executor must not be null");
        b.g(callable, "Callback must not be null");
        j0 j0Var = new j0();
        executor.execute(new k0(j0Var, callable));
        return j0Var;
    }

    public static <TResult> j<TResult> c(Exception exc) {
        j0 j0Var = new j0();
        j0Var.p(exc);
        return j0Var;
    }

    public static <TResult> j<TResult> d(TResult tresult) {
        j0 j0Var = new j0();
        j0Var.q(tresult);
        return j0Var;
    }

    public static j<Void> e(Collection<? extends j<?>> collection) {
        if (collection == null || collection.isEmpty()) {
            return d((Object) null);
        }
        for (j requireNonNull : collection) {
            Objects.requireNonNull(requireNonNull, "null tasks are not accepted");
        }
        j0 j0Var = new j0();
        q qVar = new q(collection.size(), j0Var);
        for (j h4 : collection) {
            h(h4, qVar);
        }
        return j0Var;
    }

    public static j<Void> f(j<?>... jVarArr) {
        return (jVarArr == null || jVarArr.length == 0) ? d((Object) null) : e(Arrays.asList(jVarArr));
    }

    private static Object g(j jVar) {
        if (jVar.m()) {
            return jVar.j();
        }
        if (jVar.k()) {
            throw new CancellationException("Task is already canceled");
        }
        throw new ExecutionException(jVar.i());
    }

    private static void h(j jVar, p pVar) {
        Executor executor = l.f3809b;
        jVar.e(executor, pVar);
        jVar.d(executor, pVar);
        jVar.a(executor, pVar);
    }
}
