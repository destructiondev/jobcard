package p0;

interface p<T> extends g<T>, f, d {
}
