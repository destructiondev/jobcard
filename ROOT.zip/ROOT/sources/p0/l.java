package p0;

import java.util.concurrent.Executor;

public final class l {

    /* renamed from: a  reason: collision with root package name */
    public static final Executor f3808a = new i0();

    /* renamed from: b  reason: collision with root package name */
    static final Executor f3809b = new h0();
}
