package p0;

import java.util.concurrent.CountDownLatch;

final class o<T> implements p<T> {

    /* renamed from: a  reason: collision with root package name */
    private final CountDownLatch f3810a = new CountDownLatch(1);

    /* synthetic */ o(n nVar) {
    }

    public final void a() {
        this.f3810a.await();
    }

    public final void b() {
        this.f3810a.countDown();
    }

    public final void c(Exception exc) {
        this.f3810a.countDown();
    }

    public final void d(T t4) {
        this.f3810a.countDown();
    }
}
