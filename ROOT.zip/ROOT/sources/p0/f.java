package p0;

public interface f {
    void c(Exception exc);
}
