package p0;

import l0.b;

final class z implements Runnable {

    /* renamed from: d  reason: collision with root package name */
    final /* synthetic */ j f3838d;

    /* renamed from: e  reason: collision with root package name */
    final /* synthetic */ a0 f3839e;

    z(a0 a0Var, j jVar) {
        this.f3839e = a0Var;
        this.f3838d = jVar;
    }

    public final void run() {
        synchronized (this.f3839e.f3783b) {
            a0 a0Var = this.f3839e;
            if (a0Var.f3784c != null) {
                a0Var.f3784c.c((Exception) b.f(this.f3838d.i()));
            }
        }
    }
}
