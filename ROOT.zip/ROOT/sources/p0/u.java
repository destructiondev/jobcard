package p0;

import java.util.concurrent.Executor;

final class u<TResult, TContinuationResult> implements g<TContinuationResult>, f, d, f0 {

    /* renamed from: a  reason: collision with root package name */
    private final Executor f3826a;
    /* access modifiers changed from: private */

    /* renamed from: b  reason: collision with root package name */
    public final b f3827b;
    /* access modifiers changed from: private */

    /* renamed from: c  reason: collision with root package name */
    public final j0 f3828c;

    public u(Executor executor, b bVar, j0 j0Var) {
        this.f3826a = executor;
        this.f3827b = bVar;
        this.f3828c = j0Var;
    }

    public final void a(j jVar) {
        this.f3826a.execute(new t(this, jVar));
    }

    public final void b() {
        this.f3828c.r();
    }

    public final void c(Exception exc) {
        this.f3828c.p(exc);
    }

    public final void d(TContinuationResult tcontinuationresult) {
        this.f3828c.q(tcontinuationresult);
    }
}
