package p0;

import java.util.concurrent.CancellationException;
import java.util.concurrent.Executor;
import l0.b;

final class j0<TResult> extends j<TResult> {

    /* renamed from: a  reason: collision with root package name */
    private final Object f3799a = new Object();

    /* renamed from: b  reason: collision with root package name */
    private final g0 f3800b = new g0();

    /* renamed from: c  reason: collision with root package name */
    private boolean f3801c;

    /* renamed from: d  reason: collision with root package name */
    private volatile boolean f3802d;

    /* renamed from: e  reason: collision with root package name */
    private Object f3803e;

    /* renamed from: f  reason: collision with root package name */
    private Exception f3804f;

    j0() {
    }

    private final void u() {
        b.h(this.f3801c, "Task is not yet complete");
    }

    private final void v() {
        if (this.f3802d) {
            throw new CancellationException("Task is already canceled.");
        }
    }

    private final void w() {
        if (this.f3801c) {
            throw c.a(this);
        }
    }

    private final void x() {
        synchronized (this.f3799a) {
            if (this.f3801c) {
                this.f3800b.b(this);
            }
        }
    }

    public final j<TResult> a(Executor executor, d dVar) {
        this.f3800b.a(new w(executor, dVar));
        x();
        return this;
    }

    public final j<TResult> b(Executor executor, e<TResult> eVar) {
        this.f3800b.a(new y(executor, eVar));
        x();
        return this;
    }

    public final j<TResult> c(e<TResult> eVar) {
        this.f3800b.a(new y(l.f3808a, eVar));
        x();
        return this;
    }

    public final j<TResult> d(Executor executor, f fVar) {
        this.f3800b.a(new a0(executor, fVar));
        x();
        return this;
    }

    public final j<TResult> e(Executor executor, g<? super TResult> gVar) {
        this.f3800b.a(new c0(executor, gVar));
        x();
        return this;
    }

    public final <TContinuationResult> j<TContinuationResult> f(Executor executor, b<TResult, TContinuationResult> bVar) {
        j0 j0Var = new j0();
        this.f3800b.a(new s(executor, bVar, j0Var));
        x();
        return j0Var;
    }

    public final <TContinuationResult> j<TContinuationResult> g(b<TResult, TContinuationResult> bVar) {
        return f(l.f3808a, bVar);
    }

    public final <TContinuationResult> j<TContinuationResult> h(Executor executor, b<TResult, j<TContinuationResult>> bVar) {
        j0 j0Var = new j0();
        this.f3800b.a(new u(executor, bVar, j0Var));
        x();
        return j0Var;
    }

    public final Exception i() {
        Exception exc;
        synchronized (this.f3799a) {
            exc = this.f3804f;
        }
        return exc;
    }

    public final TResult j() {
        TResult tresult;
        synchronized (this.f3799a) {
            u();
            v();
            Exception exc = this.f3804f;
            if (exc == null) {
                tresult = this.f3803e;
            } else {
                throw new h(exc);
            }
        }
        return tresult;
    }

    public final boolean k() {
        return this.f3802d;
    }

    public final boolean l() {
        boolean z3;
        synchronized (this.f3799a) {
            z3 = this.f3801c;
        }
        return z3;
    }

    public final boolean m() {
        boolean z3;
        synchronized (this.f3799a) {
            z3 = false;
            if (this.f3801c && !this.f3802d && this.f3804f == null) {
                z3 = true;
            }
        }
        return z3;
    }

    public final <TContinuationResult> j<TContinuationResult> n(Executor executor, i<TResult, TContinuationResult> iVar) {
        j0 j0Var = new j0();
        this.f3800b.a(new e0(executor, iVar, j0Var));
        x();
        return j0Var;
    }

    public final <TContinuationResult> j<TContinuationResult> o(i<TResult, TContinuationResult> iVar) {
        Executor executor = l.f3808a;
        j0 j0Var = new j0();
        this.f3800b.a(new e0(executor, iVar, j0Var));
        x();
        return j0Var;
    }

    public final void p(Exception exc) {
        b.g(exc, "Exception must not be null");
        synchronized (this.f3799a) {
            w();
            this.f3801c = true;
            this.f3804f = exc;
        }
        this.f3800b.b(this);
    }

    public final void q(Object obj) {
        synchronized (this.f3799a) {
            w();
            this.f3801c = true;
            this.f3803e = obj;
        }
        this.f3800b.b(this);
    }

    public final boolean r() {
        synchronized (this.f3799a) {
            if (this.f3801c) {
                return false;
            }
            this.f3801c = true;
            this.f3802d = true;
            this.f3800b.b(this);
            return true;
        }
    }

    public final boolean s(Exception exc) {
        b.g(exc, "Exception must not be null");
        synchronized (this.f3799a) {
            if (this.f3801c) {
                return false;
            }
            this.f3801c = true;
            this.f3804f = exc;
            this.f3800b.b(this);
            return true;
        }
    }

    public final boolean t(Object obj) {
        synchronized (this.f3799a) {
            if (this.f3801c) {
                return false;
            }
            this.f3801c = true;
            this.f3803e = obj;
            this.f3800b.b(this);
            return true;
        }
    }
}
