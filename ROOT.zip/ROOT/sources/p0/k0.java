package p0;

import java.util.concurrent.Callable;

final class k0 implements Runnable {

    /* renamed from: d  reason: collision with root package name */
    final /* synthetic */ j0 f3806d;

    /* renamed from: e  reason: collision with root package name */
    final /* synthetic */ Callable f3807e;

    k0(j0 j0Var, Callable callable) {
        this.f3806d = j0Var;
        this.f3807e = callable;
    }

    public final void run() {
        try {
            this.f3806d.q(this.f3807e.call());
        } catch (Exception e4) {
            this.f3806d.p(e4);
        } catch (Throwable th) {
            this.f3806d.p(new RuntimeException(th));
        }
    }
}
