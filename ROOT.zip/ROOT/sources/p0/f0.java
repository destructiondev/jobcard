package p0;

interface f0<TResult> {
    void a(j jVar);
}
