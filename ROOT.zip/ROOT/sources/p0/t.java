package p0;

import java.util.concurrent.Executor;

final class t implements Runnable {

    /* renamed from: d  reason: collision with root package name */
    final /* synthetic */ j f3824d;

    /* renamed from: e  reason: collision with root package name */
    final /* synthetic */ u f3825e;

    t(u uVar, j jVar) {
        this.f3825e = uVar;
        this.f3824d = jVar;
    }

    public final void run() {
        try {
            j jVar = (j) this.f3825e.f3827b.a(this.f3824d);
            if (jVar == null) {
                this.f3825e.c(new NullPointerException("Continuation returned null"));
                return;
            }
            Executor executor = l.f3809b;
            jVar.e(executor, this.f3825e);
            jVar.d(executor, this.f3825e);
            jVar.a(executor, this.f3825e);
        } catch (h e4) {
            if (e4.getCause() instanceof Exception) {
                this.f3825e.f3828c.p((Exception) e4.getCause());
            } else {
                this.f3825e.f3828c.p(e4);
            }
        } catch (Exception e5) {
            this.f3825e.f3828c.p(e5);
        }
    }
}
