package p0;

import java.util.concurrent.Executor;
import javax.annotation.Nullable;

final class w implements f0 {

    /* renamed from: a  reason: collision with root package name */
    private final Executor f3830a;
    /* access modifiers changed from: private */

    /* renamed from: b  reason: collision with root package name */
    public final Object f3831b = new Object();
    /* access modifiers changed from: private */
    @Nullable

    /* renamed from: c  reason: collision with root package name */
    public d f3832c;

    public w(Executor executor, d dVar) {
        this.f3830a = executor;
        this.f3832c = dVar;
    }

    public final void a(j jVar) {
        if (jVar.k()) {
            synchronized (this.f3831b) {
                if (this.f3832c != null) {
                    this.f3830a.execute(new v(this));
                }
            }
        }
    }
}
