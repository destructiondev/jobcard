package y0;

import android.os.Bundle;

public interface a {
    void a(String str, Bundle bundle);
}
