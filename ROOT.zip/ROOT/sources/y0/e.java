package y0;

import android.os.Bundle;
import s0.a;

public class e implements a {

    /* renamed from: a  reason: collision with root package name */
    private final a f4972a;

    public e(a aVar) {
        this.f4972a = aVar;
    }

    public void a(String str, Bundle bundle) {
        this.f4972a.b("clx", str, bundle);
    }
}
