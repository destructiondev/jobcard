package y0;

import x0.f;
import z0.a;
import z0.b;

public class d implements b, b {

    /* renamed from: a  reason: collision with root package name */
    private a f4971a;

    public void a(a aVar) {
        this.f4971a = aVar;
        f.f().b("Registered Firebase Analytics event receiver for breadcrumbs");
    }
}
