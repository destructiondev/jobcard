package y0;

import android.os.Bundle;

public class f implements a {
    public void a(String str, Bundle bundle) {
        x0.f.f().b("Skipping logging Crashlytics event to Firebase, no Firebase Analytics");
    }
}
