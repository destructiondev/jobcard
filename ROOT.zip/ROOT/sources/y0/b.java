package y0;

public interface b {
}
