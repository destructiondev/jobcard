package org.chromium.support_lib_boundary;

import android.content.Intent;

public interface WebAuthnCallbackBoundaryInterface {
    void onResult(int i4, Intent intent);
}
