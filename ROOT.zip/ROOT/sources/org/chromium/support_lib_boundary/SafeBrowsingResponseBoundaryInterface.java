package org.chromium.support_lib_boundary;

public interface SafeBrowsingResponseBoundaryInterface {
    void backToSafety(boolean z3);

    void proceed(boolean z3);

    void showInterstitial(boolean z3);
}
