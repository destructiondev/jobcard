package org.chromium.support_lib_boundary;

public interface FeatureFlagHolderBoundaryInterface {
    String[] getSupportedFeatures();
}
