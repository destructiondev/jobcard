package w3;

import a3.m;
import a3.n;
import a3.s;
import c3.d;
import j3.l;
import j3.p;
import kotlinx.coroutines.internal.g;

public final class a {
    private static final void a(d<?> dVar, Throwable th) {
        m.a aVar = m.f265d;
        dVar.resumeWith(m.a(n.a(th)));
        throw th;
    }

    public static final void b(d<? super s> dVar, d<?> dVar2) {
        try {
            d b4 = c.b(dVar);
            m.a aVar = m.f265d;
            g.c(b4, m.a(s.f271a), (l) null, 2, (Object) null);
        } catch (Throwable th) {
            a(dVar2, th);
        }
    }

    public static final <R, T> void c(p<? super R, ? super d<? super T>, ? extends Object> pVar, R r4, d<? super T> dVar, l<? super Throwable, s> lVar) {
        try {
            d b4 = c.b(c.a(pVar, r4, dVar));
            m.a aVar = m.f265d;
            g.b(b4, m.a(s.f271a), lVar);
        } catch (Throwable th) {
            a(dVar, th);
        }
    }

    public static /* synthetic */ void d(p pVar, Object obj, d dVar, l lVar, int i4, Object obj2) {
        if ((i4 & 4) != 0) {
            lVar = null;
        }
        c(pVar, obj, dVar, lVar);
    }
}
