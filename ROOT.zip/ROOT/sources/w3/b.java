package w3;

import a3.m;
import a3.n;
import c3.d;
import c3.g;
import j3.p;
import kotlin.coroutines.jvm.internal.h;
import kotlin.jvm.internal.e;
import kotlin.jvm.internal.v;
import kotlinx.coroutines.internal.f0;
import kotlinx.coroutines.internal.z;
import s3.a0;
import s3.b2;

public final class b {
    public static final <R, T> void a(p<? super R, ? super d<? super T>, ? extends Object> pVar, R r4, d<? super T> dVar) {
        Object obj;
        g context;
        Object c4;
        d<? super T> a4 = h.a(dVar);
        try {
            context = dVar.getContext();
            c4 = f0.c(context, (Object) null);
            obj = ((p) v.a(pVar, 2)).invoke(r4, a4);
            f0.a(context, c4);
            if (obj != d.c()) {
                m.a aVar = m.f265d;
                a4.resumeWith(m.a(obj));
            }
        } catch (Throwable th) {
            m.a aVar2 = m.f265d;
            obj = n.a(th);
        }
    }

    public static final <T, R> Object b(z<? super T> zVar, R r4, p<? super R, ? super d<? super T>, ? extends Object> pVar) {
        Object obj;
        Object m02;
        try {
            obj = ((p) v.a(pVar, 2)).invoke(r4, zVar);
        } catch (Throwable th) {
            obj = new a0(th, false, 2, (e) null);
        }
        if (obj == d.c() || (m02 = zVar.m0(obj)) == b2.f4241b) {
            return d.c();
        }
        if (!(m02 instanceof a0)) {
            return b2.h(m02);
        }
        throw ((a0) m02).f4227a;
    }
}
