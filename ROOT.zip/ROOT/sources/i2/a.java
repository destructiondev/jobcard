package i2;

import android.content.Context;
import io.flutter.plugin.platform.h;
import io.flutter.view.d;
import r2.c;

public interface a {

    /* renamed from: i2.a$a  reason: collision with other inner class name */
    public interface C0065a {
        String a(String str);
    }

    public static class b {

        /* renamed from: a  reason: collision with root package name */
        private final Context f2205a;

        /* renamed from: b  reason: collision with root package name */
        private final io.flutter.embedding.engine.a f2206b;

        /* renamed from: c  reason: collision with root package name */
        private final c f2207c;

        /* renamed from: d  reason: collision with root package name */
        private final d f2208d;

        /* renamed from: e  reason: collision with root package name */
        private final h f2209e;

        /* renamed from: f  reason: collision with root package name */
        private final C0065a f2210f;

        /* renamed from: g  reason: collision with root package name */
        private final io.flutter.embedding.engine.d f2211g;

        public b(Context context, io.flutter.embedding.engine.a aVar, c cVar, d dVar, h hVar, C0065a aVar2, io.flutter.embedding.engine.d dVar2) {
            this.f2205a = context;
            this.f2206b = aVar;
            this.f2207c = cVar;
            this.f2208d = dVar;
            this.f2209e = hVar;
            this.f2210f = aVar2;
            this.f2211g = dVar2;
        }

        public Context a() {
            return this.f2205a;
        }

        public c b() {
            return this.f2207c;
        }

        public C0065a c() {
            return this.f2210f;
        }

        public h d() {
            return this.f2209e;
        }
    }

    void c(b bVar);

    void g(b bVar);
}
