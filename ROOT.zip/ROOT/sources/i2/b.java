package i2;

public interface b {
    void i(a aVar);
}
