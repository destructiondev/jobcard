package a3;

import kotlin.jvm.internal.i;
import n3.c;

public final class e implements Comparable<e> {

    /* renamed from: h  reason: collision with root package name */
    public static final a f256h = new a((kotlin.jvm.internal.e) null);

    /* renamed from: i  reason: collision with root package name */
    public static final e f257i = f.a();

    /* renamed from: d  reason: collision with root package name */
    private final int f258d;

    /* renamed from: e  reason: collision with root package name */
    private final int f259e;

    /* renamed from: f  reason: collision with root package name */
    private final int f260f;

    /* renamed from: g  reason: collision with root package name */
    private final int f261g;

    public static final class a {
        private a() {
        }

        public /* synthetic */ a(kotlin.jvm.internal.e eVar) {
            this();
        }
    }

    public e(int i4, int i5, int i6) {
        this.f258d = i4;
        this.f259e = i5;
        this.f260f = i6;
        this.f261g = d(i4, i5, i6);
    }

    private final int d(int i4, int i5, int i6) {
        boolean z3 = false;
        if (new c(0, 255).m(i4) && new c(0, 255).m(i5) && new c(0, 255).m(i6)) {
            z3 = true;
        }
        if (z3) {
            return (i4 << 16) + (i5 << 8) + i6;
        }
        throw new IllegalArgumentException(("Version components are out of range: " + i4 + '.' + i5 + '.' + i6).toString());
    }

    /* renamed from: b */
    public int compareTo(e eVar) {
        i.e(eVar, "other");
        return this.f261g - eVar.f261g;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        e eVar = obj instanceof e ? (e) obj : null;
        return eVar != null && this.f261g == eVar.f261g;
    }

    public int hashCode() {
        return this.f261g;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(this.f258d);
        sb.append('.');
        sb.append(this.f259e);
        sb.append('.');
        sb.append(this.f260f);
        return sb.toString();
    }
}
