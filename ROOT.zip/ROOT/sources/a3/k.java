package a3;

public class k extends RuntimeException {
}
