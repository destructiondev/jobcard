package a3;

public final class a extends b {
}
