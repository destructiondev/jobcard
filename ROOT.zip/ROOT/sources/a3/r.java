package a3;

public final class r extends RuntimeException {
    public r() {
    }

    public r(String str) {
        super(str);
    }
}
