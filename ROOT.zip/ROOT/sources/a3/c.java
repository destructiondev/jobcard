package a3;

public interface c<R> {
}
