package a3;

public final class q {

    /* renamed from: a  reason: collision with root package name */
    public static final q f270a = new q();

    private q() {
    }
}
