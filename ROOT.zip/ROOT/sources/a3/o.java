package a3;

import j3.a;
import java.io.Serializable;
import kotlin.jvm.internal.e;
import kotlin.jvm.internal.i;

final class o<T> implements g<T>, Serializable {

    /* renamed from: d  reason: collision with root package name */
    private a<? extends T> f267d;

    /* renamed from: e  reason: collision with root package name */
    private volatile Object f268e;

    /* renamed from: f  reason: collision with root package name */
    private final Object f269f;

    public o(a<? extends T> aVar, Object obj) {
        i.e(aVar, "initializer");
        this.f267d = aVar;
        this.f268e = q.f270a;
        this.f269f = obj == null ? this : obj;
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public /* synthetic */ o(a aVar, Object obj, int i4, e eVar) {
        this(aVar, (i4 & 2) != 0 ? null : obj);
    }

    public boolean a() {
        return this.f268e != q.f270a;
    }

    public T getValue() {
        T t4;
        T t5 = this.f268e;
        T t6 = q.f270a;
        if (t5 != t6) {
            return t5;
        }
        synchronized (this.f269f) {
            t4 = this.f268e;
            if (t4 == t6) {
                a aVar = this.f267d;
                i.b(aVar);
                t4 = aVar.invoke();
                this.f268e = t4;
                this.f267d = null;
            }
        }
        return t4;
    }

    public String toString() {
        return a() ? String.valueOf(getValue()) : "Lazy value not initialized yet.";
    }
}
