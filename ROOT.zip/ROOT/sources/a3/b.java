package a3;

import kotlin.jvm.internal.i;

class b {
    public static void a(Throwable th, Throwable th2) {
        i.e(th, "<this>");
        i.e(th2, "exception");
        if (th != th2) {
            e3.b.f1943a.a(th, th2);
        }
    }
}
