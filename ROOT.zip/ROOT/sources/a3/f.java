package a3;

final class f {

    /* renamed from: a  reason: collision with root package name */
    public static final f f262a = new f();

    private f() {
    }

    public static final e a() {
        return new e(1, 8, 22);
    }
}
