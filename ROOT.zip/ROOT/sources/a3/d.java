package a3;

public final class d extends RuntimeException {
}
