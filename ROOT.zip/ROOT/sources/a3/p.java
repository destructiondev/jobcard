package a3;

public final class p {
    public static final <A, B> l<A, B> a(A a4, B b4) {
        return new l<>(a4, b4);
    }
}
