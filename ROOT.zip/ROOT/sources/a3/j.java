package a3;

class j extends i {
}
