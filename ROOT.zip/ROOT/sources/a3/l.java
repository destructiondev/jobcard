package a3;

import java.io.Serializable;
import kotlin.jvm.internal.i;

public final class l<A, B> implements Serializable {

    /* renamed from: d  reason: collision with root package name */
    private final A f263d;

    /* renamed from: e  reason: collision with root package name */
    private final B f264e;

    public l(A a4, B b4) {
        this.f263d = a4;
        this.f264e = b4;
    }

    public final A a() {
        return this.f263d;
    }

    public final B b() {
        return this.f264e;
    }

    public final A c() {
        return this.f263d;
    }

    public final B d() {
        return this.f264e;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof l)) {
            return false;
        }
        l lVar = (l) obj;
        return i.a(this.f263d, lVar.f263d) && i.a(this.f264e, lVar.f264e);
    }

    public int hashCode() {
        A a4 = this.f263d;
        int i4 = 0;
        int hashCode = (a4 == null ? 0 : a4.hashCode()) * 31;
        B b4 = this.f264e;
        if (b4 != null) {
            i4 = b4.hashCode();
        }
        return hashCode + i4;
    }

    public String toString() {
        return '(' + this.f263d + ", " + this.f264e + ')';
    }
}
