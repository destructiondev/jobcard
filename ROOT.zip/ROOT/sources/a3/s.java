package a3;

public final class s {

    /* renamed from: a  reason: collision with root package name */
    public static final s f271a = new s();

    private s() {
    }

    public String toString() {
        return "kotlin.Unit";
    }
}
