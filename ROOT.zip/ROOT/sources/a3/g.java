package a3;

public interface g<T> {
    T getValue();
}
