package a3;

import j3.a;
import kotlin.jvm.internal.e;

class i {
    public static <T> g<T> a(a<? extends T> aVar) {
        kotlin.jvm.internal.i.e(aVar, "initializer");
        return new o(aVar, (Object) null, 2, (e) null);
    }
}
