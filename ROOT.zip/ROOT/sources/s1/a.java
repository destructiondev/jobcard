package s1;

import com.google.firebase.installations.b;

public final /* synthetic */ class a implements Runnable {

    /* renamed from: d  reason: collision with root package name */
    public final /* synthetic */ b f4214d;

    public /* synthetic */ a(b bVar) {
        this.f4214d = bVar;
    }

    public final void run() {
        this.f4214d.s();
    }
}
