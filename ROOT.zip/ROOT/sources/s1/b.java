package s1;

public final /* synthetic */ class b implements Runnable {

    /* renamed from: d  reason: collision with root package name */
    public final /* synthetic */ com.google.firebase.installations.b f4215d;

    /* renamed from: e  reason: collision with root package name */
    public final /* synthetic */ boolean f4216e;

    public /* synthetic */ b(com.google.firebase.installations.b bVar, boolean z3) {
        this.f4215d = bVar;
        this.f4216e = z3;
    }

    public final void run() {
        this.f4215d.r(this.f4216e);
    }
}
