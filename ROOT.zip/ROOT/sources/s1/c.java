package s1;

import r0.e;
import r1.b;

public final /* synthetic */ class c implements b {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ e f4217a;

    public /* synthetic */ c(e eVar) {
        this.f4217a = eVar;
    }

    public final Object get() {
        return com.google.firebase.installations.b.t(this.f4217a);
    }
}
