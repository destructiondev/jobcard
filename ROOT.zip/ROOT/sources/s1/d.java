package s1;

import p0.j;

public interface d {
    j<String> a();
}
