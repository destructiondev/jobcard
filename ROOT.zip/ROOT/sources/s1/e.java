package s1;

import com.google.firebase.installations.FirebaseInstallationsRegistrar;
import u0.h;

public final /* synthetic */ class e implements h {

    /* renamed from: a  reason: collision with root package name */
    public static final /* synthetic */ e f4218a = new e();

    private /* synthetic */ e() {
    }

    public final Object a(u0.e eVar) {
        return FirebaseInstallationsRegistrar.lambda$getComponents$0(eVar);
    }
}
