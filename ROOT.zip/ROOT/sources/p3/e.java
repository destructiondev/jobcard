package p3;

class e extends d {
}
