package p3;

public final class c extends h {
}
