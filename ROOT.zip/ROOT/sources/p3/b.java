package p3;

import java.util.Iterator;

public interface b<T> {
    Iterator<T> iterator();
}
