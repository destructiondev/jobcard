package p3;

class g extends f {
}
