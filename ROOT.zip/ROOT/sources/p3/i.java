package p3;

import j3.l;
import java.util.Iterator;

public final class i<T, R> implements b<R> {
    /* access modifiers changed from: private */

    /* renamed from: a  reason: collision with root package name */
    public final b<T> f3895a;
    /* access modifiers changed from: private */

    /* renamed from: b  reason: collision with root package name */
    public final l<T, R> f3896b;

    public static final class a implements Iterator<R> {

        /* renamed from: d  reason: collision with root package name */
        private final Iterator<T> f3897d;

        /* renamed from: e  reason: collision with root package name */
        final /* synthetic */ i<T, R> f3898e;

        a(i<T, R> iVar) {
            this.f3898e = iVar;
            this.f3897d = iVar.f3895a.iterator();
        }

        public boolean hasNext() {
            return this.f3897d.hasNext();
        }

        public R next() {
            return this.f3898e.f3896b.invoke(this.f3897d.next());
        }

        public void remove() {
            throw new UnsupportedOperationException("Operation is not supported for read-only collection");
        }
    }

    public i(b<? extends T> bVar, l<? super T, ? extends R> lVar) {
        kotlin.jvm.internal.i.e(bVar, "sequence");
        kotlin.jvm.internal.i.e(lVar, "transformer");
        this.f3895a = bVar;
        this.f3896b = lVar;
    }

    public Iterator<R> iterator() {
        return new a(this);
    }
}
