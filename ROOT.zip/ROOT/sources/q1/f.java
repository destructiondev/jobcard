package q1;

import android.content.Context;
import android.util.Base64OutputStream;
import java.io.ByteArrayOutputStream;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Executor;
import java.util.zip.GZIPOutputStream;
import org.json.JSONArray;
import org.json.JSONObject;
import p0.j;
import p0.m;
import r0.e;
import r1.b;
import t0.a;
import u0.c;
import u0.f0;
import u0.r;
import y1.i;

public class f implements i, j {

    /* renamed from: a  reason: collision with root package name */
    private final b<k> f3906a;

    /* renamed from: b  reason: collision with root package name */
    private final Context f3907b;

    /* renamed from: c  reason: collision with root package name */
    private final b<i> f3908c;

    /* renamed from: d  reason: collision with root package name */
    private final Set<g> f3909d;

    /* renamed from: e  reason: collision with root package name */
    private final Executor f3910e;

    private f(Context context, String str, Set<g> set, b<i> bVar, Executor executor) {
        this((b<k>) new d(context, str), set, executor, bVar, context);
    }

    f(b<k> bVar, Set<g> set, Executor executor, b<i> bVar2, Context context) {
        this.f3906a = bVar;
        this.f3909d = set;
        this.f3910e = executor;
        this.f3908c = bVar2;
        this.f3907b = context;
    }

    public static c<f> f() {
        f0<Executor> a4 = f0.a(a.class, Executor.class);
        return c.d(f.class, i.class, j.class).b(r.i(Context.class)).b(r.i(e.class)).b(r.m(g.class)).b(r.k(i.class)).b(r.j(a4)).e(new e(a4)).c();
    }

    /* access modifiers changed from: private */
    public static /* synthetic */ f g(f0 f0Var, u0.e eVar) {
        return new f((Context) eVar.a(Context.class), ((e) eVar.a(e.class)).s(), eVar.e(g.class), eVar.d(i.class), (Executor) eVar.g(f0Var));
    }

    /* access modifiers changed from: private */
    public /* synthetic */ String h() {
        GZIPOutputStream gZIPOutputStream;
        String byteArrayOutputStream;
        synchronized (this) {
            k kVar = this.f3906a.get();
            List<l> c4 = kVar.c();
            kVar.b();
            JSONArray jSONArray = new JSONArray();
            for (int i4 = 0; i4 < c4.size(); i4++) {
                l lVar = c4.get(i4);
                JSONObject jSONObject = new JSONObject();
                jSONObject.put("agent", lVar.c());
                jSONObject.put("dates", new JSONArray(lVar.b()));
                jSONArray.put(jSONObject);
            }
            JSONObject jSONObject2 = new JSONObject();
            jSONObject2.put("heartbeats", jSONArray);
            jSONObject2.put("version", "2");
            ByteArrayOutputStream byteArrayOutputStream2 = new ByteArrayOutputStream();
            Base64OutputStream base64OutputStream = new Base64OutputStream(byteArrayOutputStream2, 11);
            try {
                gZIPOutputStream = new GZIPOutputStream(base64OutputStream);
                gZIPOutputStream.write(jSONObject2.toString().getBytes("UTF-8"));
                gZIPOutputStream.close();
                base64OutputStream.close();
                byteArrayOutputStream = byteArrayOutputStream2.toString("UTF-8");
            } catch (Throwable th) {
                try {
                    base64OutputStream.close();
                } catch (Throwable th2) {
                    th.addSuppressed(th2);
                }
                throw th;
            }
        }
        return byteArrayOutputStream;
        throw th;
    }

    /* access modifiers changed from: private */
    public static /* synthetic */ k i(Context context, String str) {
        return new k(context, str);
    }

    /* access modifiers changed from: private */
    public /* synthetic */ Void j() {
        synchronized (this) {
            this.f3906a.get().g(System.currentTimeMillis(), this.f3908c.get().a());
        }
        return null;
    }

    public j<String> a() {
        return androidx.core.os.f.a(this.f3907b) ^ true ? m.d("") : m.b(this.f3910e, new c(this));
    }

    public j<Void> k() {
        return this.f3909d.size() <= 0 ? m.d(null) : androidx.core.os.f.a(this.f3907b) ^ true ? m.d(null) : m.b(this.f3910e, new b(this));
    }
}
