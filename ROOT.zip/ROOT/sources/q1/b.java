package q1;

import java.util.concurrent.Callable;

public final /* synthetic */ class b implements Callable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ f f3901a;

    public /* synthetic */ b(f fVar) {
        this.f3901a = fVar;
    }

    public final Object call() {
        return this.f3901a.j();
    }
}
